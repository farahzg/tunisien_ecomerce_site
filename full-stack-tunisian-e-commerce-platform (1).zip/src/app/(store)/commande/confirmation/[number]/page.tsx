import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { CheckCircle2, Phone } from "lucide-react";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { ClearCart } from "@/components/cart/ClearCart";
import { formatTND, formatDateTime } from "@/lib/format";
import { getSettings } from "@/lib/settings";
import { btnClay, btnOutline } from "@/components/ui/styles";

export const metadata: Metadata = {
  title: "Commande confirmée",
  robots: { index: false, follow: false },
};

export default async function ConfirmationPage({ params }: { params: Promise<{ number: string }> }) {
  const { number } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, number.toUpperCase())).limit(1);
  if (!order) notFound();
  const [items, s] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, order.id)),
    getSettings(),
  ]);

  return (
    <div className="container-x max-w-3xl py-12 lg:py-16">
      <ClearCart />
      <div className="text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
          <CheckCircle2 className="h-9 w-9" />
        </span>
        <h1 className="mt-5 font-display text-5xl font-medium">Merci {order.customerName.split(" ")[0]} !</h1>
        <p className="mt-3 text-muted">Votre commande a bien été enregistrée. Notre équipe vous contactera très bientôt pour la confirmer.</p>
        <div className="mx-auto mt-8 inline-block rounded-2xl border-2 border-dashed border-clay/50 bg-white px-8 py-5">
          <p className="text-xs uppercase tracking-[0.25em] text-muted">Numéro de commande</p>
          <p className="mt-1 font-display text-3xl font-semibold tracking-wider text-clay select-all">{order.orderNumber}</p>
        </div>
        <p className="mt-3 text-xs text-muted">Conservez ce numéro pour suivre votre commande.</p>
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-2">
        <section className="rounded-2xl border border-line bg-white p-6">
          <h2 className="font-display text-xl font-semibold">Livraison</h2>
          <address className="mt-3 text-sm not-italic leading-relaxed text-muted">
            <span className="font-medium text-ink">{order.customerName}</span><br />
            {order.address}<br />
            {order.city}, {order.governorate}<br />
            Tél. {order.phone}
          </address>
          {order.notes && <p className="mt-3 text-sm text-muted">Notes : {order.notes}</p>}
        </section>
        <section className="rounded-2xl border border-line bg-white p-6">
          <h2 className="font-display text-xl font-semibold">Paiement</h2>
          <p className="mt-3 text-sm text-muted">Paiement à la livraison (espèces).</p>
          <p className="mt-2 text-sm">Montant à régler : <strong className="font-display text-2xl">{formatTND(order.total)}</strong></p>
          <p className="mt-2 text-xs text-muted">Passée le {formatDateTime(order.createdAt)} · Livraison estimée : {s.delivery.estimate}</p>
        </section>
      </div>

      <section className="mt-6 rounded-2xl border border-line bg-white p-6">
        <h2 className="mb-4 font-display text-xl font-semibold">Récapitulatif</h2>
        <ul className="divide-y divide-line">
          {items.map((i) => (
            <li key={i.id} className="flex items-center gap-4 py-3">
              <div className="h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-cream">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                {i.image && <img src={i.image} alt="" className="h-full w-full object-cover" />}
              </div>
              <div className="min-w-0 flex-1 text-sm">
                <p className="font-medium">{i.name}</p>
                <p className="text-xs text-muted">{i.variantLabel && `${i.variantLabel} · `}Qté {i.quantity}</p>
              </div>
              <p className="text-sm font-medium">{formatTND(i.price * i.quantity)}</p>
            </li>
          ))}
        </ul>
        <dl className="mt-4 space-y-2 border-t border-line pt-4 text-sm">
          <div className="flex justify-between"><dt className="text-muted">Sous-total</dt><dd>{formatTND(order.subtotal)}</dd></div>
          <div className="flex justify-between"><dt className="text-muted">Livraison</dt><dd>{order.deliveryFee === 0 ? "Offerte" : formatTND(order.deliveryFee)}</dd></div>
          <div className="flex justify-between text-base font-semibold"><dt>Total</dt><dd>{formatTND(order.total)}</dd></div>
        </dl>
      </section>

      <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
        <Link href="/boutique" className={btnClay}>Continuer mes achats</Link>
        <Link href={`/suivi-commande?numero=${order.orderNumber}`} className={btnOutline}>Suivre ma commande</Link>
        <a href={`tel:+216${s.store.phone.replace(/\s/g, "")}`} className="inline-flex items-center gap-2 text-sm text-muted hover:text-clay"><Phone className="h-4 w-4" /> {s.store.phone}</a>
      </div>
    </div>
  );
}
