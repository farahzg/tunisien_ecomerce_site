import type { Metadata } from "next";
import { CheckoutForm } from "@/components/cart/CheckoutForm";
import { getDeliveryFees, getSettings } from "@/lib/settings";

export const metadata: Metadata = {
  title: "Finaliser ma commande",
  robots: { index: false, follow: false },
};

export default async function CheckoutPage() {
  const [s, fees] = await Promise.all([getSettings(), getDeliveryFees()]);
  return (
    <div className="container-x py-10 lg:py-14">
      <h1 className="mb-8 font-display text-5xl font-medium">Finaliser ma commande</h1>
      <CheckoutForm
        fees={fees}
        freeThreshold={s.delivery.freeThreshold}
        defaultFee={s.delivery.defaultFee}
        estimate={s.delivery.estimate}
      />
    </div>
  );
}
