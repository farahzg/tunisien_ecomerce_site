import type { Metadata } from "next";
import { Clock, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { getSettings } from "@/lib/settings";
import { ContactForm } from "@/components/store/ContactForm";

export const metadata: Metadata = {
  title: "Contact",
  description: "Contactez ELYSSA ARTISANAT : téléphone, WhatsApp, e-mail et adresse de notre concept store à Tunis.",
  alternates: { canonical: "/contact" },
};

export default async function ContactPage() {
  const { store } = await getSettings();
  const tel = store.phone.replace(/\s/g, "");
  const rows = [
    { Icon: MapPin, title: "Adresse", text: store.address },
    { Icon: Clock, title: "Horaires", text: store.hours },
    { Icon: Phone, title: "Téléphone", text: store.phone, href: `tel:+216${tel}` },
    { Icon: Mail, title: "E-mail", text: store.email, href: `mailto:${store.email}` },
  ];
  return (
    <div className="container-x py-12 lg:py-16">
      <header className="mb-12 max-w-2xl">
        <p className="mb-3 text-xs font-medium uppercase tracking-[0.25em] text-clay">Contact</p>
        <h1 className="font-display text-5xl font-medium sm:text-6xl">Parlons de vos envies</h1>
        <p className="mt-4 text-muted">Une question sur un produit, une commande ou un cadeau sur mesure ? Écrivez-nous, nous répondons rapidement.</p>
      </header>
      <div className="grid gap-10 lg:grid-cols-[1fr_420px]">
        <ContactForm />
        <div className="space-y-4">
          {rows.map(({ Icon, title, text, href }) => (
            <div key={title} className="flex gap-4 rounded-2xl border border-line bg-white p-5">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-cream text-clay"><Icon className="h-5 w-5" /></span>
              <div>
                <p className="text-xs uppercase tracking-widest text-muted">{title}</p>
                {href ? <a href={href} className="font-medium hover:text-clay">{text}</a> : <p className="font-medium">{text}</p>}
              </div>
            </div>
          ))}
          {store.whatsapp && (
            <a
              href={`https://wa.me/${store.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-medium text-white transition hover:brightness-95"
            >
              <MessageCircle className="h-5 w-5" /> Discuter sur WhatsApp
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
