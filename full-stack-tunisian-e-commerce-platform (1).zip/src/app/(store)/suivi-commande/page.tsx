import type { Metadata } from "next";
import { and, eq } from "drizzle-orm";
import { Check, PackageSearch } from "lucide-react";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { ORDER_STATUSES, statusMeta } from "@/lib/constants";
import { formatDateTime, formatTND, normalizePhone } from "@/lib/format";
import { btnClay, input, label } from "@/components/ui/styles";

export const metadata: Metadata = {
  title: "Suivre ma commande",
  description: "Suivez l'état de votre commande ELYSSA ARTISANAT avec votre numéro de commande et votre téléphone.",
  robots: { index: false, follow: true },
};

const FLOW = ["pending", "confirmed", "processing", "shipped", "delivered"];

export default async function TrackingPage({
  searchParams,
}: {
  searchParams: Promise<{ numero?: string; tel?: string }>;
}) {
  const sp = await searchParams;
  const numero = (sp.numero ?? "").trim().toUpperCase();
  const tel = normalizePhone(sp.tel ?? "");
  const searched = !!(numero && tel);

  let order: typeof orders.$inferSelect | undefined;
  let items: (typeof orderItems.$inferSelect)[] = [];
  if (searched) {
    [order] = await db
      .select()
      .from(orders)
      .where(and(eq(orders.orderNumber, numero), eq(orders.phone, tel)))
      .limit(1);
    if (order) items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  }
  const idx = order ? FLOW.indexOf(order.status) : -1;

  return (
    <div className="container-x max-w-2xl py-12 lg:py-16">
      <h1 className="font-display text-5xl font-medium">Suivre ma commande</h1>
      <p className="mt-3 text-muted">Saisissez votre numéro de commande et le téléphone utilisé lors de l&apos;achat.</p>

      <form className="mt-8 grid gap-4 rounded-2xl border border-line bg-white p-6 sm:grid-cols-2" method="get">
        <div>
          <label htmlFor="numero" className={label}>Numéro de commande</label>
          <input id="numero" name="numero" required defaultValue={numero} placeholder="ELY-250101-ABCDE" className={input} />
        </div>
        <div>
          <label htmlFor="tel" className={label}>Téléphone</label>
          <input id="tel" name="tel" required type="tel" defaultValue={sp.tel ?? ""} placeholder="92 944 940" className={input} />
        </div>
        <button className={`${btnClay} sm:col-span-2`}>Rechercher</button>
      </form>

      {searched && !order && (
        <div className="mt-8 rounded-2xl border border-dashed border-line p-10 text-center">
          <PackageSearch className="mx-auto h-10 w-10 text-beige" />
          <p className="mt-3 font-medium">Aucune commande trouvée</p>
          <p className="mt-1 text-sm text-muted">Vérifiez le numéro de commande et le numéro de téléphone saisis.</p>
        </div>
      )}

      {order && (
        <div className="mt-8 rounded-2xl border border-line bg-white p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs uppercase tracking-widest text-muted">Commande</p>
              <p className="font-display text-2xl font-semibold text-clay">{order.orderNumber}</p>
            </div>
            <span className={`rounded-full px-3 py-1 text-xs font-medium ring-1 ${statusMeta(order.status).cls}`}>{statusMeta(order.status).label}</span>
          </div>
          <p className="mt-1 text-xs text-muted">Passée le {formatDateTime(order.createdAt)}</p>

          {order.status === "cancelled" ? (
            <p className="mt-6 rounded-lg bg-rose-50 p-3 text-sm text-rose-700">Cette commande a été annulée.</p>
          ) : (
            <ol className="mt-8 grid grid-cols-5 gap-1">
              {FLOW.map((s, i) => (
                <li key={s} className="text-center">
                  <span className={`mx-auto flex h-8 w-8 items-center justify-center rounded-full text-xs ${i <= idx ? "bg-clay text-white" : "bg-sand text-muted"}`}>
                    {i <= idx ? <Check className="h-4 w-4" /> : i + 1}
                  </span>
                  <p className={`mt-2 text-[11px] leading-tight sm:text-xs ${i <= idx ? "font-medium" : "text-muted"}`}>
                    {ORDER_STATUSES.find((x) => x.value === s)?.label}
                  </p>
                </li>
              ))}
            </ol>
          )}

          <ul className="mt-8 divide-y divide-line border-t border-line text-sm">
            {items.map((i) => (
              <li key={i.id} className="flex justify-between gap-3 py-3">
                <span>{i.name}{i.variantLabel && ` — ${i.variantLabel}`} <span className="text-muted">× {i.quantity}</span></span>
                <span className="font-medium">{formatTND(i.price * i.quantity)}</span>
              </li>
            ))}
          </ul>
          <p className="flex justify-between border-t border-line pt-4 font-semibold"><span>Total (paiement à la livraison)</span><span>{formatTND(order.total)}</span></p>
        </div>
      )}
    </div>
  );
}
