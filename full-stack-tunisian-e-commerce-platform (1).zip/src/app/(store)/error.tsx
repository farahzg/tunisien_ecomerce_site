"use client";

import { btnPrimary } from "@/components/ui/styles";

export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="container-x py-28 text-center">
      <h1 className="font-display text-4xl">Oups, quelque chose s&apos;est mal passé</h1>
      <p className="mx-auto mt-3 max-w-md text-muted">
        Une erreur inattendue est survenue. Veuillez réessayer dans un instant.
      </p>
      <button onClick={reset} className={`${btnPrimary} mt-8`}>Réessayer</button>
    </div>
  );
}
