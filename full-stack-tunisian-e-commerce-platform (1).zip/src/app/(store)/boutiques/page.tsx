import type { Metadata } from "next";
import { Clock, MapPin, Navigation, Phone } from "lucide-react";
import { getSettings } from "@/lib/settings";

export const metadata: Metadata = {
  title: "Nos boutiques",
  description: "Retrouvez nos boutiques ELYSSA ARTISANAT à Tunis (4 rue Alkissai, Mutuelle Ville) et à Mahdia : adresses, horaires et contact.",
  alternates: { canonical: "/boutiques" },
};

export default async function StoresPage() {
  const { locations } = await getSettings();
  const first = locations[0];
  return (
    <div className="container-x py-12 lg:py-16">
      <header className="mb-12 max-w-2xl">
        <p className="mb-3 text-xs font-medium uppercase tracking-[0.25em] text-clay">Nos boutiques</p>
        <h1 className="font-display text-5xl font-medium sm:text-6xl">Venez nous rendre visite</h1>
        <p className="mt-4 text-muted">Parcourez nos collections en vrai, rencontrez l&apos;équipe et découvrez nos expositions.</p>
      </header>

      {locations.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-line p-10 text-center text-muted">Aucune boutique renseignée pour le moment.</p>
      ) : (
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-5">
            {locations.map((l) => (
              <article key={l.name} className="rounded-2xl border border-line bg-white p-6">
                <h2 className="font-display text-3xl font-semibold">{l.name}</h2>
                <ul className="mt-4 space-y-3 text-sm text-muted">
                  <li className="flex gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-clay" />{l.address}</li>
                  <li className="flex gap-3"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-clay" />{l.hours}</li>
                  <li className="flex gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-clay" /><a href={`tel:+216${l.phone.replace(/\s/g, "")}`} className="hover:text-clay">{l.phone}</a></li>
                </ul>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(l.address)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-clay hover:underline"
                >
                  <Navigation className="h-4 w-4" /> Itinéraire
                </a>
              </article>
            ))}
          </div>
          <div className="min-h-[360px] overflow-hidden rounded-2xl border border-line bg-cream">
            <iframe
              title={`Carte — ${first.name}`}
              src={`https://maps.google.com/maps?q=${encodeURIComponent(first.address)}&output=embed`}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="h-full min-h-[360px] w-full border-0"
            />
          </div>
        </div>
      )}
    </div>
  );
}
