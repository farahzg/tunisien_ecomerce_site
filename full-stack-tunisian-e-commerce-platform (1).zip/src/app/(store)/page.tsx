import Link from "next/link";
import type { Metadata } from "next";
import { ArrowRight, Truck, Hand, Banknote, Gift, Star } from "lucide-react";
import { getCategoriesWithCounts, listProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { ProductCard } from "@/components/store/ProductCard";
import { InstagramIcon, StarPattern } from "@/components/icons";
import { btnClay, btnOutline } from "@/components/ui/styles";

export const metadata: Metadata = {
  title: { absolute: "ELYSSA ARTISANAT — Concept store tunisien : artisanat, bijoux, déco" },
  alternates: { canonical: "/" },
};

function Heading({ eyebrow, title, href, cta }: { eyebrow: string; title: string; href?: string; cta?: string }) {
  return (
    <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.25em] text-clay">
          <StarPattern className="h-3 w-3" /> {eyebrow}
        </p>
        <h2 className="font-display text-4xl font-medium sm:text-5xl">{title}</h2>
      </div>
      {href && (
        <Link href={href} className="group inline-flex items-center gap-2 text-sm font-medium hover:text-clay">
          {cta ?? "Voir tout"} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
        </Link>
      )}
    </div>
  );
}

export default async function HomePage() {
  const [settings, categories, best, fresh, featured] = await Promise.all([
    getSettings(),
    getCategoriesWithCounts(),
    listProducts({ sort: "populaires", limit: 4, inStock: true }),
    listProducts({ sort: "nouveautes", limit: 4 }),
    listProducts({ featured: true, limit: 8 }),
  ]);
  const { promo, collections, testimonials, social } = settings;
  const insta = featured.items.length ? featured.items : fresh.items;

  const perks = [
    { Icon: Truck, title: "Livraison en Tunisie", text: "Dans les 24 gouvernorats" },
    { Icon: Banknote, title: "Paiement à la livraison", text: "Réglez en main propre" },
    { Icon: Hand, title: "100 % made in Tunisia", text: "Créateurs & artisans locaux" },
    { Icon: Gift, title: "Emballage soigné", text: "Prêt à offrir" },
  ];

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-cream/70">
        <div className="pattern-zellige absolute inset-0 opacity-70" aria-hidden />
        <div className="container-x relative grid items-center gap-10 py-12 lg:grid-cols-12 lg:gap-6 lg:py-20">
          <div className="lg:col-span-6 lg:pr-10">
            <p className="animate-fade-up mb-5 flex items-center gap-3 text-xs font-medium uppercase tracking-[0.3em] text-clay">
              <span className="h-px w-8 bg-clay" /> {promo.heroEyebrow}
            </p>
            <h1 className="animate-fade-up delay-1 font-display text-5xl font-medium leading-[1.02] sm:text-6xl lg:text-7xl">
              {promo.heroTitle}
            </h1>
            <p className="animate-fade-up delay-2 mt-6 max-w-lg text-base leading-relaxed text-muted sm:text-lg">
              {promo.heroSubtitle}
            </p>
            <div className="animate-fade-up delay-3 mt-9 flex flex-wrap gap-3">
              <Link href={promo.heroCtaLink || "/boutique"} className={btnClay}>
                {promo.heroCta} <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/a-propos" className={btnOutline}>Notre histoire</Link>
            </div>
          </div>
          <div className="animate-fade-up delay-2 relative mx-auto w-full max-w-md lg:col-span-6 lg:max-w-none">
            <div className="relative mx-auto aspect-[4/5] w-full max-w-[34rem] overflow-hidden rounded-t-[999px] rounded-b-3xl border-[6px] border-ivory shadow-2xl shadow-clay/20">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={promo.heroImage} alt="Pièces artisanales tunisiennes ELYSSA ARTISANAT" fetchPriority="high" className="h-full w-full object-cover" />
            </div>
            <div className="absolute -bottom-4 left-2 hidden rounded-2xl bg-white px-5 py-4 shadow-xl sm:block lg:-left-4">
              <p className="font-display text-3xl font-semibold text-clay">100 %</p>
              <p className="text-xs uppercase tracking-widest text-muted">Made in Tunisia</p>
            </div>
          </div>
        </div>
      </section>

      {/* PERKS */}
      <section className="border-y border-line bg-ivory">
        <div className="container-x grid grid-cols-2 gap-6 py-8 lg:grid-cols-4">
          {perks.map(({ Icon, title, text }) => (
            <div key={title} className="flex items-center gap-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-cream text-clay">
                <Icon className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-semibold">{title}</p>
                <p className="text-xs text-muted">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="container-x pt-20">
        <Heading eyebrow="Explorer" title="Nos univers" href="/boutique" cta="Toute la boutique" />
        {categories.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-line p-10 text-center text-muted">Les catégories arrivent bientôt.</p>
        ) : (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-6 lg:gap-5">
            {categories.map((c, i) => (
              <Link
                key={c.id}
                href={`/boutique?categorie=${c.slug}`}
                className={`group relative block overflow-hidden rounded-2xl bg-sand ${
                  i < 2 ? "md:col-span-3 aspect-[16/10]" : "md:col-span-2 aspect-[4/5] md:aspect-[3/4]"
                } ${i === categories.length - 1 && categories.length % 2 === 1 ? "col-span-2 aspect-[16/10] md:col-span-2 md:aspect-[3/4]" : ""}`}
              >
                {c.imageUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={c.imageUrl} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-4 text-ivory sm:p-6">
                  <h3 className="font-display text-2xl font-medium sm:text-3xl">{c.name}</h3>
                  <p className="mt-1 flex items-center gap-1.5 text-xs text-ivory/80">
                    {c.count} article{c.count > 1 ? "s" : ""}
                    <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-1" />
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* BEST SELLERS */}
      <section className="container-x pt-24">
        <Heading eyebrow="Coups de cœur" title="Nos meilleures ventes" href="/boutique?tri=populaires" />
        {best.items.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-line p-10 text-center text-muted">Aucun produit pour le moment.</p>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-4 lg:gap-x-6">
            {best.items.map((p, i) => <ProductCard key={p.id} product={p} priority={i < 2} />)}
          </div>
        )}
      </section>

      {/* STORY */}
      <section className="relative mt-24 overflow-hidden bg-ink text-ivory">
        <div className="pattern-zellige absolute inset-0 opacity-40" aria-hidden />
        <div className="container-x relative grid items-center gap-12 py-20 lg:grid-cols-2 lg:py-28">
          <div className="relative order-2 lg:order-1">
            <div className="aspect-[5/4] overflow-hidden rounded-3xl">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={promo.storyImage} alt="Architecture blanche et bleue de Tunisie" loading="lazy" className="h-full w-full object-cover" />
            </div>
            <div className="absolute -bottom-5 right-4 rounded-2xl bg-clay px-6 py-4 text-white shadow-xl sm:right-8">
              <p className="font-display text-2xl">Tunis · Mahdia</p>
              <p className="text-xs uppercase tracking-widest text-white/80">Nos deux boutiques</p>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <p className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.25em] text-beige">
              <StarPattern className="h-3 w-3" /> Notre histoire
            </p>
            <h2 className="font-display text-4xl font-medium leading-tight sm:text-5xl">{promo.storyTitle}</h2>
            <p className="mt-6 max-w-xl leading-relaxed text-ivory/75">{promo.storyText}</p>
            <ul className="mt-8 grid max-w-md grid-cols-3 gap-4 text-center">
              {[["100 %", "fait main"], ["2", "boutiques"], ["24", "gouvernorats livrés"]].map(([n, l]) => (
                <li key={l} className="rounded-xl border border-white/15 px-2 py-4">
                  <p className="font-display text-3xl text-beige">{n}</p>
                  <p className="text-[11px] uppercase tracking-wider text-ivory/60">{l}</p>
                </li>
              ))}
            </ul>
            <Link href="/a-propos" className="mt-9 inline-flex items-center gap-2 rounded-full border border-ivory/40 px-7 py-3 text-sm transition hover:bg-ivory hover:text-ink">
              Lire notre histoire <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* COLLECTIONS */}
      {collections.length > 0 && (
        <section className="container-x pt-24">
          <Heading eyebrow="Sélections" title="Collections à la une" />
          <div className="grid gap-5 sm:grid-cols-2">
            {collections.map((c) => (
              <Link key={c.title} href={c.href || "/boutique"} className="group relative block aspect-[16/11] overflow-hidden rounded-3xl bg-sand">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={c.image} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-r from-ink/75 via-ink/30 to-transparent" />
                <div className="absolute inset-0 flex max-w-[75%] flex-col justify-end p-6 text-ivory sm:p-8">
                  <h3 className="font-display text-3xl font-medium sm:text-4xl">{c.title}</h3>
                  <p className="mt-2 text-sm text-ivory/80">{c.text}</p>
                  <span className="mt-4 inline-flex items-center gap-2 text-sm font-medium">
                    Découvrir <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1.5" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* NEW ARRIVALS */}
      <section className="container-x pt-24">
        <Heading eyebrow="Fraîchement arrivés" title="Nouveautés" href="/boutique?tri=nouveautes" />
        {fresh.items.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-line p-10 text-center text-muted">Aucune nouveauté pour le moment.</p>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-4 lg:gap-x-6">
            {fresh.items.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </section>

      {/* TESTIMONIALS */}
      {testimonials.length > 0 && (
        <section className="mt-24 bg-cream/70 py-20">
          <div className="container-x">
            <div className="mb-12 text-center">
              <p className="mb-2 text-xs font-medium uppercase tracking-[0.25em] text-clay">Avis clients</p>
              <h2 className="font-display text-4xl font-medium sm:text-5xl">Elles et ils nous font confiance</h2>
            </div>
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
              {testimonials.map((t) => (
                <figure key={t.name} className="flex flex-col rounded-2xl border border-line bg-ivory p-6">
                  <div className="mb-4 flex gap-0.5 text-clay" aria-label={`${t.rating} sur 5`}>
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < t.rating ? "fill-current" : "text-sand"}`} />
                    ))}
                  </div>
                  <blockquote className="flex-1 font-display text-lg leading-snug">« {t.text} »</blockquote>
                  <figcaption className="mt-5 text-sm">
                    <span className="font-semibold">{t.name}</span>
                    <span className="text-muted"> · {t.city}</span>
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* INSTAGRAM */}
      <section className="container-x pt-24">
        <div className="mb-8 text-center">
          <p className="mb-2 text-xs font-medium uppercase tracking-[0.25em] text-clay">Suivez-nous</p>
          <h2 className="font-display text-4xl font-medium sm:text-5xl">@elyssaartisanat</h2>
          <p className="mt-2 text-sm text-muted">Nos nouveautés, coulisses d&apos;atelier et vernissages sur Instagram.</p>
        </div>
        <div className="grid grid-cols-3 gap-2 sm:gap-3 lg:grid-cols-6">
          {insta.slice(0, 6).map((p) => (
            <a
              key={p.id}
              href={social.instagram || "https://www.instagram.com/elyssaartisanat"}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative aspect-square overflow-hidden rounded-xl bg-cream"
              aria-label={`Voir ${p.name} sur Instagram`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.images[0]} alt={p.name} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-110" />
              <span className="absolute inset-0 flex items-center justify-center bg-ink/40 opacity-0 transition group-hover:opacity-100">
                <InstagramIcon className="h-7 w-7 text-white" />
              </span>
            </a>
          ))}
        </div>
        <div className="mt-8 text-center">
          <a href={social.instagram} target="_blank" rel="noopener noreferrer" className={btnOutline}>
            <InstagramIcon className="h-4 w-4" /> Suivre sur Instagram
          </a>
        </div>
      </section>
    </>
  );
}
