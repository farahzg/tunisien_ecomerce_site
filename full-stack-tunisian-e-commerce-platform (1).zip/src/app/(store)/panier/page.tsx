import type { Metadata } from "next";
import { CartView } from "@/components/cart/CartView";
import { getSettings } from "@/lib/settings";

export const metadata: Metadata = {
  title: "Mon panier",
  robots: { index: false, follow: false },
};

export default async function CartPage() {
  const s = await getSettings();
  return (
    <div className="container-x py-10 lg:py-14">
      <h1 className="mb-8 font-display text-5xl font-medium">Mon panier</h1>
      <CartView freeThreshold={s.delivery.freeThreshold} />
    </div>
  );
}
