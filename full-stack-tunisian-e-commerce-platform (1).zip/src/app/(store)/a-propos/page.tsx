import Link from "next/link";
import type { Metadata } from "next";
import { Gem, Hand, Leaf, Heart } from "lucide-react";
import { getSettings } from "@/lib/settings";
import { btnClay } from "@/components/ui/styles";

export const metadata: Metadata = {
  title: "Notre histoire",
  description: "ELYSSA ARTISANAT, concept store tunisien dédié aux créateurs et artisans : savoir-faire, authenticité et pièces uniques 100 % made in Tunisia.",
  alternates: { canonical: "/a-propos" },
};

const values = [
  { Icon: Hand, title: "Fait main", text: "Chaque pièce est façonnée, peinte ou brodée à la main : de légères différences témoignent de son authenticité." },
  { Icon: Leaf, title: "Matières nobles", text: "Cuivre martelé, céramique émaillée, lin, soie, paille : des matières choisies pour durer." },
  { Icon: Gem, title: "Pièces uniques", text: "Des éditions limitées et des créations d'artistes que l'on ne trouve pas ailleurs." },
  { Icon: Heart, title: "Made in Tunisia", text: "Nous valorisons les artisans et créateurs tunisiens et leur savoir-faire contemporain." },
];

export default async function AboutPage() {
  const { promo, store } = await getSettings();
  return (
    <>
      <section className="relative overflow-hidden bg-cream/70">
        <div className="pattern-zellige absolute inset-0 opacity-60" aria-hidden />
        <div className="container-x relative py-16 text-center lg:py-24">
          <p className="mb-3 text-xs font-medium uppercase tracking-[0.3em] text-clay">Notre histoire</p>
          <h1 className="mx-auto max-w-3xl font-display text-5xl font-medium leading-tight sm:text-6xl">{promo.storyTitle}</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-muted">{store.tagline}</p>
        </div>
      </section>

      <section className="container-x grid items-center gap-12 py-20 lg:grid-cols-2">
        <div className="aspect-[4/5] overflow-hidden rounded-3xl">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={promo.heroImage} alt="Pièces artisanales ELYSSA ARTISANAT" loading="lazy" className="h-full w-full object-cover" />
        </div>
        <div className="space-y-5 leading-relaxed text-muted">
          <h2 className="font-display text-4xl text-ink">Un concept store, une vision</h2>
          <p>{promo.storyText}</p>
          <p>
            Installé au cœur de Tunis, à la Mutuelle Ville, et à Mahdia, ELYSSA ARTISANAT est un lieu de vie autant qu&apos;une
            boutique : on y découvre des expositions de peinture, des vernissages et des rencontres avec les créateurs que nous défendons.
          </p>
          <p>
            Notre boutique en ligne prolonge cette expérience : vous retrouvez nos pièces coup de cœur, livrées partout en Tunisie,
            avec un paiement à la livraison pour acheter en toute confiance.
          </p>
          <Link href="/boutique" className={`${btnClay} mt-2`}>Découvrir la collection</Link>
        </div>
      </section>

      <section className="bg-ink py-20 text-ivory">
        <div className="container-x">
          <h2 className="mb-12 text-center font-display text-4xl sm:text-5xl">Nos engagements</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map(({ Icon, title, text }) => (
              <div key={title} className="rounded-2xl border border-white/10 p-6">
                <Icon className="h-7 w-7 text-clay" />
                <h3 className="mt-4 font-display text-2xl">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ivory/70">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
