export default function Loading() {
  return (
    <div className="container-x py-12" aria-busy="true" aria-label="Chargement">
      <div className="skeleton mb-8 h-10 w-64" />
      <div className="grid grid-cols-2 gap-5 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i}>
            <div className="skeleton aspect-[4/5] w-full rounded-2xl" />
            <div className="skeleton mt-4 h-4 w-3/4" />
            <div className="skeleton mt-2 h-4 w-1/3" />
          </div>
        ))}
      </div>
    </div>
  );
}
