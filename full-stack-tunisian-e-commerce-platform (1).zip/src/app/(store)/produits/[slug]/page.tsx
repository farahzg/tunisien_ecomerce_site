import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getProductBySlug, getRelatedProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { ProductGallery } from "@/components/store/ProductGallery";
import { ProductPurchase } from "@/components/store/ProductPurchase";
import { ProductCard } from "@/components/store/ProductCard";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const p = await getProductBySlug(slug);
  if (!p) return { title: "Produit introuvable", robots: { index: false } };
  const description = (p.shortDescription || p.description).slice(0, 160);
  return {
    title: p.name,
    description,
    alternates: { canonical: `/produits/${p.slug}` },
    openGraph: { title: p.name, description, images: p.images.slice(0, 1), type: "website" },
  };
}

export default async function ProductPage({ params }: Params) {
  const { slug } = await params;
  const p = await getProductBySlug(slug);
  if (!p) notFound();
  const [related, settings] = await Promise.all([getRelatedProducts(p.categoryId, p.id), getSettings()]);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name,
    description: p.description,
    image: p.images,
    sku: p.sku || undefined,
    brand: { "@type": "Brand", name: "ELYSSA ARTISANAT" },
    offers: {
      "@type": "Offer",
      priceCurrency: "TND",
      price: p.price,
      availability: p.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
  };

  return (
    <div className="container-x py-8 lg:py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
      <nav aria-label="Fil d'Ariane" className="mb-6 text-sm text-muted">
        <Link href="/" className="hover:text-clay">Accueil</Link> <span className="mx-1.5">/</span>
        <Link href="/boutique" className="hover:text-clay">Boutique</Link> <span className="mx-1.5">/</span>
        {p.categoryName && (
          <>
            <Link href={`/boutique?categorie=${p.categorySlug}`} className="hover:text-clay">{p.categoryName}</Link>
            <span className="mx-1.5">/</span>
          </>
        )}
        <span className="text-ink">{p.name}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
        <ProductGallery images={p.images} name={p.name} />
        <div className="lg:py-4">
          {p.categoryName && <p className="mb-2 text-xs font-medium uppercase tracking-[0.25em] text-clay">{p.categoryName}</p>}
          <h1 className="font-display text-4xl font-medium leading-tight sm:text-5xl">{p.name}</h1>
          {p.shortDescription && <p className="mt-3 text-muted">{p.shortDescription}</p>}
          <div className="mt-6 border-t border-line pt-6">
            <ProductPurchase
              product={{
                id: p.id,
                slug: p.slug,
                name: p.name,
                price: p.price,
                comparePrice: p.comparePrice,
                image: p.images[0] ?? "",
                stock: p.stock,
              }}
              variants={p.variants.map((v) => ({
                id: v.id,
                optionName: v.optionName,
                value: v.value,
                priceAdjust: v.priceAdjust,
                stock: v.stock,
              }))}
            />
          </div>

          <div className="mt-8 divide-y divide-line border-y border-line text-sm">
            <details open className="group py-4">
              <summary className="flex cursor-pointer list-none items-center justify-between font-medium">Description <span className="text-xl text-clay group-open:rotate-45 transition">+</span></summary>
              <p className="mt-3 whitespace-pre-line leading-relaxed text-muted">{p.description || p.shortDescription}</p>
            </details>
            <details className="group py-4">
              <summary className="flex cursor-pointer list-none items-center justify-between font-medium">Livraison & paiement <span className="text-xl text-clay group-open:rotate-45 transition">+</span></summary>
              <p className="mt-3 leading-relaxed text-muted">
                Livraison dans toute la Tunisie en {settings.delivery.estimate}. Frais de livraison selon votre gouvernorat,
                offerts dès {settings.delivery.freeThreshold} TND d&apos;achat. Paiement en espèces à la réception de votre colis.
              </p>
            </details>
            {p.sku && (
              <div className="flex justify-between py-4"><span className="font-medium">Référence</span><span className="text-muted">{p.sku}</span></div>
            )}
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24">
          <h2 className="mb-8 font-display text-4xl font-medium">Vous aimerez aussi</h2>
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 lg:grid-cols-4 lg:gap-x-6">
            {related.map((r) => <ProductCard key={r.id} product={r} />)}
          </div>
        </section>
      )}
    </div>
  );
}
