import { CartProvider } from "@/components/cart/CartProvider";
import { Header } from "@/components/store/Header";
import { Footer } from "@/components/store/Footer";
import { getSettings } from "@/lib/settings";
import { getCategories } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function StoreLayout({ children }: { children: React.ReactNode }) {
  const [settings, cats] = await Promise.all([getSettings(), getCategories().catch(() => [])]);
  const categories = cats.map((c) => ({ name: c.name, slug: c.slug }));
  return (
    <CartProvider>
      <a
        href="#contenu"
        className="sr-only z-[100] rounded bg-ink px-4 py-2 text-ivory focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Aller au contenu
      </a>
      <Header
        categories={categories}
        announcement={settings.promo.announcementEnabled ? settings.promo.announcement : null}
      />
      <main id="contenu">{children}</main>
      <Footer settings={settings} categories={categories} />
    </CartProvider>
  );
}
