import Link from "next/link";
import { btnPrimary } from "@/components/ui/styles";

export default function NotFound() {
  return (
    <div className="container-x py-28 text-center">
      <p className="text-sm uppercase tracking-[0.3em] text-clay">Erreur 404</p>
      <h1 className="mt-3 font-display text-5xl">Page introuvable</h1>
      <p className="mx-auto mt-3 max-w-md text-muted">
        La page que vous cherchez n&apos;existe plus ou a été déplacée.
      </p>
      <Link href="/boutique" className={`${btnPrimary} mt-8`}>Retour à la boutique</Link>
    </div>
  );
}
