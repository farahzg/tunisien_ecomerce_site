import Link from "next/link";
import type { Metadata } from "next";
import { ChevronLeft, ChevronRight, PackageSearch } from "lucide-react";
import { SORTS, getCategoriesWithCounts, listProducts } from "@/lib/queries";
import { CatalogFilters } from "@/components/store/CatalogFilters";
import { ProductCard } from "@/components/store/ProductCard";
import { btnPrimary } from "@/components/ui/styles";

const PAGE_SIZE = 12;

type SP = Record<string, string | string[] | undefined>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

export async function generateMetadata({ searchParams }: { searchParams: Promise<SP> }): Promise<Metadata> {
  const sp = await searchParams;
  const cats = await getCategoriesWithCounts().catch(() => []);
  const cat = cats.find((c) => c.slug === one(sp.categorie));
  const q = one(sp.q);
  const title = cat ? cat.name : q ? `Recherche : ${q}` : "Boutique";
  return {
    title,
    description:
      cat?.description ||
      "Découvrez notre sélection d'artisanat, bijoux, décoration, mode et cadeaux uniques 100 % made in Tunisia.",
    alternates: { canonical: cat ? `/boutique?categorie=${cat.slug}` : "/boutique" },
    robots: q ? { index: false, follow: true } : undefined,
  };
}

export default async function ShopPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = one(sp.q).trim().slice(0, 80);
  const categorie = one(sp.categorie);
  const tri = SORTS.some((s) => s.value === one(sp.tri)) ? one(sp.tri) : "nouveautes";
  const min = one(sp.min);
  const max = one(sp.max);
  const dispo = one(sp.dispo) === "1";
  const page = Math.max(1, parseInt(one(sp.page)) || 1);

  const [cats, { items, total }] = await Promise.all([
    getCategoriesWithCounts(),
    listProducts({
      q: q || undefined,
      category: categorie || undefined,
      sort: tri,
      min: min ? Number(min) : undefined,
      max: max ? Number(max) : undefined,
      inStock: dispo,
      limit: PAGE_SIZE,
      offset: (page - 1) * PAGE_SIZE,
    }),
  ]);
  const activeCat = cats.find((c) => c.slug === categorie);
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  const pageHref = (p: number) => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (categorie) params.set("categorie", categorie);
    if (tri !== "nouveautes") params.set("tri", tri);
    if (min) params.set("min", min);
    if (max) params.set("max", max);
    if (dispo) params.set("dispo", "1");
    if (p > 1) params.set("page", String(p));
    const s = params.toString();
    return s ? `/boutique?${s}` : "/boutique";
  };

  return (
    <div className="container-x py-10 lg:py-14">
      <nav aria-label="Fil d'Ariane" className="mb-6 text-sm text-muted">
        <Link href="/" className="hover:text-clay">Accueil</Link> <span className="mx-1.5">/</span>
        <span className="text-ink">{activeCat ? activeCat.name : "Boutique"}</span>
      </nav>
      <header className="mb-10 max-w-2xl">
        <h1 className="font-display text-5xl font-medium sm:text-6xl">
          {activeCat ? activeCat.name : q ? `Résultats pour « ${q} »` : "La boutique"}
        </h1>
        <p className="mt-3 text-muted">
          {activeCat?.description || "Des pièces artisanales choisies avec soin, créées et façonnées en Tunisie."}
        </p>
      </header>

      <CatalogFilters
        categories={cats.map((c) => ({ name: c.name, slug: c.slug, count: c.count }))}
        sorts={SORTS}
        current={{ q, categorie, tri, min, max, dispo }}
      />

      <p className="mb-6 mt-8 text-sm text-muted" aria-live="polite">
        {total} produit{total > 1 ? "s" : ""}
      </p>

      {items.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-line bg-white/50 px-6 py-20 text-center">
          <PackageSearch className="mx-auto h-12 w-12 text-beige" />
          <h2 className="mt-4 font-display text-3xl">Aucun produit trouvé</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted">
            Essayez de modifier votre recherche ou de retirer certains filtres.
          </p>
          <Link href="/boutique" className={`${btnPrimary} mt-6`}>Voir toute la boutique</Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4 lg:gap-x-6">
          {items.map((p, i) => <ProductCard key={p.id} product={p} priority={i < 4} />)}
        </div>
      )}

      {pages > 1 && (
        <nav className="mt-14 flex items-center justify-center gap-2" aria-label="Pagination">
          {page > 1 && (
            <Link href={pageHref(page - 1)} aria-label="Page précédente" className="rounded-full border border-line p-2.5 hover:border-clay">
              <ChevronLeft className="h-4 w-4" />
            </Link>
          )}
          {Array.from({ length: pages }).map((_, i) => (
            <Link
              key={i}
              href={pageHref(i + 1)}
              aria-current={page === i + 1 ? "page" : undefined}
              className={`flex h-10 w-10 items-center justify-center rounded-full text-sm ${
                page === i + 1 ? "bg-ink text-ivory" : "border border-line hover:border-clay"
              }`}
            >
              {i + 1}
            </Link>
          ))}
          {page < pages && (
            <Link href={pageHref(page + 1)} aria-label="Page suivante" className="rounded-full border border-line p-2.5 hover:border-clay">
              <ChevronRight className="h-4 w-4" />
            </Link>
          )}
        </nav>
      )}
    </div>
  );
}
