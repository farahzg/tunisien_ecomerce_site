import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import { ToastProvider } from "@/components/ui/Toast";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-cormorant",
  display: "swap",
});
const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "ELYSSA ARTISANAT — Artisanat, bijoux et décoration made in Tunisia",
    template: "%s | ELYSSA ARTISANAT",
  },
  description:
    "Concept store tunisien : artisanat, bijoux, décoration, mode et cadeaux uniques 100 % made in Tunisia. Livraison partout en Tunisie, paiement à la livraison.",
  keywords: [
    "artisanat tunisien",
    "bijoux faits main",
    "décoration Tunisie",
    "cadeaux uniques",
    "concept store Tunis",
    "Elyssa Artisanat",
  ],
  openGraph: {
    type: "website",
    locale: "fr_TN",
    siteName: "ELYSSA ARTISANAT",
    images: ["/images/hero.jpg"],
  },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = {
  themeColor: "#fbf8f2",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${cormorant.variable} ${inter.variable}`}>
      <body className="min-h-screen antialiased">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
