"use server";

import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { createSession, destroySession } from "@/lib/auth";
import { hashPassword, verifyPassword } from "@/lib/password";
import { loginSchema } from "@/lib/validation";

const attempts = new Map<string, { n: number; first: number }>();
const WINDOW = 10 * 60 * 1000;
const MAX_ATTEMPTS = 6;
const DUMMY_HASH = hashPassword("dummy-password-for-timing");

export type LoginState = { error?: string } | undefined;

export async function loginAction(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const parsed = loginSchema.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) return { error: "Veuillez saisir un e-mail et un mot de passe valides." };

  const h = await headers();
  const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  const key = `${ip}|${parsed.data.email}`;
  const now = Date.now();
  const rec = attempts.get(key);
  if (rec && now - rec.first < WINDOW && rec.n >= MAX_ATTEMPTS) {
    return { error: "Trop de tentatives. Réessayez dans quelques minutes." };
  }

  const [user] = await db
    .select()
    .from(adminUsers)
    .where(eq(adminUsers.email, parsed.data.email))
    .limit(1);
  const ok = verifyPassword(parsed.data.password, user?.passwordHash ?? DUMMY_HASH) && !!user;
  if (!ok) {
    attempts.set(key, !rec || now - rec.first >= WINDOW ? { n: 1, first: now } : { n: rec.n + 1, first: rec.first });
    return { error: "E-mail ou mot de passe incorrect." };
  }
  attempts.delete(key);
  await createSession(user.id);
  redirect("/admin");
}

export async function logoutAction() {
  await destroySession();
  redirect("/admin/login");
}
