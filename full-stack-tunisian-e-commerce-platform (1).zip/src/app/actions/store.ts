"use server";

import { randomInt } from "node:crypto";
import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  contactMessages,
  customers,
  newsletterSubscribers,
  orderItems,
  orders,
  productVariants,
  products,
} from "@/db/schema";
import { contactSchema, newsletterSchema, orderSchema } from "@/lib/validation";
import { computeDelivery, getDeliveryFees, getSettings } from "@/lib/settings";

class UserError extends Error {}

export type ActionResult =
  | { ok: true; message?: string }
  | { ok: false; error: string; fieldErrors?: Record<string, string> };

function fieldErrors(issues: { path: PropertyKey[]; message: string }[]) {
  const out: Record<string, string> = {};
  for (const i of issues) {
    const k = String(i.path[0] ?? "form");
    if (!out[k]) out[k] = i.message;
  }
  return out;
}

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function makeOrderNumber() {
  const d = new Date();
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  let s = "";
  for (let i = 0; i < 5; i++) s += ALPHABET[randomInt(ALPHABET.length)];
  return `ELY-${yy}${mm}${dd}-${s}`;
}

export async function createOrder(
  raw: unknown,
): Promise<{ ok: true; orderNumber: string } | { ok: false; error: string; fieldErrors?: Record<string, string> }> {
  const parsed = orderSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Veuillez corriger les champs signalés.",
      fieldErrors: fieldErrors(parsed.error.issues),
    };
  }
  const data = parsed.data;
  const [s, fees] = await Promise.all([getSettings(), getDeliveryFees()]);
  const zone = fees.find((f) => f.governorate === data.governorate);
  if (zone && !zone.active) {
    return { ok: false, error: `Nous ne livrons pas encore à ${data.governorate}.` };
  }

  try {
    const orderNumber = await db.transaction(async (tx) => {
      // Merge duplicate lines
      const merged = new Map<string, (typeof data.items)[number]>();
      for (const it of data.items) {
        const k = `${it.productId}-${it.variantId ?? 0}`;
        const prev = merged.get(k);
        merged.set(k, prev ? { ...prev, quantity: prev.quantity + it.quantity } : it);
      }

      const lines: {
        productId: number;
        variantId: number | null;
        name: string;
        variantLabel: string;
        price: number;
        quantity: number;
        image: string;
      }[] = [];

      for (const it of merged.values()) {
        const [p] = await tx.select().from(products).where(eq(products.id, it.productId));
        if (!p || !p.available) {
          throw new UserError("Un des articles de votre panier n'est plus disponible.");
        }
        const variants = await tx
          .select()
          .from(productVariants)
          .where(eq(productVariants.productId, p.id));
        let unit = p.price;
        let variantLabel = "";
        let variantId: number | null = null;
        if (variants.length) {
          const v = variants.find((x) => x.id === it.variantId);
          if (!v) throw new UserError(`Veuillez choisir une option pour « ${p.name} ».`);
          const upd = await tx
            .update(productVariants)
            .set({ stock: sql`${productVariants.stock} - ${it.quantity}` })
            .where(and(eq(productVariants.id, v.id), gte(productVariants.stock, it.quantity)))
            .returning({ id: productVariants.id });
          if (!upd.length) {
            throw new UserError(`Stock insuffisant pour « ${p.name} — ${v.value} ».`);
          }
          unit = p.price + v.priceAdjust;
          variantLabel = v.value;
          variantId = v.id;
        } else {
          const upd = await tx
            .update(products)
            .set({ stock: sql`${products.stock} - ${it.quantity}` })
            .where(and(eq(products.id, p.id), gte(products.stock, it.quantity)))
            .returning({ id: products.id });
          if (!upd.length) throw new UserError(`Stock insuffisant pour « ${p.name} ».`);
        }
        lines.push({
          productId: p.id,
          variantId,
          name: p.name,
          variantLabel,
          price: unit,
          quantity: it.quantity,
          image: p.images[0] ?? "",
        });
      }

      const subtotal = lines.reduce((n, l) => n + l.price * l.quantity, 0);
      const deliveryFee = computeDelivery(data.governorate, subtotal, s, fees);
      const total = subtotal + deliveryFee;

      const [customer] = await tx
        .insert(customers)
        .values({
          fullName: data.fullName,
          phone: data.phone,
          email: data.email,
          governorate: data.governorate,
          city: data.city,
          address: data.address,
        })
        .onConflictDoUpdate({
          target: customers.phone,
          set: {
            fullName: data.fullName,
            email: sql`coalesce(nullif(${data.email}, ''), ${customers.email})`,
            governorate: data.governorate,
            city: data.city,
            address: data.address,
            updatedAt: new Date(),
          },
        })
        .returning({ id: customers.id });

      const number = makeOrderNumber();
      const [order] = await tx
        .insert(orders)
        .values({
          orderNumber: number,
          customerId: customer.id,
          status: "pending",
          subtotal,
          deliveryFee,
          total,
          paymentMethod: "cod",
          customerName: data.fullName,
          phone: data.phone,
          email: data.email,
          governorate: data.governorate,
          city: data.city,
          address: data.address,
          notes: data.notes,
        })
        .returning({ id: orders.id });
      await tx.insert(orderItems).values(lines.map((l) => ({ ...l, orderId: order.id })));
      return number;
    });
    return { ok: true, orderNumber };
  } catch (e) {
    if (e instanceof UserError) return { ok: false, error: e.message };
    console.error("[createOrder]", e);
    return { ok: false, error: "Une erreur est survenue. Veuillez réessayer dans un instant." };
  }
}

export async function subscribeNewsletter(email: string): Promise<ActionResult> {
  const parsed = newsletterSchema.safeParse({ email });
  if (!parsed.success) return { ok: false, error: "Adresse e-mail invalide." };
  try {
    await db.insert(newsletterSubscribers).values(parsed.data).onConflictDoNothing();
    return { ok: true, message: "Merci ! Vous êtes bien inscrit(e) à notre newsletter." };
  } catch (e) {
    console.error("[newsletter]", e);
    return { ok: false, error: "Une erreur est survenue. Veuillez réessayer." };
  }
}

export async function sendContactMessage(raw: unknown): Promise<ActionResult> {
  const parsed = contactSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Veuillez corriger les champs signalés.",
      fieldErrors: fieldErrors(parsed.error.issues),
    };
  }
  try {
    await db.insert(contactMessages).values(parsed.data);
    return { ok: true, message: "Merci ! Votre message a bien été envoyé. Nous vous répondons très vite." };
  } catch (e) {
    console.error("[contact]", e);
    return { ok: false, error: "Une erreur est survenue. Veuillez réessayer." };
  }
}
