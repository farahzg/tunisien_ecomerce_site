"use server";

import { revalidatePath } from "next/cache";
import { and, eq, gte, inArray, ne, sql } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import {
  categories,
  contactMessages,
  customers,
  deliveryFees,
  orderItems,
  orders,
  productVariants,
  products,
  settings,
} from "@/db/schema";
import { assertAdmin } from "@/lib/auth";
import { slugify } from "@/lib/format";
import { GOVERNORATES } from "@/lib/constants";
import {
  categorySchema,
  customerSchema,
  productSchema,
  statusSchema,
} from "@/lib/validation";

type Res<T = object> = ({ ok: true } & T) | { ok: false; error: string };

function refresh() {
  revalidatePath("/", "layout");
}

function firstIssue(e: z.ZodError) {
  const i = e.issues[0];
  return i ? i.message : "Données invalides";
}

async function uniqueSlug(table: "products" | "categories", base: string, selfId?: number) {
  const root = base || "article";
  let candidate = root;
  for (let n = 2; n < 50; n++) {
    const rows =
      table === "products"
        ? await db
            .select({ id: products.id })
            .from(products)
            .where(selfId ? and(eq(products.slug, candidate), ne(products.id, selfId)) : eq(products.slug, candidate))
        : await db
            .select({ id: categories.id })
            .from(categories)
            .where(selfId ? and(eq(categories.slug, candidate), ne(categories.id, selfId)) : eq(categories.slug, candidate));
    if (rows.length === 0) return candidate;
    candidate = `${root}-${n}`;
  }
  return `${root}-${Date.now()}`;
}

/* ------------------------------ PRODUCTS ------------------------------ */

export async function saveProduct(raw: unknown): Promise<Res<{ id: number }>> {
  await assertAdmin();
  const parsed = productSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  const d = parsed.data;
  const badImg = d.images.find((u) => !/^(\/|https?:\/\/)/.test(u));
  if (badImg) return { ok: false, error: "URL d'image invalide" };
  if (d.comparePrice != null && d.comparePrice <= d.price) d.comparePrice = null;
  const slug = await uniqueSlug("products", slugify(d.slug || d.name), d.id);
  const totalVariantStock = d.variants.reduce((n, v) => n + v.stock, 0);

  try {
    const id = await db.transaction(async (tx) => {
      const values = {
        name: d.name,
        slug,
        shortDescription: d.shortDescription,
        description: d.description,
        price: d.price,
        comparePrice: d.comparePrice,
        categoryId: d.categoryId,
        images: d.images,
        stock: d.variants.length ? totalVariantStock : d.stock,
        sku: d.sku,
        featured: d.featured,
        available: d.available,
        updatedAt: new Date(),
      };
      let productId: number;
      if (d.id) {
        const upd = await tx.update(products).set(values).where(eq(products.id, d.id)).returning({ id: products.id });
        if (!upd.length) throw new Error("Produit introuvable");
        productId = d.id;
      } else {
        const [row] = await tx.insert(products).values(values).returning({ id: products.id });
        productId = row.id;
      }

      const existing = await tx.select({ id: productVariants.id }).from(productVariants).where(eq(productVariants.productId, productId));
      const keepIds = d.variants.filter((v) => v.id).map((v) => v.id!);
      const toDelete = existing.map((e) => e.id).filter((x) => !keepIds.includes(x));
      if (toDelete.length) await tx.delete(productVariants).where(inArray(productVariants.id, toDelete));
      for (let i = 0; i < d.variants.length; i++) {
        const v = d.variants[i];
        const vals = {
          productId,
          optionName: v.optionName,
          value: v.value,
          priceAdjust: v.priceAdjust,
          stock: v.stock,
          sortOrder: i,
        };
        if (v.id && existing.some((e) => e.id === v.id)) {
          await tx.update(productVariants).set(vals).where(eq(productVariants.id, v.id));
        } else {
          await tx.insert(productVariants).values(vals);
        }
      }
      return productId;
    });
    refresh();
    return { ok: true, id };
  } catch (e) {
    console.error("[saveProduct]", e);
    return { ok: false, error: "Impossible d'enregistrer le produit." };
  }
}

export async function deleteProduct(id: number): Promise<Res> {
  await assertAdmin();
  try {
    await db.delete(products).where(eq(products.id, id));
    refresh();
    return { ok: true };
  } catch (e) {
    console.error("[deleteProduct]", e);
    return { ok: false, error: "Suppression impossible." };
  }
}

export async function toggleProductFlag(
  id: number,
  field: "featured" | "available",
  value: boolean,
): Promise<Res> {
  await assertAdmin();
  if (field !== "featured" && field !== "available") return { ok: false, error: "Champ invalide" };
  await db
    .update(products)
    .set({ [field]: value, updatedAt: new Date() })
    .where(eq(products.id, id));
  refresh();
  return { ok: true };
}

export async function updateStock(id: number, stock: number): Promise<Res> {
  await assertAdmin();
  if (!Number.isInteger(stock) || stock < 0 || stock > 100000) return { ok: false, error: "Stock invalide" };
  await db.update(products).set({ stock, updatedAt: new Date() }).where(eq(products.id, id));
  refresh();
  return { ok: true };
}

/* ----------------------------- CATEGORIES ----------------------------- */

export async function saveCategory(raw: unknown): Promise<Res> {
  await assertAdmin();
  const parsed = categorySchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  const d = parsed.data;
  if (d.imageUrl && !/^(\/|https?:\/\/)/.test(d.imageUrl)) return { ok: false, error: "URL d'image invalide" };
  const slug = await uniqueSlug("categories", slugify(d.slug || d.name), d.id);
  const values = { name: d.name, slug, description: d.description, imageUrl: d.imageUrl, sortOrder: d.sortOrder };
  try {
    if (d.id) await db.update(categories).set(values).where(eq(categories.id, d.id));
    else await db.insert(categories).values(values);
    refresh();
    return { ok: true };
  } catch (e) {
    console.error("[saveCategory]", e);
    return { ok: false, error: "Impossible d'enregistrer la catégorie." };
  }
}

export async function deleteCategory(id: number): Promise<Res> {
  await assertAdmin();
  await db.delete(categories).where(eq(categories.id, id));
  refresh();
  return { ok: true };
}

/* ------------------------------- ORDERS ------------------------------- */

export async function updateOrderStatus(id: number, status: string): Promise<Res> {
  await assertAdmin();
  const parsed = statusSchema.safeParse(status);
  if (!parsed.success) return { ok: false, error: "Statut invalide" };
  const next = parsed.data;
  try {
    await db.transaction(async (tx) => {
      const [order] = await tx.select().from(orders).where(eq(orders.id, id));
      if (!order) throw new Error("Commande introuvable");
      if (order.status === next) return;
      const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, id));
      const cancelling = next === "cancelled" && order.status !== "cancelled";
      const reviving = order.status === "cancelled" && next !== "cancelled";
      if (cancelling) {
        for (const it of items) {
          if (it.variantId) {
            await tx.update(productVariants).set({ stock: sql`${productVariants.stock} + ${it.quantity}` }).where(eq(productVariants.id, it.variantId));
          } else if (it.productId) {
            await tx.update(products).set({ stock: sql`${products.stock} + ${it.quantity}` }).where(eq(products.id, it.productId));
          }
        }
      }
      if (reviving) {
        for (const it of items) {
          if (it.variantId) {
            const r = await tx.update(productVariants).set({ stock: sql`${productVariants.stock} - ${it.quantity}` }).where(and(eq(productVariants.id, it.variantId), gte(productVariants.stock, it.quantity))).returning({ id: productVariants.id });
            if (!r.length) throw new Error(`Stock insuffisant pour « ${it.name} »`);
          } else if (it.productId) {
            const r = await tx.update(products).set({ stock: sql`${products.stock} - ${it.quantity}` }).where(and(eq(products.id, it.productId), gte(products.stock, it.quantity))).returning({ id: products.id });
            if (!r.length) throw new Error(`Stock insuffisant pour « ${it.name} »`);
          }
        }
      }
      await tx.update(orders).set({ status: next, updatedAt: new Date() }).where(eq(orders.id, id));
    });
    refresh();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Mise à jour impossible" };
  }
}

export async function updateOrderNotes(id: number, notes: string): Promise<Res> {
  await assertAdmin();
  await db.update(orders).set({ adminNotes: String(notes).slice(0, 1000), updatedAt: new Date() }).where(eq(orders.id, id));
  refresh();
  return { ok: true };
}

/* ------------------------------ CUSTOMERS ----------------------------- */

export async function saveCustomer(raw: unknown): Promise<Res> {
  await assertAdmin();
  const parsed = customerSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  const { id, ...rest } = parsed.data;
  try {
    await db.update(customers).set({ ...rest, updatedAt: new Date() }).where(eq(customers.id, id));
    refresh();
    return { ok: true };
  } catch {
    return { ok: false, error: "Ce numéro de téléphone est déjà utilisé par un autre client." };
  }
}

export async function deleteCustomer(id: number): Promise<Res> {
  await assertAdmin();
  await db.delete(customers).where(eq(customers.id, id));
  refresh();
  return { ok: true };
}

/* ------------------------------ MESSAGES ------------------------------ */

export async function setMessageRead(id: number, read: boolean): Promise<Res> {
  await assertAdmin();
  await db.update(contactMessages).set({ read }).where(eq(contactMessages.id, id));
  revalidatePath("/admin", "layout");
  return { ok: true };
}

export async function deleteMessage(id: number): Promise<Res> {
  await assertAdmin();
  await db.delete(contactMessages).where(eq(contactMessages.id, id));
  revalidatePath("/admin", "layout");
  return { ok: true };
}

/* ------------------------------ SETTINGS ------------------------------ */

const url = z.string().trim().max(300);
const SETTINGS_SCHEMAS = {
  store: z.object({
    name: z.string().trim().min(2).max(80),
    tagline: z.string().trim().max(200),
    email: z.string().trim().max(150).refine((v) => v === "" || z.string().email().safeParse(v).success, "E-mail invalide"),
    phone: z.string().trim().max(30),
    whatsapp: z.string().trim().max(30),
    address: z.string().trim().max(250),
    hours: z.string().trim().max(150),
  }),
  social: z.object({ instagram: url, facebook: url, tiktok: url, pinterest: url }),
  promo: z.object({
    announcementEnabled: z.boolean(),
    announcement: z.string().trim().max(200),
    heroEyebrow: z.string().trim().max(80),
    heroTitle: z.string().trim().min(2).max(140),
    heroSubtitle: z.string().trim().max(400),
    heroCta: z.string().trim().min(1).max(40),
    heroCtaLink: z.string().trim().min(1).max(200),
    heroImage: z.string().trim().min(1).max(300),
    storyTitle: z.string().trim().max(140),
    storyText: z.string().trim().max(1200),
    storyImage: z.string().trim().max(300),
  }),
  delivery: z.object({
    defaultFee: z.number().min(0).max(1000),
    freeThreshold: z.number().min(0).max(100000),
    estimate: z.string().trim().max(80),
  }),
  locations: z.array(z.object({
    name: z.string().trim().min(1).max(100),
    address: z.string().trim().min(1).max(250),
    hours: z.string().trim().max(150),
    phone: z.string().trim().max(30),
  })).max(10),
  collections: z.array(z.object({
    title: z.string().trim().min(1).max(80),
    text: z.string().trim().max(200),
    image: z.string().trim().min(1).max(300),
    href: z.string().trim().max(200),
  })).max(8),
  testimonials: z.array(z.object({
    name: z.string().trim().min(1).max(60),
    city: z.string().trim().max(60),
    text: z.string().trim().min(1).max(400),
    rating: z.number().int().min(1).max(5),
  })).max(12),
};

export async function saveSettings(key: string, value: unknown): Promise<Res> {
  await assertAdmin();
  if (!(key in SETTINGS_SCHEMAS)) return { ok: false, error: "Section inconnue" };
  const schema = SETTINGS_SCHEMAS[key as keyof typeof SETTINGS_SCHEMAS];
  const parsed = schema.safeParse(value);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  await db
    .insert(settings)
    .values({ key, value: parsed.data })
    .onConflictDoUpdate({ target: settings.key, set: { value: parsed.data, updatedAt: new Date() } });
  refresh();
  return { ok: true };
}

export async function saveDeliveryFees(
  rows: { governorate: string; fee: number; active: boolean }[],
): Promise<Res> {
  await assertAdmin();
  const schema = z.array(z.object({
    governorate: z.enum(GOVERNORATES),
    fee: z.number().min(0).max(1000),
    active: z.boolean(),
  }));
  const parsed = schema.safeParse(rows);
  if (!parsed.success) return { ok: false, error: "Frais de livraison invalides" };
  await db.transaction(async (tx) => {
    for (const r of parsed.data) {
      await tx
        .insert(deliveryFees)
        .values(r)
        .onConflictDoUpdate({ target: deliveryFees.governorate, set: { fee: r.fee, active: r.active } });
    }
  });
  refresh();
  return { ok: true };
}
