import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { getAdmin } from "@/lib/auth";
import { LoginForm } from "./LoginForm";
import { Logo } from "@/components/store/Header";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Connexion administrateur",
  robots: { index: false, follow: false },
};

export default async function LoginPage() {
  if (await getAdmin()) redirect("/admin");
  return (
    <div className="pattern-zellige flex min-h-screen items-center justify-center bg-cream/60 p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex justify-center"><Logo /></div>
        <div className="rounded-3xl border border-line bg-white p-8 shadow-xl shadow-clay/5">
          <h1 className="font-display text-3xl font-semibold">Espace administration</h1>
          <p className="mt-1 text-sm text-muted">Connectez-vous pour gérer votre boutique.</p>
          <LoginForm />
        </div>
        <p className="mt-6 text-center text-xs text-muted">Accès réservé à l&apos;équipe ELYSSA ARTISANAT.</p>
      </div>
    </div>
  );
}
