"use client";

import { useActionState } from "react";
import { Loader2 } from "lucide-react";
import { loginAction } from "@/app/actions/auth";
import { input, label } from "@/components/ui/styles";

export function LoginForm() {
  const [state, action, pending] = useActionState(loginAction, undefined);
  return (
    <form action={action} className="mt-6 space-y-5">
      <div>
        <label htmlFor="email" className={label}>Adresse e-mail</label>
        <input id="email" name="email" type="email" required autoComplete="username" className={input} />
      </div>
      <div>
        <label htmlFor="password" className={label}>Mot de passe</label>
        <input id="password" name="password" type="password" required autoComplete="current-password" className={input} />
      </div>
      {state?.error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{state.error}</p>}
      <button disabled={pending} className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-ink px-4 py-3 text-sm font-medium text-ivory transition hover:bg-clay disabled:opacity-60">
        {pending && <Loader2 className="h-4 w-4 animate-spin" />} Se connecter
      </button>
    </form>
  );
}
