import Link from "next/link";
import { and, desc, ilike, or, sql } from "drizzle-orm";
import { Search, Users } from "lucide-react";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { formatDate, formatTND } from "@/lib/format";
import { EmptyState, PageHeader, Pagination } from "@/components/admin/ui";
import { aPrimary, card, input } from "@/components/ui/styles";

export const metadata = { title: "Clients" };
const PAGE_SIZE = 20;

export default async function CustomersPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim();
  const page = Math.max(1, parseInt(sp.page ?? "1") || 1);
  const like = `%${q.replace(/[%_]/g, "")}%`;
  const where = q ? and(or(ilike(customers.fullName, like), ilike(customers.phone, like), ilike(customers.email, like), ilike(customers.city, like))) : undefined;

  const [rows, [{ n }]] = await Promise.all([
    db
      .select({
        id: customers.id,
        fullName: customers.fullName,
        phone: customers.phone,
        email: customers.email,
        governorate: customers.governorate,
        city: customers.city,
        orders: sql<number>`(select count(*) from orders o where o.customer_id = customers.id)::int`,
        spent: sql<number>`(select coalesce(sum(o.total),0) from orders o where o.customer_id = customers.id and o.status <> 'cancelled')::float8`,
        last: sql<Date | null>`(select max(o.created_at) from orders o where o.customer_id = customers.id)`,
      })
      .from(customers)
      .where(where)
      .orderBy(desc(sql`(select max(o.created_at) from orders o where o.customer_id = customers.id)`).append(sql` nulls last`))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db.select({ n: sql<number>`count(*)::int` }).from(customers).where(where),
  ]);
  const pages = Math.max(1, Math.ceil(n / PAGE_SIZE));
  const hrefFor = (p: number) => `/admin/clients?${new URLSearchParams({ ...(q ? { q } : {}), ...(p > 1 ? { page: String(p) } : {}) })}`;

  return (
    <div>
      <PageHeader title="Clients" subtitle={`${n} client${n > 1 ? "s" : ""}`} />
      <form method="get" className={`${card} mb-5 flex flex-wrap items-end gap-3 p-4`}>
        <div className="relative min-w-[240px] flex-1">
          <label htmlFor="q" className="mb-1 block text-xs font-medium text-muted">Recherche</label>
          <Search className="pointer-events-none absolute bottom-3 left-3 h-4 w-4 text-muted" />
          <input id="q" name="q" defaultValue={q} placeholder="Nom, téléphone, e-mail, ville…" className={`${input} pl-9`} />
        </div>
        <button className={aPrimary}>Rechercher</button>
        {q && <Link href="/admin/clients" className="pb-2 text-sm text-clay hover:underline">Réinitialiser</Link>}
      </form>
      <div className={`${card} overflow-hidden`}>
        {rows.length === 0 ? (
          <EmptyState icon={<Users className="h-10 w-10" />} title="Aucun client" text="Les clients sont créés automatiquement à chaque commande." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="border-b border-line bg-cream/50 text-xs uppercase tracking-wider text-muted">
                <tr>
                  <th className="px-4 py-3 font-medium">Client</th>
                  <th className="px-4 py-3 font-medium">Localisation</th>
                  <th className="px-4 py-3 text-center font-medium">Commandes</th>
                  <th className="px-4 py-3 text-right font-medium">Total dépensé</th>
                  <th className="px-4 py-3 font-medium">Dernière commande</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {rows.map((c) => (
                  <tr key={c.id} className="hover:bg-cream/40">
                    <td className="px-4 py-3.5">
                      <Link href={`/admin/clients/${c.id}`} className="font-medium hover:text-clay">{c.fullName}</Link>
                      <p className="text-xs text-muted">{c.phone}{c.email && ` · ${c.email}`}</p>
                    </td>
                    <td className="px-4 py-3.5 text-muted">{[c.city, c.governorate].filter(Boolean).join(", ") || "—"}</td>
                    <td className="px-4 py-3.5 text-center">{c.orders}</td>
                    <td className="whitespace-nowrap px-4 py-3.5 text-right font-semibold">{formatTND(c.spent)}</td>
                    <td className="whitespace-nowrap px-4 py-3.5 text-muted">{c.last ? formatDate(c.last) : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={page} pages={pages} hrefFor={hrefFor} />
      </div>
    </div>
  );
}
