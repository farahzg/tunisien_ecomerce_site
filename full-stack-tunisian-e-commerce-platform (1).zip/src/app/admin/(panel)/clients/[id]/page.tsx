import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { formatDate, formatDateTime, formatTND } from "@/lib/format";
import { CustomerForm } from "@/components/admin/CustomerForm";
import { EmptyState, PageHeader, StatusBadge } from "@/components/admin/ui";
import { card } from "@/components/ui/styles";

export const metadata = { title: "Fiche client" };

export default async function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const cid = Number(id);
  if (!Number.isInteger(cid)) notFound();
  const [c] = await db.select().from(customers).where(eq(customers.id, cid)).limit(1);
  if (!c) notFound();
  const history = await db.select().from(orders).where(eq(orders.customerId, cid)).orderBy(desc(orders.createdAt));
  const spent = history.filter((o) => o.status !== "cancelled").reduce((n, o) => n + o.total, 0);

  return (
    <div>
      <Link href="/admin/clients" className="mb-3 inline-flex items-center gap-1.5 text-sm text-muted hover:text-clay"><ArrowLeft className="h-4 w-4" /> Clients</Link>
      <PageHeader title={c.fullName} subtitle={`Client depuis le ${formatDate(c.createdAt)}`} />
      <div className="mb-6 grid grid-cols-3 gap-4">
        {[["Commandes", String(history.length)], ["Total dépensé", formatTND(spent)], ["Panier moyen", formatTND(history.length ? spent / history.length : 0)]].map(([l, v]) => (
          <div key={l} className={`${card} p-5`}><p className="text-xs text-muted">{l}</p><p className="mt-1 font-display text-2xl font-semibold sm:text-3xl">{v}</p></div>
        ))}
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className={`${card} p-6`}>
          <h2 className="mb-4 font-display text-2xl font-semibold">Informations</h2>
          <CustomerForm customer={{ id: c.id, fullName: c.fullName, phone: c.phone, email: c.email, governorate: c.governorate, city: c.city, address: c.address }} />
        </section>
        <section className={`${card} overflow-hidden`}>
          <h2 className="p-6 pb-3 font-display text-2xl font-semibold">Historique des commandes</h2>
          {history.length === 0 ? <EmptyState title="Aucune commande" /> : (
            <ul className="divide-y divide-line">
              {history.map((o) => (
                <li key={o.id}>
                  <Link href={`/admin/commandes/${o.id}`} className="flex items-center gap-3 px-6 py-3.5 hover:bg-cream/50">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-clay">{o.orderNumber}</p>
                      <p className="text-xs text-muted">{formatDateTime(o.createdAt)}</p>
                    </div>
                    <StatusBadge status={o.status} />
                    <p className="w-24 text-right text-sm font-semibold">{formatTND(o.total)}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
