import Link from "next/link";
import { desc, eq, ne, sql, lte, and, gte } from "drizzle-orm";
import { AlertTriangle, CheckCircle2, Clock, Package, ShoppingCart, TrendingUp, Users, Wallet } from "lucide-react";
import { db } from "@/db";
import { customers, orders, products } from "@/db/schema";
import { LOW_STOCK_THRESHOLD, ORDER_STATUSES } from "@/lib/constants";
import { formatDate, formatTND } from "@/lib/format";
import { soldExpr, stockExpr } from "@/lib/queries";
import { EmptyState, PageHeader, StatusBadge } from "@/components/admin/ui";
import { card } from "@/components/ui/styles";

export const metadata = { title: "Tableau de bord" };

export default async function DashboardPage() {
  const since = new Date(Date.now() - 13 * 24 * 3600 * 1000);
  since.setHours(0, 0, 0, 0);
  const monthAgo = new Date(Date.now() - 30 * 24 * 3600 * 1000);

  const [
    [totals],
    [prodCount],
    [custCount],
    byStatus,
    daily,
    recent,
    lowStock,
    top,
  ] = await Promise.all([
    db
      .select({
        total: sql<number>`count(*)::int`,
        pending: sql<number>`count(*) filter (where ${orders.status} = 'pending')::int`,
        completed: sql<number>`count(*) filter (where ${orders.status} = 'delivered')::int`,
        revenue: sql<number>`coalesce(sum(${orders.total}) filter (where ${orders.status} <> 'cancelled'), 0)::float8`,
        collected: sql<number>`coalesce(sum(${orders.total}) filter (where ${orders.status} = 'delivered'), 0)::float8`,
        month: sql<number>`coalesce(sum(${orders.total}) filter (where ${orders.status} <> 'cancelled' and ${orders.createdAt} >= ${monthAgo}), 0)::float8`,
      })
      .from(orders),
    db.select({ n: sql<number>`count(*)::int` }).from(products),
    db.select({ n: sql<number>`count(*)::int` }).from(customers),
    db.select({ status: orders.status, n: sql<number>`count(*)::int` }).from(orders).groupBy(orders.status),
    db
      .select({
        day: sql<string>`to_char(date_trunc('day', ${orders.createdAt}), 'YYYY-MM-DD')`,
        sum: sql<number>`coalesce(sum(${orders.total}), 0)::float8`,
        n: sql<number>`count(*)::int`,
      })
      .from(orders)
      .where(and(ne(orders.status, "cancelled"), gte(orders.createdAt, since)))
      .groupBy(sql`1`),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(7),
    db
      .select({ id: products.id, name: products.name, image: products.images, stock: stockExpr, available: products.available })
      .from(products)
      .where(lte(stockExpr, LOW_STOCK_THRESHOLD))
      .orderBy(stockExpr)
      .limit(7),
    db
      .select({ id: products.id, name: products.name, sold: soldExpr, price: products.price })
      .from(products)
      .orderBy(desc(soldExpr))
      .limit(5),
  ]);

  // Build last 14 days series
  const map = new Map(daily.map((d) => [d.day, d]));
  const series = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date(since.getTime() + i * 24 * 3600 * 1000);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    return { key, label: d.getDate(), sum: map.get(key)?.sum ?? 0, n: map.get(key)?.n ?? 0 };
  });
  const maxSum = Math.max(1, ...series.map((s) => s.sum));
  const statusCount = Object.fromEntries(byStatus.map((s) => [s.status, s.n]));

  const stats = [
    { label: "Commandes", value: totals.total, Icon: ShoppingCart, href: "/admin/commandes", tone: "bg-sky-50 text-sky-700" },
    { label: "En attente", value: totals.pending, Icon: Clock, href: "/admin/commandes?statut=pending", tone: "bg-amber-50 text-amber-700" },
    { label: "Livrées", value: totals.completed, Icon: CheckCircle2, href: "/admin/commandes?statut=delivered", tone: "bg-emerald-50 text-emerald-700" },
    { label: "Produits", value: prodCount.n, Icon: Package, href: "/admin/produits", tone: "bg-violet-50 text-violet-700" },
  ];

  return (
    <div>
      <PageHeader title="Tableau de bord" subtitle="Vue d'ensemble de votre boutique ELYSSA ARTISANAT" />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map(({ label, value, Icon, href, tone }) => (
          <Link key={label} href={href} className={`${card} p-5 transition hover:-translate-y-0.5 hover:shadow-md`}>
            <span className={`inline-flex h-10 w-10 items-center justify-center rounded-xl ${tone}`}><Icon className="h-5 w-5" /></span>
            <p className="mt-4 font-display text-4xl font-semibold">{value}</p>
            <p className="text-sm text-muted">{label}</p>
          </Link>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <section className={`${card} p-6 lg:col-span-2`}>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl font-semibold">Chiffre d&apos;affaires</h2>
              <p className="text-sm text-muted">14 derniers jours (hors commandes annulées)</p>
            </div>
            <div className="flex gap-6 text-right">
              <div><p className="text-xs text-muted">30 jours</p><p className="font-display text-2xl font-semibold">{formatTND(totals.month)}</p></div>
              <div><p className="text-xs text-muted">Total</p><p className="font-display text-2xl font-semibold text-clay">{formatTND(totals.revenue)}</p></div>
            </div>
          </div>
          <div className="mt-6 flex h-44 items-end gap-1.5 sm:gap-2" role="img" aria-label="Graphique du chiffre d'affaires quotidien">
            {series.map((s) => (
              <div key={s.key} className="group relative flex h-full flex-1 flex-col justify-end">
                <div
                  className="w-full rounded-t-md bg-gradient-to-t from-clay to-beige transition group-hover:from-clay-dark"
                  style={{ height: `${Math.max(s.sum > 0 ? 6 : 2, (s.sum / maxSum) * 100)}%`, opacity: s.sum > 0 ? 1 : 0.25 }}
                />
                <div className="pointer-events-none absolute -top-9 left-1/2 z-10 hidden -translate-x-1/2 whitespace-nowrap rounded-md bg-ink px-2 py-1 text-xs text-ivory group-hover:block">
                  {formatTND(s.sum)} · {s.n} cmd
                </div>
              </div>
            ))}
          </div>
          <div className="mt-2 flex gap-1.5 sm:gap-2">
            {series.map((s) => <span key={s.key} className="flex-1 text-center text-[10px] text-muted">{s.label}</span>)}
          </div>
          <div className="mt-6 grid grid-cols-3 gap-3 border-t border-line pt-5 text-sm">
            <div className="flex items-center gap-2"><Wallet className="h-4 w-4 text-clay" /><div><p className="text-xs text-muted">Encaissé (livrées)</p><p className="font-semibold">{formatTND(totals.collected)}</p></div></div>
            <div className="flex items-center gap-2"><TrendingUp className="h-4 w-4 text-clay" /><div><p className="text-xs text-muted">Panier moyen</p><p className="font-semibold">{formatTND(totals.total ? totals.revenue / Math.max(1, totals.total - (statusCount.cancelled ?? 0)) : 0)}</p></div></div>
            <div className="flex items-center gap-2"><Users className="h-4 w-4 text-clay" /><div><p className="text-xs text-muted">Clients</p><p className="font-semibold">{custCount.n}</p></div></div>
          </div>
        </section>

        <section className={`${card} p-6`}>
          <h2 className="font-display text-2xl font-semibold">Commandes par statut</h2>
          <ul className="mt-4 space-y-3">
            {ORDER_STATUSES.map((s) => {
              const n = statusCount[s.value] ?? 0;
              const pct = totals.total ? (n / totals.total) * 100 : 0;
              return (
                <li key={s.value}>
                  <Link href={`/admin/commandes?statut=${s.value}`} className="block">
                    <div className="mb-1 flex justify-between text-sm"><span>{s.label}</span><span className="font-medium">{n}</span></div>
                    <div className="h-2 overflow-hidden rounded-full bg-cream"><div className="h-full rounded-full bg-clay/80" style={{ width: `${pct}%` }} /></div>
                  </Link>
                </li>
              );
            })}
          </ul>
          <h3 className="mb-3 mt-7 font-display text-xl font-semibold">Meilleures ventes</h3>
          <ul className="space-y-2 text-sm">
            {top.filter((t) => t.sold > 0).length === 0 && <li className="text-muted">Aucune vente pour le moment.</li>}
            {top.filter((t) => t.sold > 0).map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-2">
                <Link href={`/admin/produits/${t.id}`} className="truncate hover:text-clay">{t.name}</Link>
                <span className="shrink-0 rounded-full bg-cream px-2 py-0.5 text-xs">{t.sold} vendu{t.sold > 1 ? "s" : ""}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <section className={`${card} overflow-hidden lg:col-span-3`}>
          <div className="flex items-center justify-between p-6 pb-3">
            <h2 className="font-display text-2xl font-semibold">Commandes récentes</h2>
            <Link href="/admin/commandes" className="text-sm text-clay hover:underline">Tout voir</Link>
          </div>
          {recent.length === 0 ? (
            <EmptyState title="Aucune commande" text="Les commandes de la boutique apparaîtront ici." />
          ) : (
            <ul className="divide-y divide-line">
              {recent.map((o) => (
                <li key={o.id}>
                  <Link href={`/admin/commandes/${o.id}`} className="flex items-center gap-3 px-6 py-3.5 transition hover:bg-cream/50">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{o.customerName}</p>
                      <p className="text-xs text-muted">{o.orderNumber} · {formatDate(o.createdAt)}</p>
                    </div>
                    <StatusBadge status={o.status} />
                    <p className="w-24 text-right text-sm font-semibold">{formatTND(o.total)}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className={`${card} overflow-hidden lg:col-span-2`}>
          <div className="flex items-center gap-2 p-6 pb-3">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <h2 className="font-display text-2xl font-semibold">Stock faible</h2>
          </div>
          {lowStock.length === 0 ? (
            <EmptyState title="Tout est en stock" text="Aucun produit sous le seuil d'alerte." />
          ) : (
            <ul className="divide-y divide-line">
              {lowStock.map((p) => (
                <li key={p.id}>
                  <Link href={`/admin/produits/${p.id}`} className="flex items-center gap-3 px-6 py-3 transition hover:bg-cream/50">
                    <div className="h-11 w-10 shrink-0 overflow-hidden rounded-md bg-cream">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      {p.image[0] && <img src={p.image[0]} alt="" className="h-full w-full object-cover" />}
                    </div>
                    <p className="min-w-0 flex-1 truncate text-sm">{p.name}</p>
                    <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${p.stock <= 0 ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-800"}`}>
                      {p.stock <= 0 ? "Épuisé" : `${p.stock} restant${p.stock > 1 ? "s" : ""}`}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
