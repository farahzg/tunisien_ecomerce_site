import type { Metadata } from "next";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { contactMessages, orders } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { AdminShell } from "@/components/admin/AdminShell";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: { default: "Administration", template: "%s | Admin ELYSSA" },
  robots: { index: false, follow: false },
};

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const admin = await requireAdmin();
  const [[p], [m]] = await Promise.all([
    db.select({ n: sql<number>`count(*)::int` }).from(orders).where(eq(orders.status, "pending")),
    db.select({ n: sql<number>`count(*)::int` }).from(contactMessages).where(eq(contactMessages.read, false)),
  ]);
  return (
    <AdminShell adminName={admin.name} adminEmail={admin.email} pendingOrders={p.n} unreadMessages={m.n}>
      {children}
    </AdminShell>
  );
}
