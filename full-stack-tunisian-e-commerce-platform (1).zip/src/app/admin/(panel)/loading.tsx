export default function Loading() {
  return (
    <div aria-busy="true" aria-label="Chargement">
      <div className="skeleton mb-6 h-9 w-56" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton h-28 rounded-2xl" />)}
      </div>
      <div className="skeleton mt-6 h-72 rounded-2xl" />
    </div>
  );
}
