import { asc, sql } from "drizzle-orm";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { PageHeader } from "@/components/admin/ui";
import { CategoryManager } from "@/components/admin/CategoryManager";

export const metadata = { title: "Catégories" };

export default async function CategoriesPage() {
  const rows = await db
    .select({
      id: categories.id,
      name: categories.name,
      slug: categories.slug,
      description: categories.description,
      imageUrl: categories.imageUrl,
      sortOrder: categories.sortOrder,
      productCount: sql<number>`(select count(*) from products p where p.category_id = categories.id)::int`,
    })
    .from(categories)
    .orderBy(asc(categories.sortOrder), asc(categories.name));
  return (
    <div>
      <PageHeader title="Catégories" subtitle="Organisez votre boutique par univers" />
      <CategoryManager rows={rows} />
    </div>
  );
}
