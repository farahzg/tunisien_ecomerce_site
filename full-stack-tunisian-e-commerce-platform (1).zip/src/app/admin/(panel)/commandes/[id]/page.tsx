import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { ArrowLeft, MapPin, Phone, Mail, User } from "lucide-react";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { formatDateTime, formatTND } from "@/lib/format";
import { OrderStatusSelect } from "@/components/admin/OrderStatusSelect";
import { OrderNotes } from "@/components/admin/OrderNotes";
import { PageHeader } from "@/components/admin/ui";
import { card } from "@/components/ui/styles";

export const metadata = { title: "Détail de la commande" };

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const oid = Number(id);
  if (!Number.isInteger(oid)) notFound();
  const [order] = await db.select().from(orders).where(eq(orders.id, oid)).limit(1);
  if (!order) notFound();
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, oid));

  return (
    <div>
      <Link href="/admin/commandes" className="mb-3 inline-flex items-center gap-1.5 text-sm text-muted hover:text-clay">
        <ArrowLeft className="h-4 w-4" /> Toutes les commandes
      </Link>
      <PageHeader
        title={order.orderNumber}
        subtitle={`Passée le ${formatDateTime(order.createdAt)} · Dernière mise à jour ${formatDateTime(order.updatedAt)}`}
        actions={<OrderStatusSelect orderId={order.id} status={order.status} large />}
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className={`${card} overflow-hidden`}>
            <h2 className="p-6 pb-3 font-display text-2xl font-semibold">Articles ({items.reduce((n, i) => n + i.quantity, 0)})</h2>
            <ul className="divide-y divide-line">
              {items.map((i) => (
                <li key={i.id} className="flex items-center gap-4 px-6 py-4">
                  <div className="h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-cream">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    {i.image && <img src={i.image} alt="" className="h-full w-full object-cover" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    {i.productId ? (
                      <Link href={`/admin/produits/${i.productId}`} className="font-medium hover:text-clay">{i.name}</Link>
                    ) : (
                      <p className="font-medium">{i.name}</p>
                    )}
                    {i.variantLabel && <p className="text-xs text-muted">{i.variantLabel}</p>}
                    <p className="text-xs text-muted">{formatTND(i.price)} × {i.quantity}</p>
                  </div>
                  <p className="font-semibold">{formatTND(i.price * i.quantity)}</p>
                </li>
              ))}
            </ul>
            <dl className="space-y-2 border-t border-line bg-cream/40 p-6 text-sm">
              <div className="flex justify-between"><dt className="text-muted">Sous-total</dt><dd>{formatTND(order.subtotal)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Livraison ({order.governorate})</dt><dd>{order.deliveryFee === 0 ? "Offerte" : formatTND(order.deliveryFee)}</dd></div>
              <div className="flex justify-between border-t border-line pt-3 text-base font-semibold"><dt>Total à encaisser (COD)</dt><dd className="font-display text-2xl">{formatTND(order.total)}</dd></div>
            </dl>
          </section>

          <section className={`${card} p-6`}>
            <h2 className="mb-3 font-display text-2xl font-semibold">Notes internes</h2>
            <OrderNotes orderId={order.id} initial={order.adminNotes} />
          </section>
        </div>

        <div className="space-y-6">
          <section className={`${card} p-6`}>
            <h2 className="mb-4 font-display text-2xl font-semibold">Client</h2>
            <ul className="space-y-3 text-sm">
              <li className="flex gap-3"><User className="mt-0.5 h-4 w-4 text-clay" />
                {order.customerId ? <Link href={`/admin/clients/${order.customerId}`} className="font-medium hover:text-clay">{order.customerName}</Link> : <span className="font-medium">{order.customerName}</span>}
              </li>
              <li className="flex gap-3"><Phone className="mt-0.5 h-4 w-4 text-clay" /><a href={`tel:+216${order.phone}`} className="hover:text-clay">{order.phone}</a></li>
              {order.email && <li className="flex gap-3"><Mail className="mt-0.5 h-4 w-4 text-clay" /><a href={`mailto:${order.email}`} className="break-all hover:text-clay">{order.email}</a></li>}
            </ul>
          </section>
          <section className={`${card} p-6`}>
            <h2 className="mb-4 font-display text-2xl font-semibold">Livraison</h2>
            <p className="flex gap-3 text-sm leading-relaxed"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
              <span>{order.address}<br />{order.city}, {order.governorate}</span>
            </p>
            {order.notes && (
              <div className="mt-4 rounded-lg bg-amber-50 p-3 text-sm text-amber-900">
                <p className="mb-0.5 text-xs font-semibold uppercase tracking-wide">Note du client</p>{order.notes}
              </div>
            )}
          </section>
          <section className={`${card} p-6 text-sm`}>
            <h2 className="mb-3 font-display text-2xl font-semibold">Paiement</h2>
            <p className="text-muted">Paiement à la livraison (espèces)</p>
          </section>
        </div>
      </div>
    </div>
  );
}
