import Link from "next/link";
import { and, desc, eq, gte, ilike, lt, or, sql } from "drizzle-orm";
import { Search, ShoppingCart } from "lucide-react";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { ORDER_STATUSES } from "@/lib/constants";
import { formatDateTime, formatTND } from "@/lib/format";
import { EmptyState, PageHeader, Pagination } from "@/components/admin/ui";
import { OrderStatusSelect } from "@/components/admin/OrderStatusSelect";
import { aPrimary, card, input } from "@/components/ui/styles";

export const metadata = { title: "Commandes" };
const PAGE_SIZE = 15;

type SP = Record<string, string | undefined>;

export default async function OrdersPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim();
  const statut = sp.statut ?? "";
  const from = sp.du ?? "";
  const to = sp.au ?? "";
  const page = Math.max(1, parseInt(sp.page ?? "1") || 1);

  const conds = [];
  if (q) {
    const like = `%${q.replace(/[%_]/g, "")}%`;
    conds.push(or(ilike(orders.orderNumber, like), ilike(orders.customerName, like), ilike(orders.phone, like))!);
  }
  if (ORDER_STATUSES.some((s) => s.value === statut)) conds.push(eq(orders.status, statut));
  if (from && !Number.isNaN(Date.parse(from))) conds.push(gte(orders.createdAt, new Date(from)));
  if (to && !Number.isNaN(Date.parse(to))) conds.push(lt(orders.createdAt, new Date(new Date(to).getTime() + 24 * 3600 * 1000)));
  const where = conds.length ? and(...conds) : undefined;

  const [rows, [{ n }], [sum]] = await Promise.all([
    db.select().from(orders).where(where).orderBy(desc(orders.createdAt)).limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE),
    db.select({ n: sql<number>`count(*)::int` }).from(orders).where(where),
    db.select({ s: sql<number>`coalesce(sum(${orders.total}) filter (where ${orders.status} <> 'cancelled'),0)::float8` }).from(orders).where(where),
  ]);
  const pages = Math.max(1, Math.ceil(n / PAGE_SIZE));
  const hrefFor = (p: number) => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (statut) params.set("statut", statut);
    if (from) params.set("du", from);
    if (to) params.set("au", to);
    if (p > 1) params.set("page", String(p));
    return `/admin/commandes${params.size ? `?${params}` : ""}`;
  };

  return (
    <div>
      <PageHeader title="Commandes" subtitle={`${n} commande${n > 1 ? "s" : ""} · ${formatTND(sum.s)} de chiffre d'affaires`} />

      <form className={`${card} mb-5 flex flex-wrap items-end gap-3 p-4`} method="get">
        <div className="relative min-w-[220px] flex-1">
          <label htmlFor="q" className="mb-1 block text-xs font-medium text-muted">Recherche</label>
          <Search className="pointer-events-none absolute bottom-3 left-3 h-4 w-4 text-muted" />
          <input id="q" name="q" defaultValue={q} placeholder="N° de commande, nom, téléphone…" className={`${input} pl-9`} />
        </div>
        <div>
          <label htmlFor="statut" className="mb-1 block text-xs font-medium text-muted">Statut</label>
          <select id="statut" name="statut" defaultValue={statut} className={input}>
            <option value="">Tous</option>
            {ORDER_STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="du" className="mb-1 block text-xs font-medium text-muted">Du</label>
          <input id="du" type="date" name="du" defaultValue={from} className={input} />
        </div>
        <div>
          <label htmlFor="au" className="mb-1 block text-xs font-medium text-muted">Au</label>
          <input id="au" type="date" name="au" defaultValue={to} className={input} />
        </div>
        <button className={aPrimary}>Filtrer</button>
        {(q || statut || from || to) && <Link href="/admin/commandes" className="pb-2 text-sm text-clay hover:underline">Réinitialiser</Link>}
      </form>

      <div className={`${card} overflow-hidden`}>
        {rows.length === 0 ? (
          <EmptyState icon={<ShoppingCart className="h-10 w-10" />} title="Aucune commande trouvée" text="Modifiez vos filtres ou attendez les prochaines commandes." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="border-b border-line bg-cream/50 text-xs uppercase tracking-wider text-muted">
                <tr>
                  <th className="px-4 py-3 font-medium">Commande</th>
                  <th className="px-4 py-3 font-medium">Client</th>
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3 font-medium">Statut</th>
                  <th className="px-4 py-3 text-right font-medium">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {rows.map((o) => (
                  <tr key={o.id} className="transition hover:bg-cream/40">
                    <td className="px-4 py-3.5">
                      <Link href={`/admin/commandes/${o.id}`} className="font-medium text-clay hover:underline">{o.orderNumber}</Link>
                    </td>
                    <td className="px-4 py-3.5">
                      <p className="font-medium">{o.customerName}</p>
                      <p className="text-xs text-muted">{o.phone} · {o.governorate}</p>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3.5 text-muted">{formatDateTime(o.createdAt)}</td>
                    <td className="px-4 py-3.5"><OrderStatusSelect orderId={o.id} status={o.status} /></td>
                    <td className="whitespace-nowrap px-4 py-3.5 text-right font-semibold">{formatTND(o.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={page} pages={pages} hrefFor={hrefFor} />
      </div>
    </div>
  );
}
