import { getDeliveryFees, getSettings } from "@/lib/settings";
import { PageHeader } from "@/components/admin/ui";
import { SettingsForm } from "@/components/admin/SettingsForm";

export const metadata = { title: "Paramètres" };

export default async function SettingsPage() {
  const [settings, fees] = await Promise.all([getSettings(), getDeliveryFees()]);
  return (
    <div>
      <PageHeader title="Paramètres" subtitle="Informations de la boutique, livraison et contenu de la page d'accueil" />
      <SettingsForm settings={settings} fees={fees} />
    </div>
  );
}
