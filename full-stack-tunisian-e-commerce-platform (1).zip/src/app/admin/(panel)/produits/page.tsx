import Link from "next/link";
import { and, desc, eq, ilike, sql } from "drizzle-orm";
import { Package, Plus, Search } from "lucide-react";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { LOW_STOCK_THRESHOLD } from "@/lib/constants";
import { hasVariantsExpr, stockExpr } from "@/lib/queries";
import { EmptyState, PageHeader, Pagination } from "@/components/admin/ui";
import { ProductsTable } from "@/components/admin/ProductsTable";
import { aPrimary, card, input } from "@/components/ui/styles";

export const metadata = { title: "Produits" };
const PAGE_SIZE = 20;

type SP = Record<string, string | undefined>;

export default async function AdminProductsPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim();
  const cat = sp.categorie ?? "";
  const stock = sp.stock ?? "";
  const page = Math.max(1, parseInt(sp.page ?? "1") || 1);

  const conds = [];
  if (q) conds.push(ilike(products.name, `%${q.replace(/[%_]/g, "")}%`));
  if (cat) conds.push(eq(products.categoryId, Number(cat) || 0));
  if (stock === "low") conds.push(sql`${stockExpr} > 0 and ${stockExpr} <= ${LOW_STOCK_THRESHOLD}`);
  if (stock === "out") conds.push(sql`${stockExpr} <= 0`);
  if (stock === "hidden") conds.push(eq(products.available, false));
  const where = conds.length ? and(...conds) : undefined;

  const [rows, [{ n }], cats] = await Promise.all([
    db
      .select({
        id: products.id,
        name: products.name,
        sku: products.sku,
        images: products.images,
        categoryName: categories.name,
        price: products.price,
        stock: stockExpr,
        featured: products.featured,
        available: products.available,
        hasVariants: hasVariantsExpr,
      })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(where)
      .orderBy(desc(products.createdAt))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db.select({ n: sql<number>`count(*)::int` }).from(products).where(where),
    db.select().from(categories).orderBy(categories.sortOrder),
  ]);
  const pages = Math.max(1, Math.ceil(n / PAGE_SIZE));
  const hrefFor = (p: number) => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (cat) params.set("categorie", cat);
    if (stock) params.set("stock", stock);
    if (p > 1) params.set("page", String(p));
    return `/admin/produits${params.size ? `?${params}` : ""}`;
  };

  return (
    <div>
      <PageHeader
        title="Produits"
        subtitle={`${n} produit${n > 1 ? "s" : ""}`}
        actions={<Link href="/admin/produits/nouveau" className={aPrimary}><Plus className="h-4 w-4" /> Nouveau produit</Link>}
      />
      <form method="get" className={`${card} mb-5 flex flex-wrap items-end gap-3 p-4`}>
        <div className="relative min-w-[220px] flex-1">
          <label htmlFor="q" className="mb-1 block text-xs font-medium text-muted">Recherche</label>
          <Search className="pointer-events-none absolute bottom-3 left-3 h-4 w-4 text-muted" />
          <input id="q" name="q" defaultValue={q} placeholder="Nom du produit…" className={`${input} pl-9`} />
        </div>
        <div>
          <label htmlFor="categorie" className="mb-1 block text-xs font-medium text-muted">Catégorie</label>
          <select id="categorie" name="categorie" defaultValue={cat} className={input}>
            <option value="">Toutes</option>
            {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="stock" className="mb-1 block text-xs font-medium text-muted">Stock</label>
          <select id="stock" name="stock" defaultValue={stock} className={input}>
            <option value="">Tous</option>
            <option value="low">Stock faible</option>
            <option value="out">Épuisés</option>
            <option value="hidden">Indisponibles</option>
          </select>
        </div>
        <button className={aPrimary}>Filtrer</button>
        {(q || cat || stock) && <Link href="/admin/produits" className="pb-2 text-sm text-clay hover:underline">Réinitialiser</Link>}
      </form>

      <div className={`${card} overflow-hidden`}>
        {rows.length === 0 ? (
          <EmptyState
            icon={<Package className="h-10 w-10" />}
            title="Aucun produit"
            text="Ajoutez votre premier produit pour l'afficher sur la boutique."
            action={{ href: "/admin/produits/nouveau", label: "Ajouter un produit" }}
          />
        ) : (
          <ProductsTable rows={rows.map((r) => ({ ...r, image: r.images[0] ?? null }))} />
        )}
        <Pagination page={page} pages={pages} hrefFor={hrefFor} />
      </div>
    </div>
  );
}
