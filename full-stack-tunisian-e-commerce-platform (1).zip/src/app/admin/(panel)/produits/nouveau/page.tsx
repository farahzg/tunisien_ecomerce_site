import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { PageHeader } from "@/components/admin/ui";
import { ProductForm, emptyProduct } from "@/components/admin/ProductForm";

export const metadata = { title: "Nouveau produit" };

export default async function NewProductPage() {
  const cats = await db.select({ id: categories.id, name: categories.name }).from(categories).orderBy(asc(categories.sortOrder));
  return (
    <div>
      <Link href="/admin/produits" className="mb-3 inline-flex items-center gap-1.5 text-sm text-muted hover:text-clay"><ArrowLeft className="h-4 w-4" /> Produits</Link>
      <PageHeader title="Nouveau produit" />
      <ProductForm initial={emptyProduct} categories={cats} />
    </div>
  );
}
