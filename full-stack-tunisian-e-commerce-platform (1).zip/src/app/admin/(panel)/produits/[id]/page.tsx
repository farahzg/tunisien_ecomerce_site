import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, productVariants, products } from "@/db/schema";
import { PageHeader } from "@/components/admin/ui";
import { ProductForm } from "@/components/admin/ProductForm";

export const metadata = { title: "Modifier le produit" };

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const pid = Number(id);
  if (!Number.isInteger(pid)) notFound();
  const [p] = await db.select().from(products).where(eq(products.id, pid)).limit(1);
  if (!p) notFound();
  const [variants, cats] = await Promise.all([
    db.select().from(productVariants).where(eq(productVariants.productId, pid)).orderBy(asc(productVariants.sortOrder), asc(productVariants.id)),
    db.select({ id: categories.id, name: categories.name }).from(categories).orderBy(asc(categories.sortOrder)),
  ]);

  return (
    <div>
      <Link href="/admin/produits" className="mb-3 inline-flex items-center gap-1.5 text-sm text-muted hover:text-clay"><ArrowLeft className="h-4 w-4" /> Produits</Link>
      <PageHeader
        title={p.name}
        actions={p.available ? <Link href={`/produits/${p.slug}`} target="_blank" className="inline-flex items-center gap-2 rounded-lg border border-line bg-white px-4 py-2 text-sm hover:bg-cream"><ExternalLink className="h-4 w-4" /> Voir sur la boutique</Link> : undefined}
      />
      <ProductForm
        categories={cats}
        initial={{
          id: p.id,
          name: p.name,
          slug: p.slug,
          shortDescription: p.shortDescription,
          description: p.description,
          price: String(p.price),
          comparePrice: p.comparePrice != null ? String(p.comparePrice) : "",
          categoryId: p.categoryId ? String(p.categoryId) : "",
          images: p.images,
          stock: String(p.stock),
          sku: p.sku,
          featured: p.featured,
          available: p.available,
          optionName: variants[0]?.optionName ?? "Couleur",
          variants: variants.map((v) => ({ id: v.id, value: v.value, priceAdjust: String(v.priceAdjust), stock: String(v.stock) })),
        }}
      />
    </div>
  );
}
