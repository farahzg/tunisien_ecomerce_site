"use client";

import { aPrimary } from "@/components/ui/styles";

export default function AdminError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="rounded-2xl border border-line bg-white p-12 text-center">
      <h1 className="font-display text-3xl">Une erreur est survenue</h1>
      <p className="mt-2 text-sm text-muted">Impossible de charger cette page. Réessayez.</p>
      <button onClick={reset} className={`${aPrimary} mt-6`}>Réessayer</button>
    </div>
  );
}
