import { desc } from "drizzle-orm";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { PageHeader } from "@/components/admin/ui";
import { MessagesList } from "@/components/admin/MessagesList";

export const metadata = { title: "Messages" };

export default async function MessagesPage() {
  const rows = await db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)).limit(200);
  return (
    <div>
      <PageHeader title="Messages" subtitle="Messages reçus via le formulaire de contact" />
      <MessagesList rows={rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }))} />
    </div>
  );
}
