import { NextResponse } from "next/server";
import { db } from "@/db";
import { media } from "@/db/schema";
import { getAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MAX = 5 * 1024 * 1024;

function sniff(buf: Buffer): string | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "image/jpeg";
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
  if (buf.subarray(0, 4).toString() === "RIFF" && buf.subarray(8, 12).toString() === "WEBP") return "image/webp";
  if (buf.subarray(4, 8).toString() === "ftyp" && /avif|avis/.test(buf.subarray(8, 12).toString())) return "image/avif";
  return null;
}

export async function POST(req: Request) {
  const admin = await getAdmin();
  if (!admin) return NextResponse.json({ error: "Non autorisé" }, { status: 401 });

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Requête invalide" }, { status: 400 });
  }
  const files = form.getAll("files").filter((f): f is File => f instanceof File);
  if (files.length === 0) return NextResponse.json({ error: "Aucun fichier" }, { status: 400 });
  if (files.length > 10) return NextResponse.json({ error: "10 fichiers maximum à la fois" }, { status: 400 });

  const urls: string[] = [];
  for (const file of files) {
    if (file.size > MAX) {
      return NextResponse.json({ error: `« ${file.name} » dépasse 5 Mo` }, { status: 413 });
    }
    const buf = Buffer.from(await file.arrayBuffer());
    const mime = sniff(buf);
    if (!mime) {
      return NextResponse.json({ error: `« ${file.name} » n'est pas une image valide (JPG, PNG, WebP, AVIF)` }, { status: 415 });
    }
    const [row] = await db.insert(media).values({ mime, size: buf.length, data: buf }).returning({ id: media.id });
    urls.push(`/api/media/${row.id}`);
  }
  return NextResponse.json({ urls });
}
