export type StoreSettings = {
  store: {
    name: string;
    tagline: string;
    email: string;
    phone: string;
    whatsapp: string;
    address: string;
    hours: string;
  };
  social: {
    instagram: string;
    facebook: string;
    tiktok: string;
    pinterest: string;
  };
  promo: {
    announcementEnabled: boolean;
    announcement: string;
    heroEyebrow: string;
    heroTitle: string;
    heroSubtitle: string;
    heroCta: string;
    heroCtaLink: string;
    heroImage: string;
    storyTitle: string;
    storyText: string;
    storyImage: string;
  };
  delivery: {
    defaultFee: number;
    freeThreshold: number;
    estimate: string;
  };
  locations: { name: string; address: string; hours: string; phone: string }[];
  collections: { title: string; text: string; image: string; href: string }[];
  testimonials: { name: string; city: string; text: string; rating: number }[];
};

export const DEFAULT_SETTINGS: StoreSettings = {
  store: {
    name: "ELYSSA ARTISANAT",
    tagline: "Concept Store à Tunis — 100 % made in Tunisia",
    email: "contact@elyssa-artisanat.tn",
    phone: "92 944 940",
    whatsapp: "21692944940",
    address: "4 rue Alkissai, Mutuelle Ville, Tunis 1082",
    hours: "10h – 19h, fermé le dimanche",
  },
  social: {
    instagram: "https://www.instagram.com/elyssaartisanat",
    facebook: "https://www.facebook.com/elyssaartisanat",
    tiktok: "",
    pinterest: "",
  },
  promo: {
    announcementEnabled: true,
    announcement:
      "Livraison offerte dès 180 TND · Paiement à la livraison partout en Tunisie",
    heroEyebrow: "Concept Store · Made in Tunisia",
    heroTitle: "L'art de vivre tunisien, façonné à la main",
    heroSubtitle:
      "Bijoux, céramiques, textiles et objets de décoration signés par des artisans et créateurs tunisiens. Des pièces uniques, pensées pour durer et pour être offertes.",
    heroCta: "Découvrir la boutique",
    heroCtaLink: "/boutique",
    heroImage: "/images/hero.jpg",
    storyTitle: "Du geste de l'artisan à votre intérieur",
    storyText:
      "Depuis notre concept store de Tunis, nous réunissons des créateurs, potiers, bijoutiers, couturières et artistes qui font vivre un savoir-faire tunisien contemporain. Chaque pièce est choisie pour son authenticité, la qualité de sa fabrication et l'histoire qu'elle raconte : le cuivre martelé, la grenade émaillée, le poisson peint à la main, la broderie qui s'invite sur une étole.",
    storyImage: "/seed/27605521.jpg",
  },
  delivery: {
    defaultFee: 8,
    freeThreshold: 180,
    estimate: "2 à 5 jours ouvrables",
  },
  locations: [
    {
      name: "Concept Store — Tunis",
      address: "4 rue Alkissai, Mutuelle Ville, Tunis 1082",
      hours: "10h – 19h, fermé le dimanche",
      phone: "92 944 940",
    },
    {
      name: "Elyssa Artisanat — Mahdia",
      address: "Mahdia, Tunisie (retrouvez-nous sur @elyssaartisanatmahdia)",
      hours: "Horaires sur notre page Instagram",
      phone: "92 944 940",
    },
  ],
  collections: [
    {
      title: "Collection Grenade",
      text: "Vases et céramiques émaillés inspirés du fruit symbole d'abondance.",
      image: "/seed/29286721.jpg",
      href: "/boutique?categorie=artisanat",
    },
    {
      title: "Bleu Méditerranée",
      text: "Étoles, châles et foulards aux nuances de la côte.",
      image: "/seed/38537261.jpg",
      href: "/boutique?categorie=mode",
    },
    {
      title: "Table & Café",
      text: "Le cuivre martelé pour un rituel du café tout en élégance.",
      image: "/seed/20122594.jpg",
      href: "/boutique?q=cuivre",
    },
    {
      title: "L'art d'offrir",
      text: "Coffrets et cadeaux uniques, emballés avec soin.",
      image: "/seed/6332412.jpg",
      href: "/boutique?categorie=cadeaux",
    },
  ],
  testimonials: [
    {
      name: "Salma B.",
      city: "La Marsa",
      text: "La cafetière en cuivre est magnifique, encore plus belle qu'en photo. Livraison rapide et colis très soigné. Je recommande les yeux fermés.",
      rating: 5,
    },
    {
      name: "Mehdi K.",
      city: "Sousse",
      text: "J'ai offert un coffret cadeau à ma mère : elle a adoré. Le paiement à la livraison m'a vraiment rassuré, et le service client est très réactif.",
      rating: 5,
    },
    {
      name: "Ines T.",
      city: "Tunis",
      text: "Les coussins peints main apportent une vraie touche d'art dans mon salon. Des pièces uniques qu'on ne trouve nulle part ailleurs.",
      rating: 5,
    },
    {
      name: "Yosra M.",
      city: "Mahdia",
      text: "Le collier plastron est une pièce d'exception. Finitions parfaites, emballage élégant. Merci Elyssa !",
      rating: 4,
    },
  ],
};
