import "server-only";
import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";

const COOKIE = "elyssa_admin_session";
const MAX_AGE = 60 * 60 * 12; // 12 hours

function secret() {
  return (
    process.env.SESSION_SECRET ||
    createHash("sha256")
      .update(`elyssa::${process.env.DATABASE_URL ?? "local"}`)
      .digest("hex")
  );
}

function sign(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export async function createSession(userId: number) {
  const payload = Buffer.from(
    JSON.stringify({ uid: userId, exp: Date.now() + MAX_AGE * 1000 }),
  ).toString("base64url");
  const token = `${payload}.${sign(payload)}`;
  const h = await headers();
  const secure = h.get("x-forwarded-proto") === "https";
  const jar = await cookies();
  jar.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure,
    path: "/",
    maxAge: MAX_AGE,
  });
}

export async function destroySession() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

export const getAdmin = cache(async () => {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString()) as {
      uid: number;
      exp: number;
    };
    if (!data.uid || data.exp < Date.now()) return null;
    const [user] = await db
      .select({ id: adminUsers.id, email: adminUsers.email, name: adminUsers.name })
      .from(adminUsers)
      .where(eq(adminUsers.id, data.uid))
      .limit(1);
    return user ?? null;
  } catch {
    return null;
  }
});

/** For pages/layouts: redirects to the login page when not authenticated. */
export async function requireAdmin() {
  const admin = await getAdmin();
  if (!admin) redirect("/admin/login");
  return admin;
}

/** For server actions / route handlers: throws when not authenticated. */
export async function assertAdmin() {
  const admin = await getAdmin();
  if (!admin) throw new Error("Non autorisé");
  return admin;
}
