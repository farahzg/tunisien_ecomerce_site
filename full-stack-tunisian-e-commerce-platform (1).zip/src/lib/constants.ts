export const GOVERNORATES = [
  "Tunis",
  "Ariana",
  "Ben Arous",
  "Manouba",
  "Nabeul",
  "Zaghouan",
  "Bizerte",
  "Béja",
  "Jendouba",
  "Le Kef",
  "Siliana",
  "Sousse",
  "Monastir",
  "Mahdia",
  "Sfax",
  "Kairouan",
  "Kasserine",
  "Sidi Bouzid",
  "Gabès",
  "Médenine",
  "Tataouine",
  "Gafsa",
  "Tozeur",
  "Kébili",
] as const;

export const DEFAULT_GOVERNORATE_FEES: Record<string, number> = {
  Tunis: 7,
  Ariana: 7,
  "Ben Arous": 7,
  Manouba: 7,
  Nabeul: 8,
  Zaghouan: 8,
  Bizerte: 8,
  Sousse: 8,
  Monastir: 8,
  Mahdia: 8,
  Béja: 9,
  Jendouba: 9,
  "Le Kef": 9,
  Siliana: 9,
  Sfax: 9,
  Kairouan: 9,
  Kasserine: 9,
  "Sidi Bouzid": 9,
  Gabès: 10,
  Médenine: 10,
  Tataouine: 10,
  Gafsa: 10,
  Tozeur: 10,
  Kébili: 10,
};

export const ORDER_STATUSES = [
  { value: "pending", label: "En attente", cls: "bg-amber-100 text-amber-800 ring-amber-200" },
  { value: "confirmed", label: "Confirmée", cls: "bg-sky-100 text-sky-800 ring-sky-200" },
  { value: "processing", label: "En préparation", cls: "bg-indigo-100 text-indigo-800 ring-indigo-200" },
  { value: "shipped", label: "Expédiée", cls: "bg-violet-100 text-violet-800 ring-violet-200" },
  { value: "delivered", label: "Livrée", cls: "bg-emerald-100 text-emerald-800 ring-emerald-200" },
  { value: "cancelled", label: "Annulée", cls: "bg-rose-100 text-rose-800 ring-rose-200" },
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number]["value"];

export const STATUS_VALUES = ORDER_STATUSES.map((s) => s.value) as [
  OrderStatus,
  ...OrderStatus[],
];

export function statusMeta(value: string) {
  return ORDER_STATUSES.find((s) => s.value === value) ?? ORDER_STATUSES[0];
}

export const LOW_STOCK_THRESHOLD = 5;
