import { z } from "zod";
import { GOVERNORATES, STATUS_VALUES } from "./constants";

const phoneRegex = /^[2-9]\d{7}$/;

export const orderSchema = z.object({
  fullName: z.string().trim().min(3, "Veuillez saisir votre nom complet").max(100),
  phone: z
    .string()
    .trim()
    .transform((v) => v.replace(/[\s.-]/g, "").replace(/^(\+216|00216|216)/, ""))
    .refine((v) => phoneRegex.test(v), "Numéro de téléphone tunisien invalide (8 chiffres)"),
  email: z
    .string()
    .trim()
    .max(150)
    .refine((v) => v === "" || z.string().email().safeParse(v).success, "Adresse e-mail invalide"),
  governorate: z.enum(GOVERNORATES, { message: "Veuillez choisir un gouvernorat" }),
  city: z.string().trim().min(2, "Veuillez saisir votre ville").max(100),
  address: z.string().trim().min(8, "Veuillez saisir votre adresse complète").max(300),
  notes: z.string().trim().max(500).default(""),
  items: z
    .array(
      z.object({
        productId: z.number().int().positive(),
        variantId: z.number().int().positive().nullable(),
        quantity: z.number().int().min(1).max(50),
      }),
    )
    .min(1, "Votre panier est vide")
    .max(50),
});
export type OrderInput = z.input<typeof orderSchema>;

export const contactSchema = z.object({
  name: z.string().trim().min(2, "Veuillez saisir votre nom").max(100),
  email: z
    .string()
    .trim()
    .max(150)
    .refine((v) => v === "" || z.string().email().safeParse(v).success, "Adresse e-mail invalide"),
  phone: z.string().trim().max(30).default(""),
  message: z.string().trim().min(10, "Votre message est trop court").max(2000),
});

export const newsletterSchema = z.object({
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide").max(150),
});

export const productSchema = z.object({
  id: z.number().int().positive().optional(),
  name: z.string().trim().min(2, "Nom requis").max(150),
  slug: z.string().trim().max(120).default(""),
  shortDescription: z.string().trim().max(240).default(""),
  description: z.string().trim().max(5000).default(""),
  price: z.number().min(0, "Prix invalide").max(1_000_000),
  comparePrice: z.number().min(0).max(1_000_000).nullable(),
  categoryId: z.number().int().positive().nullable(),
  images: z.array(z.string().trim().min(1).max(500)).max(12),
  stock: z.number().int().min(0).max(100000),
  sku: z.string().trim().max(60).default(""),
  featured: z.boolean(),
  available: z.boolean(),
  variants: z
    .array(
      z.object({
        id: z.number().int().positive().optional(),
        optionName: z.string().trim().min(1).max(40),
        value: z.string().trim().min(1, "Valeur de variante requise").max(60),
        priceAdjust: z.number().min(-100000).max(100000),
        stock: z.number().int().min(0).max(100000),
      }),
    )
    .max(30),
});
export type ProductInput = z.infer<typeof productSchema>;

export const categorySchema = z.object({
  id: z.number().int().positive().optional(),
  name: z.string().trim().min(2, "Nom requis").max(80),
  slug: z.string().trim().max(80).default(""),
  description: z.string().trim().max(400).default(""),
  imageUrl: z.string().trim().max(500).default(""),
  sortOrder: z.number().int().min(0).max(1000).default(0),
});

export const statusSchema = z.enum(STATUS_VALUES);

export const customerSchema = z.object({
  id: z.number().int().positive(),
  fullName: z.string().trim().min(2).max(100),
  phone: z
    .string()
    .trim()
    .transform((v) => v.replace(/[\s.-]/g, "").replace(/^(\+216|00216|216)/, ""))
    .refine((v) => phoneRegex.test(v), "Numéro de téléphone invalide"),
  email: z
    .string()
    .trim()
    .refine((v) => v === "" || z.string().email().safeParse(v).success, "Adresse e-mail invalide"),
  governorate: z.string().trim().max(60),
  city: z.string().trim().max(100),
  address: z.string().trim().max(300),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1).max(200),
});
