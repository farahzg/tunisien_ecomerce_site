import "server-only";
import { cache } from "react";
import { db } from "@/db";
import { deliveryFees, settings } from "@/db/schema";
import { DEFAULT_SETTINGS, type StoreSettings } from "./settings-defaults";
import { DEFAULT_GOVERNORATE_FEES, GOVERNORATES } from "./constants";

export const getSettings = cache(async (): Promise<StoreSettings> => {
  const out = structuredClone(DEFAULT_SETTINGS) as Record<string, unknown>;
  try {
    const rows = await db.select().from(settings);
    for (const row of rows) {
      if (!(row.key in out)) continue;
      const base = out[row.key];
      if (Array.isArray(base)) {
        if (Array.isArray(row.value)) out[row.key] = row.value;
      } else if (row.value && typeof row.value === "object") {
        out[row.key] = { ...(base as object), ...(row.value as object) };
      }
    }
  } catch (e) {
    console.error("[settings] unable to load", e);
  }
  return out as StoreSettings;
});

export type DeliveryRow = { governorate: string; fee: number; active: boolean };

export const getDeliveryFees = cache(async (): Promise<DeliveryRow[]> => {
  let rows: DeliveryRow[] = [];
  try {
    rows = await db.select().from(deliveryFees);
  } catch (e) {
    console.error("[delivery] unable to load", e);
  }
  const map = new Map(rows.map((r) => [r.governorate, r]));
  return GOVERNORATES.map(
    (g) =>
      map.get(g) ?? {
        governorate: g,
        fee: DEFAULT_GOVERNORATE_FEES[g] ?? DEFAULT_SETTINGS.delivery.defaultFee,
        active: true,
      },
  );
});

export function computeDelivery(
  governorate: string,
  subtotal: number,
  s: StoreSettings,
  fees: DeliveryRow[],
) {
  const row = fees.find((f) => f.governorate === governorate);
  const base = row ? row.fee : s.delivery.defaultFee;
  const free = s.delivery.freeThreshold > 0 && subtotal >= s.delivery.freeThreshold;
  return free ? 0 : base;
}
