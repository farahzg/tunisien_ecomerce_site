function group(intPart: string) {
  return intPart.replace(/\B(?=(\d{3})+(?!\d))/g, "\u202f");
}

/** Formats a number as TND (e.g. "89 TND", "89,50 TND", "1 240 TND"). */
export function formatTND(value: number | string | null | undefined) {
  const n = Number(value ?? 0);
  const rounded = Math.round(n * 1000) / 1000;
  const [i, d] = (Number.isInteger(rounded)
    ? rounded.toFixed(0)
    : rounded.toFixed(rounded * 100 === Math.round(rounded * 100) ? 2 : 3)
  ).split(".");
  return `${group(i)}${d ? "," + d : ""}\u00a0TND`;
}

const MONTHS = [
  "janv.", "févr.", "mars", "avr.", "mai", "juin",
  "juil.", "août", "sept.", "oct.", "nov.", "déc.",
];

function p2(n: number) {
  return String(n).padStart(2, "0");
}

export function formatDate(d: Date | string | number) {
  const date = new Date(d);
  return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

export function formatDateTime(d: Date | string | number) {
  const date = new Date(d);
  return `${formatDate(date)} à ${p2(date.getHours())}:${p2(date.getMinutes())}`;
}

export function slugify(input: string) {
  return input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export function normalizePhone(raw: string) {
  const digits = raw.replace(/[^\d+]/g, "");
  return digits.replace(/^(\+216|00216|216)/, "");
}

export function plural(n: number, one: string, many: string) {
  return n > 1 ? many : one;
}
