import "server-only";
import { and, asc, desc, eq, gte, ilike, lte, ne, or, sql, count } from "drizzle-orm";
import { db } from "@/db";
import { categories, productVariants, products } from "@/db/schema";

// Effective stock: sum of variant stock when variants exist, otherwise product stock.
export const stockExpr = sql<number>`(case when exists (select 1 from product_variants pv where pv.product_id = products.id) then (select coalesce(sum(pv.stock),0) from product_variants pv where pv.product_id = products.id) else products.stock end)::int`;

export const soldExpr = sql<number>`(select coalesce(sum(oi.quantity),0) from order_items oi join orders o on o.id = oi.order_id where oi.product_id = products.id and o.status <> 'cancelled')::int`;

export const hasVariantsExpr = sql<boolean>`exists (select 1 from product_variants pv where pv.product_id = products.id)`;

export type ProductCardData = {
  id: number;
  name: string;
  slug: string;
  shortDescription: string;
  price: number;
  comparePrice: number | null;
  images: string[];
  featured: boolean;
  available: boolean;
  createdAt: Date;
  categoryName: string | null;
  categorySlug: string | null;
  stock: number;
  sold: number;
  hasVariants: boolean;
};

const cardSelect = {
  id: products.id,
  name: products.name,
  slug: products.slug,
  shortDescription: products.shortDescription,
  price: products.price,
  comparePrice: products.comparePrice,
  images: products.images,
  featured: products.featured,
  available: products.available,
  createdAt: products.createdAt,
  categoryName: categories.name,
  categorySlug: categories.slug,
  stock: stockExpr,
  sold: soldExpr,
  hasVariants: hasVariantsExpr,
};

export const SORTS = [
  { value: "nouveautes", label: "Nouveautés" },
  { value: "populaires", label: "Meilleures ventes" },
  { value: "prix-asc", label: "Prix croissant" },
  { value: "prix-desc", label: "Prix décroissant" },
  { value: "nom", label: "Nom (A–Z)" },
] as const;

export type ListOpts = {
  q?: string;
  category?: string;
  sort?: string;
  min?: number;
  max?: number;
  inStock?: boolean;
  featured?: boolean;
  limit?: number;
  offset?: number;
};

export async function listProducts(opts: ListOpts = {}) {
  const conds = [eq(products.available, true)];
  if (opts.q) {
    const like = `%${opts.q.replace(/[%_]/g, "")}%`;
    conds.push(or(ilike(products.name, like), ilike(products.description, like))!);
  }
  if (opts.category) conds.push(eq(categories.slug, opts.category));
  if (opts.min != null && !Number.isNaN(opts.min)) conds.push(gte(products.price, opts.min));
  if (opts.max != null && !Number.isNaN(opts.max)) conds.push(lte(products.price, opts.max));
  if (opts.featured) conds.push(eq(products.featured, true));
  if (opts.inStock) conds.push(sql`${stockExpr} > 0`);
  const where = and(...conds);

  const order =
    opts.sort === "prix-asc"
      ? [asc(products.price)]
      : opts.sort === "prix-desc"
        ? [desc(products.price)]
        : opts.sort === "nom"
          ? [asc(products.name)]
          : opts.sort === "populaires"
            ? [desc(soldExpr), desc(products.featured), desc(products.createdAt)]
            : [desc(products.createdAt), desc(products.id)];

  const [items, totalRow] = await Promise.all([
    db
      .select(cardSelect)
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(where)
      .orderBy(...order)
      .limit(opts.limit ?? 12)
      .offset(opts.offset ?? 0),
    db
      .select({ n: count() })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(where),
  ]);
  return { items: items as ProductCardData[], total: totalRow[0]?.n ?? 0 };
}

export async function getCategories() {
  return db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.name));
}

export async function getCategoriesWithCounts() {
  return db
    .select({
      id: categories.id,
      name: categories.name,
      slug: categories.slug,
      description: categories.description,
      imageUrl: categories.imageUrl,
      count: sql<number>`(select count(*) from products p where p.category_id = categories.id and p.available = true)::int`,
    })
    .from(categories)
    .orderBy(asc(categories.sortOrder), asc(categories.name));
}

export async function getProductBySlug(slug: string) {
  const [row] = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      shortDescription: products.shortDescription,
      description: products.description,
      price: products.price,
      comparePrice: products.comparePrice,
      images: products.images,
      sku: products.sku,
      featured: products.featured,
      available: products.available,
      categoryId: products.categoryId,
      categoryName: categories.name,
      categorySlug: categories.slug,
      stock: stockExpr,
      hasVariants: hasVariantsExpr,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.slug, slug))
    .limit(1);
  if (!row || !row.available) return null;
  const variants = await db
    .select()
    .from(productVariants)
    .where(eq(productVariants.productId, row.id))
    .orderBy(asc(productVariants.sortOrder), asc(productVariants.id));
  return { ...row, variants };
}

export async function getRelatedProducts(categoryId: number | null, excludeId: number) {
  const conds = [eq(products.available, true), ne(products.id, excludeId)];
  if (categoryId) conds.push(eq(products.categoryId, categoryId));
  const rows = await db
    .select(cardSelect)
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(and(...conds))
    .orderBy(desc(products.featured), desc(products.createdAt))
    .limit(4);
  return rows as ProductCardData[];
}
