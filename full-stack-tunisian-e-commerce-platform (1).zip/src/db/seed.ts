import { eq, sql } from "drizzle-orm";
import { db } from "./index";
import {
  adminUsers,
  categories,
  customers,
  deliveryFees,
  orderItems,
  orders,
  productVariants,
  products,
  settings,
} from "./schema";
import { hashPassword } from "@/lib/password";
import { DEFAULT_SETTINGS } from "@/lib/settings-defaults";
import { DEFAULT_GOVERNORATE_FEES, GOVERNORATES } from "@/lib/constants";

const img = (id: number) => `/seed/${id}.jpg`;

const CATEGORIES = [
  {
    name: "Artisanat",
    slug: "artisanat",
    description: "Cuivre martelé, céramiques émaillées et objets façonnés à la main.",
    imageUrl: img(29286721),
  },
  {
    name: "Bijoux & Accessoires",
    slug: "bijoux",
    description: "Colliers, sautoirs et accessoires de créateurs tunisiens.",
    imageUrl: img(17368721),
  },
  {
    name: "Décoration",
    slug: "decoration",
    description: "Coussins peints main, paniers tressés et touches d'art pour la maison.",
    imageUrl: img(33354742),
  },
  {
    name: "Mode",
    slug: "mode",
    description: "Étoles, châles et foulards brodés, tissés et imprimés.",
    imageUrl: img(38537257),
  },
  {
    name: "Cadeaux uniques",
    slug: "cadeaux",
    description: "Coffrets et idées cadeaux emballés avec soin.",
    imageUrl: img(6332412),
  },
];

type SeedProduct = {
  name: string;
  cat: string;
  price: number;
  compare?: number;
  imgs: number[];
  stock: number;
  featured?: boolean;
  short: string;
  desc: string;
  variants?: { opt: string; items: [string, number, number][] };
};

const PRODUCTS: SeedProduct[] = [
  {
    name: "Cafetière en cuivre martelé",
    cat: "artisanat",
    price: 89,
    imgs: [20122594, 20122613],
    stock: 0,
    featured: true,
    short: "L'ibrik traditionnel en cuivre, martelé à la main.",
    desc: "Façonnée par un maître chaudronnier, cette cafetière en cuivre martelé sublime le rituel du café turc. Anse en bois, intérieur étamé, finition patinée naturelle. Une pièce à exposer autant qu'à utiliser.",
    variants: {
      opt: "Contenance",
      items: [["2 tasses", 0, 8], ["4 tasses", 20, 6]],
    },
  },
  {
    name: "Vase grenade en céramique émaillée",
    cat: "artisanat",
    price: 120,
    compare: 140,
    imgs: [29286721, 8063852],
    stock: 0,
    featured: true,
    short: "La grenade, symbole d'abondance, en émail brillant.",
    desc: "Vase sculptural en forme de grenade, tourné et émaillé à la main dans un atelier tunisien. L'émail profond capte la lumière et change de nuance selon l'heure. Étanche, il accueille fleurs séchées ou branches.",
    variants: {
      opt: "Couleur",
      items: [["Vert olive", 0, 7], ["Rouge grenat", 0, 5], ["Blanc cassé", 0, 4]],
    },
  },
  {
    name: "Plateau en cuivre gravé",
    cat: "artisanat",
    price: 145,
    imgs: [23159397],
    stock: 6,
    short: "Plateau de service aux gravures géométriques.",
    desc: "Plateau rond en cuivre, gravé à la main de motifs géométriques inspirés de l'architecture de la médina. Idéal pour le service du thé ou du café. Diamètre : 35 cm.",
  },
  {
    name: "Pots en céramique peinte main",
    cat: "artisanat",
    price: 98,
    imgs: [8063852, 29286721],
    stock: 10,
    short: "Trio de pots aux couleurs de la Méditerranée.",
    desc: "Série de trois pots en céramique, peints à la main un par un : aucun n'est identique. Parfaits pour vos plantes aromatiques, vos pinceaux ou en objet décoratif.",
  },
  {
    name: "Cafetières ciselées suspendues",
    cat: "artisanat",
    price: 65,
    imgs: [9939081],
    stock: 3,
    short: "Métal ciselé aux motifs ornementaux.",
    desc: "Petites cafetières décoratives en métal ciselé, à suspendre ou à poser. Elles apportent une note orientale et chaleureuse à votre cuisine ou votre salon.",
  },
  {
    name: "Coupe sur pied en métal martelé",
    cat: "artisanat",
    price: 76,
    imgs: [30190819],
    stock: 9,
    short: "Une coupe élégante pour la table ou l'entrée.",
    desc: "Coupe sur pied en métal martelé à la main, au reflet argenté. Elle accueille fruits, olives ou petits objets et se fond dans les intérieurs les plus épurés.",
  },
  {
    name: "Collier ras-du-cou doré et perles",
    cat: "bijoux",
    price: 185,
    imgs: [17368721, 4735935],
    stock: 5,
    featured: true,
    short: "Collier rigide doré orné de perles et de pierres.",
    desc: "Pièce signature réalisée à la main : un jonc rigide plaqué or accueille un pendentif sculptural de perles baroques, nacre et pierres fines. Un bijou d'exception, comme une petite œuvre d'art à porter.",
  },
  {
    name: "Collier de perles en céramique émaillée",
    cat: "bijoux",
    price: 135,
    imgs: [40839146],
    stock: 8,
    short: "Grosses perles vert profond et médaillon doré.",
    desc: "Collier sautoir composé de perles en céramique émaillée vert forêt, rehaussées de perles peintes et d'un médaillon texturé doré. Léger et très graphique.",
  },
  {
    name: "Collier plastron aux pièces dorées",
    cat: "bijoux",
    price: 240,
    imgs: [15272716],
    stock: 4,
    featured: true,
    short: "Plastron inspiré des parures traditionnelles.",
    desc: "Grand collier plastron revisité : pièces dorées, perles rouges et ornements ciselés. Il habille une tenue sobre et s'impose comme la pièce centrale de votre look de fête.",
  },
  {
    name: "Sautoir de perles peintes main",
    cat: "bijoux",
    price: 110,
    imgs: [20003440],
    stock: 11,
    short: "Perles multicolores aux motifs géométriques.",
    desc: "Sautoir de perles en bois peintes à la main de motifs colorés. Chaque collier est légèrement différent, preuve de son origine artisanale.",
  },
  {
    name: "Colliers dorés fins superposables",
    cat: "bijoux",
    price: 78,
    imgs: [34734540],
    stock: 14,
    short: "Chaînes délicates à porter seules ou en rang.",
    desc: "Une sélection de chaînes fines et de pendentifs délicats, à superposer selon vos envies. Plaqué or 18 carats, hypoallergénique.",
    variants: {
      opt: "Finition",
      items: [["Doré", 0, 8], ["Argenté", 0, 6]],
    },
  },
  {
    name: "Cabas en paille brodé",
    cat: "bijoux",
    price: 68,
    imgs: [16063786, 37651104],
    stock: 0,
    featured: true,
    short: "Le cabas d'été tressé main, orné d'un cœur bleu.",
    desc: "Cabas en paille tressée à la main, doublé de coton et orné d'une broderie. Anses solides, grande contenance : on l'emporte à la plage comme au marché.",
    variants: {
      opt: "Couleur",
      items: [["Naturel", 0, 6], ["Vert menthe", 0, 4], ["Bleu", 0, 5]],
    },
  },
  {
    name: "Coussin peint main « Poissons »",
    cat: "decoration",
    price: 85,
    imgs: [33354742, 37903770],
    stock: 0,
    featured: true,
    short: "Un coussin-tableau aux motifs colorés peints à la main.",
    desc: "Coussin en coton épais, peint à la main de motifs de poissons et de rayures multicolores, passepoil noir. Déhoussable, livré avec sa garniture. Pièce unique : les motifs varient légèrement.",
    variants: {
      opt: "Format",
      items: [["30 × 50 cm", 0, 7], ["45 × 45 cm", 15, 5]],
    },
  },
  {
    name: "Lot de 2 coussins en lin",
    cat: "decoration",
    price: 95,
    imgs: [8762877],
    stock: 12,
    short: "Lin lavé aux teintes naturelles.",
    desc: "Deux coussins en lin lavé, doux et texturé, dans des tons sable et terre. Fermeture invisible, garnissage généreux.",
  },
  {
    name: "Coussins aux motifs botaniques",
    cat: "decoration",
    price: 72,
    compare: 90,
    imgs: [7885120],
    stock: 9,
    short: "Imprimés végétaux pour un salon lumineux.",
    desc: "Coussins aux imprimés botaniques délicats, parfaits pour réveiller un canapé neutre. Housse déhoussable en coton.",
  },
  {
    name: "Paniers tressés décoratifs",
    cat: "decoration",
    price: 58,
    imgs: [8356222, 20385476],
    stock: 15,
    short: "Paniers en fibres naturelles, tressés à la main.",
    desc: "Paniers en fibres végétales tressées, polyvalents : rangement, cache-pot ou décoration murale. Chaque pièce est unique.",
  },
  {
    name: "Série de coussins pastel",
    cat: "decoration",
    price: 64,
    imgs: [8416318],
    stock: 2,
    short: "Trois nuances douces pour un coin lecture.",
    desc: "Trio de coussins en teintes pastel (vert, bleu, rose) pour composer un coin cocooning. Matière douce, coutures soignées.",
  },
  {
    name: "Étole brodée à franges",
    cat: "mode",
    price: 160,
    imgs: [38537257, 38537261],
    stock: 0,
    featured: true,
    short: "Étole fluide ornée de calligraphie dorée et de franges.",
    desc: "Étole en voile de coton doux, ornée de broderies calligraphiques dorées et de longues franges nouées à la main. Elle s'enroule en écharpe, se drape en châle, ou s'accroche sur une robe de soirée.",
    variants: {
      opt: "Couleur",
      items: [["Noir", 0, 6], ["Bleu pétrole", 0, 5], ["Ivoire", 0, 3]],
    },
  },
  {
    name: "Châle en soie imprimé paisley",
    cat: "mode",
    price: 120,
    imgs: [33595151],
    stock: 7,
    short: "Soie mélangée aux motifs cachemire.",
    desc: "Grand châle en soie mélangée au toucher fluide, imprimé de motifs paisley. Léger, il se glisse dans un sac et réchauffe les soirées d'été.",
  },
  {
    name: "Foulard coloré à motifs",
    cat: "mode",
    price: 55,
    imgs: [37840926],
    stock: 18,
    short: "Un carré de couleur pour toutes les occasions.",
    desc: "Foulard carré aux couleurs vives, à nouer dans les cheveux, au cou ou sur un sac. Coton léger.",
  },
  {
    name: "Châle brodé traditionnel",
    cat: "mode",
    price: 175,
    imgs: [19783300],
    stock: 0,
    short: "Châle brodé main, inspiré des tenues de cérémonie.",
    desc: "Châle brodé main, inspiré des tenues de cérémonie tunisiennes. Pièce de collection – actuellement épuisée, de nouveaux exemplaires arrivent bientôt.",
  },
  {
    name: "Cabas de plage en paille",
    cat: "mode",
    price: 62,
    imgs: [5591748],
    stock: 13,
    short: "Le compagnon des journées au bord de l'eau.",
    desc: "Sac de plage en paille tressée, léger et solide. Fermeture par bouton-pression, poche intérieure zippée.",
  },
  {
    name: "Coffret cadeau artisanal",
    cat: "cadeaux",
    price: 130,
    imgs: [6332412, 34972177],
    stock: 12,
    featured: true,
    short: "Une sélection de créateurs, prête à offrir.",
    desc: "Coffret composé par notre équipe : une bougie parfumée, une pièce en céramique et une douceur locale, emballés dans du papier kraft et un ruban doré. Carte de vœux personnalisable à la commande (notes de livraison).",
  },
  {
    name: "Coffret « Douceur »",
    cat: "cadeaux",
    price: 95,
    imgs: [5486833],
    stock: 16,
    short: "Un petit coffret délicat pour les attentions.",
    desc: "Petit coffret ruban velours : idéal pour une attention, un anniversaire ou un remerciement. Contenu artisanal 100 % tunisien.",
  },
  {
    name: "Pack cadeaux emballés (lot de 3)",
    cat: "cadeaux",
    price: 45,
    imgs: [5876727],
    stock: 20,
    short: "Trois petites boîtes ficelées main.",
    desc: "Lot de trois boîtes cadeaux en carton kraft, ficelées à la main et ornées de cartes. Idéal pour les fêtes et les mariages.",
  },
  {
    name: "Boîte cadeau rose ruban",
    cat: "cadeaux",
    price: 38,
    imgs: [4913759],
    stock: 1,
    short: "Petite boîte cadeau au ruban violet.",
    desc: "Petite boîte cadeau tendre, avec ruban en satin. À garnir d'un bijou ou d'un mot doux.",
  },
];

const CUSTOMERS = [
  ["Salma Ben Youssef", "98123456", "salma.by@example.com", "Tunis", "La Marsa", "12 rue des Jasmins, La Marsa"],
  ["Mehdi Kharrat", "22334455", "", "Sousse", "Sousse Médina", "5 avenue Habib Bourguiba"],
  ["Ines Trabelsi", "55667788", "ines.trabelsi@example.com", "Tunis", "Mutuelle Ville", "8 rue de Marseille"],
  ["Yosra Mansouri", "29887766", "", "Mahdia", "Mahdia", "Rue de la Corniche, résidence Les Pins"],
  ["Karim Bouazizi", "50112233", "karim.b@example.com", "Sfax", "Sfax Ville", "Avenue Hedi Chaker, immeuble B"],
  ["Rim Chaabane", "96554433", "", "Ariana", "Ennasr", "Cité Ennasr 2, rue 5"],
  ["Amine Jlassi", "21009988", "amine.jlassi@example.com", "Nabeul", "Hammamet", "Rue des Orangers, Hammamet Nord"],
  ["Hela Mejri", "54778899", "", "Monastir", "Monastir", "Boulevard de l'Environnement"],
  ["Nour Gharbi", "93221100", "nour.g@example.com", "Ben Arous", "Mégrine", "Rue Ibn Khaldoun"],
  ["Fatma Zouari", "24556677", "", "Bizerte", "Bizerte Ville", "Rue du Port, appartement 4"],
];

const STATUS_PLAN = [
  "pending", "pending", "pending", "confirmed", "confirmed", "processing",
  "shipped", "shipped", "delivered", "delivered", "delivered", "delivered",
  "delivered", "delivered", "delivered", "cancelled",
];

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function orderNumber(d: Date, seed: number) {
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  let s = "";
  let x = seed * 7919 + 13;
  for (let i = 0; i < 5; i++) {
    x = (x * 1103515245 + 12345) & 0x7fffffff;
    s += ALPHABET[x % ALPHABET.length];
  }
  return `ELY-${yy}${mm}${dd}-${s}`;
}

export async function seedIfEmpty() {
  // 1. Admin account (idempotent)
  const [{ n: adminCount }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(adminUsers);
  if (adminCount === 0) {
    const email = (process.env.ADMIN_EMAIL || "admin@elyssa-artisanat.tn").toLowerCase();
    const password = process.env.ADMIN_PASSWORD || "Elyssa@2025";
    await db.insert(adminUsers).values({
      email,
      name: "Administrateur",
      passwordHash: hashPassword(password),
    });
    console.log(`[seed] admin account created (${email})`);
  }

  // 2. Settings + delivery fees (never overwrite)
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await db.insert(settings).values({ key, value }).onConflictDoNothing();
  }
  await db
    .insert(deliveryFees)
    .values(
      GOVERNORATES.map((g) => ({
        governorate: g,
        fee: DEFAULT_GOVERNORATE_FEES[g] ?? 8,
        active: true,
      })),
    )
    .onConflictDoNothing();

  // 3. Demo catalogue — only once
  const [flag] = await db.select().from(settings).where(eq(settings.key, "seeded"));
  if (flag) return;
  const [{ n: productCount }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(products);
  if (productCount > 0) {
    await db.insert(settings).values({ key: "seeded", value: true }).onConflictDoNothing();
    return;
  }

  const cats = await db
    .insert(categories)
    .values(CATEGORIES.map((c, i) => ({ ...c, sortOrder: i })))
    .returning();
  const catId = Object.fromEntries(cats.map((c) => [c.slug, c.id]));

  const now = Date.now();
  const createdProducts: {
    id: number;
    name: string;
    price: number;
    image: string;
    variants: { id: number; value: string; adjust: number }[];
  }[] = [];

  for (let i = 0; i < PRODUCTS.length; i++) {
    const p = PRODUCTS[i];
    const slug = p.name
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
    const [row] = await db
      .insert(products)
      .values({
        name: p.name,
        slug,
        shortDescription: p.short,
        description: p.desc,
        price: p.price,
        comparePrice: p.compare ?? null,
        categoryId: catId[p.cat],
        images: p.imgs.map(img),
        stock: p.variants ? 0 : p.stock,
        sku: `ELY-${String(i + 1).padStart(3, "0")}`,
        featured: !!p.featured,
        available: true,
        createdAt: new Date(now - (PRODUCTS.length - i) * 36 * 3600 * 1000),
      })
      .returning();
    let vrows: { id: number; value: string; adjust: number }[] = [];
    if (p.variants) {
      const inserted = await db
        .insert(productVariants)
        .values(
          p.variants.items.map(([value, adjust, stock], idx) => ({
            productId: row.id,
            optionName: p.variants!.opt,
            value,
            priceAdjust: adjust,
            stock,
            sortOrder: idx,
          })),
        )
        .returning();
      vrows = inserted.map((v) => ({ id: v.id, value: v.value, adjust: v.priceAdjust }));
    }
    createdProducts.push({
      id: row.id,
      name: p.name,
      price: p.price,
      image: img(p.imgs[0]),
      variants: vrows,
    });
  }

  // 4. Demo customers + orders
  const customerRows = await db
    .insert(customers)
    .values(
      CUSTOMERS.map(([fullName, phone, email, governorate, city, address]) => ({
        fullName,
        phone,
        email,
        governorate,
        city,
        address,
      })),
    )
    .returning();

  for (let i = 0; i < STATUS_PLAN.length; i++) {
    const status = STATUS_PLAN[i];
    const c = customerRows[i % customerRows.length];
    const created = new Date(now - (STATUS_PLAN.length - i) * 1.9 * 24 * 3600 * 1000 - i * 3600 * 1000);
    const nItems = 1 + (i % 3);
    const lines = [];
    for (let k = 0; k < nItems; k++) {
      const p = createdProducts[(i * 5 + k * 7) % createdProducts.length];
      const v = p.variants.length ? p.variants[(i + k) % p.variants.length] : null;
      lines.push({
        productId: p.id,
        variantId: v?.id ?? null,
        name: p.name,
        variantLabel: v?.value ?? "",
        price: p.price + (v?.adjust ?? 0),
        quantity: 1 + ((i + k) % 2),
        image: p.image,
      });
    }
    const subtotal = lines.reduce((s, l) => s + l.price * l.quantity, 0);
    const fee = subtotal >= 180 ? 0 : (DEFAULT_GOVERNORATE_FEES[c.governorate] ?? 8);
    const [order] = await db
      .insert(orders)
      .values({
        orderNumber: orderNumber(created, i + 1),
        customerId: c.id,
        status,
        subtotal,
        deliveryFee: fee,
        total: subtotal + fee,
        paymentMethod: "cod",
        customerName: c.fullName,
        phone: c.phone,
        email: c.email,
        governorate: c.governorate,
        city: c.city,
        address: c.address,
        notes: i % 4 === 0 ? "Merci d'appeler avant la livraison." : "",
        createdAt: created,
        updatedAt: created,
      })
      .returning();
    await db.insert(orderItems).values(lines.map((l) => ({ ...l, orderId: order.id })));
  }

  await db.insert(settings).values({ key: "seeded", value: true }).onConflictDoNothing();
  console.log("[seed] demo catalogue, customers and orders created");
}
