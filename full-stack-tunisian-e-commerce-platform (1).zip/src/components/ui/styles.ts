export const input =
  "w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-muted/60 transition focus:border-clay focus:outline-none focus:ring-2 focus:ring-clay/20 disabled:opacity-60";

export const label = "mb-1.5 block text-sm font-medium text-ink";

const btn =
  "inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium tracking-wide transition disabled:cursor-not-allowed disabled:opacity-60";

export const btnPrimary = `${btn} bg-ink text-ivory hover:bg-clay`;
export const btnClay = `${btn} bg-clay text-white hover:bg-clay-dark`;
export const btnOutline = `${btn} border border-ink/25 text-ink hover:border-ink hover:bg-ink hover:text-ivory`;

// Admin (more compact, less rounded)
const abtn =
  "inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-60";
export const aPrimary = `${abtn} bg-ink text-ivory hover:bg-clay`;
export const aOutline = `${abtn} border border-line bg-white text-ink hover:bg-cream`;
export const aDanger = `${abtn} bg-rose-600 text-white hover:bg-rose-700`;

export const card = "rounded-2xl border border-line bg-white";
