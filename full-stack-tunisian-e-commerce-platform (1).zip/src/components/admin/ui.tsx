import Link from "next/link";
import { statusMeta } from "@/lib/constants";

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-4xl font-semibold">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const m = statusMeta(status);
  return (
    <span className={`inline-flex whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-medium ring-1 ${m.cls}`}>
      {m.label}
    </span>
  );
}

export function EmptyState({
  icon,
  title,
  text,
  action,
}: {
  icon?: React.ReactNode;
  title: string;
  text?: string;
  action?: { href: string; label: string };
}) {
  return (
    <div className="px-6 py-16 text-center">
      {icon && <div className="mx-auto mb-3 flex justify-center text-beige">{icon}</div>}
      <p className="font-display text-2xl">{title}</p>
      {text && <p className="mx-auto mt-1 max-w-sm text-sm text-muted">{text}</p>}
      {action && (
        <Link href={action.href} className="mt-5 inline-flex rounded-lg bg-ink px-4 py-2 text-sm font-medium text-ivory hover:bg-clay">
          {action.label}
        </Link>
      )}
    </div>
  );
}

export function Pagination({
  page,
  pages,
  hrefFor,
}: {
  page: number;
  pages: number;
  hrefFor: (p: number) => string;
}) {
  if (pages <= 1) return null;
  return (
    <nav className="flex items-center justify-between border-t border-line px-4 py-3 text-sm" aria-label="Pagination">
      <span className="text-muted">Page {page} sur {pages}</span>
      <div className="flex gap-2">
        {page > 1 && <Link href={hrefFor(page - 1)} className="rounded-lg border border-line px-3 py-1.5 hover:bg-cream">Précédent</Link>}
        {page < pages && <Link href={hrefFor(page + 1)} className="rounded-lg border border-line px-3 py-1.5 hover:bg-cream">Suivant</Link>}
      </div>
    </nav>
  );
}
