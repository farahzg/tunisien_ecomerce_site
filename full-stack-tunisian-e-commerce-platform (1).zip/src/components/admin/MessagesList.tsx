"use client";

import { useOptimistic, useTransition } from "react";
import { Mail, MailOpen, Phone, Trash2 } from "lucide-react";
import { deleteMessage, setMessageRead } from "@/app/actions/admin";
import { useToast } from "@/components/ui/Toast";
import { formatDateTime } from "@/lib/format";
import { EmptyState } from "./ui";
import { card } from "@/components/ui/styles";

export type Msg = { id: number; name: string; email: string; phone: string; message: string; read: boolean; createdAt: string };

export function MessagesList({ rows }: { rows: Msg[] }) {
  const [list, apply] = useOptimistic(rows, (s, a: { id: number; read?: boolean; del?: boolean }) =>
    a.del ? s.filter((m) => m.id !== a.id) : s.map((m) => (m.id === a.id ? { ...m, read: a.read! } : m)),
  );
  const [, start] = useTransition();
  const { toast } = useToast();

  if (list.length === 0) {
    return <div className={card}><EmptyState icon={<Mail className="h-10 w-10" />} title="Aucun message" text="Les messages du formulaire de contact apparaîtront ici." /></div>;
  }
  return (
    <ul className="space-y-3">
      {list.map((m) => (
        <li key={m.id} className={`${card} p-5 ${m.read ? "" : "border-l-4 border-l-clay"}`}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="font-medium">{m.name} {!m.read && <span className="ml-2 rounded-full bg-clay px-2 py-0.5 text-[10px] text-white">Nouveau</span>}</p>
              <p className="mt-0.5 flex flex-wrap gap-x-4 text-xs text-muted">
                {m.email && <a href={`mailto:${m.email}`} className="inline-flex items-center gap-1 hover:text-clay"><Mail className="h-3 w-3" />{m.email}</a>}
                {m.phone && <a href={`tel:${m.phone}`} className="inline-flex items-center gap-1 hover:text-clay"><Phone className="h-3 w-3" />{m.phone}</a>}
                <span>{formatDateTime(m.createdAt)}</span>
              </p>
            </div>
            <div className="flex gap-1">
              <button
                onClick={() => start(async () => { apply({ id: m.id, read: !m.read }); await setMessageRead(m.id, !m.read); })}
                className="inline-flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-xs hover:bg-cream"
              >
                <MailOpen className="h-3.5 w-3.5" /> {m.read ? "Marquer non lu" : "Marquer lu"}
              </button>
              <button
                aria-label="Supprimer le message"
                onClick={() => start(async () => { apply({ id: m.id, del: true }); await deleteMessage(m.id); toast("Message supprimé"); })}
                className="rounded-lg p-2 text-rose-600 hover:bg-rose-50"
              ><Trash2 className="h-4 w-4" /></button>
            </div>
          </div>
          <p className="mt-3 whitespace-pre-line text-sm leading-relaxed">{m.message}</p>
        </li>
      ))}
    </ul>
  );
}
