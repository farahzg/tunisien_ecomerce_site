"use client";

import { useState, useTransition } from "react";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { saveDeliveryFees, saveSettings } from "@/app/actions/admin";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "./ImageUploader";
import type { StoreSettings } from "@/lib/settings-defaults";
import { aOutline, aPrimary, card, input, label } from "@/components/ui/styles";

type Field = {
  name: string;
  label: string;
  type?: "text" | "textarea" | "number" | "checkbox" | "image";
  hint?: string;
  wide?: boolean;
};
type Obj = Record<string, string | number | boolean>;

function convert(fields: Field[], v: Obj): Obj {
  const out: Obj = { ...v };
  for (const f of fields) {
    if (f.type === "number") out[f.name] = Number(String(v[f.name]).replace(",", ".")) || 0;
  }
  return out;
}

function FieldInput({ f, value, onChange, id }: { f: Field; value: string | number | boolean; onChange: (v: string | number | boolean) => void; id: string }) {
  if (f.type === "checkbox") {
    return (
      <label className="flex cursor-pointer items-center gap-3 text-sm">
        <input id={id} type="checkbox" checked={!!value} onChange={(e) => onChange(e.target.checked)} className="h-5 w-5 accent-clay" />
        <span className="font-medium">{f.label}</span>
      </label>
    );
  }
  if (f.type === "image") {
    return <ImageUploader multiple={false} label={f.label} value={value ? [String(value)] : []} onChange={(v) => onChange(v[0] ?? "")} />;
  }
  return (
    <div>
      <label htmlFor={id} className={label}>{f.label}</label>
      {f.type === "textarea" ? (
        <textarea id={id} rows={4} value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} className={input} />
      ) : (
        <input id={id} inputMode={f.type === "number" ? "decimal" : undefined} value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} className={input} />
      )}
      {f.hint && <p className="mt-1 text-xs text-muted">{f.hint}</p>}
    </div>
  );
}

function SaveBar({ pending, label: text = "Enregistrer" }: { pending: boolean; label?: string }) {
  return (
    <div className="mt-6 flex justify-end border-t border-line pt-5">
      <button disabled={pending} className={aPrimary}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} {text}</button>
    </div>
  );
}

function ObjectSection({ settingKey, title, description, fields, initial }: { settingKey: string; title: string; description: string; fields: Field[]; initial: Obj }) {
  const [v, setV] = useState<Obj>(initial);
  const [pending, start] = useTransition();
  const { toast } = useToast();
  function submit(e: React.FormEvent) {
    e.preventDefault();
    start(async () => {
      const res = await saveSettings(settingKey, convert(fields, v));
      if (res.ok) toast("Paramètres enregistrés — visibles immédiatement sur la boutique");
      else toast(res.error, "error");
    });
  }
  return (
    <form onSubmit={submit} className={`${card} p-6`} noValidate>
      <h2 className="font-display text-2xl font-semibold">{title}</h2>
      <p className="mb-6 text-sm text-muted">{description}</p>
      <div className="grid gap-5 sm:grid-cols-2">
        {fields.map((f) => (
          <div key={f.name} className={f.wide || f.type === "textarea" || f.type === "image" ? "sm:col-span-2" : ""}>
            <FieldInput f={f} id={`${settingKey}-${f.name}`} value={v[f.name] ?? ""} onChange={(x) => setV((s) => ({ ...s, [f.name]: x }))} />
          </div>
        ))}
      </div>
      <SaveBar pending={pending} />
    </form>
  );
}

function ListSection({ settingKey, title, description, fields, initial, blank, addLabel, itemTitle }: {
  settingKey: string; title: string; description: string; fields: Field[]; initial: Obj[]; blank: Obj; addLabel: string; itemTitle: (o: Obj, i: number) => string;
}) {
  const [rows, setRows] = useState<Obj[]>(initial);
  const [pending, start] = useTransition();
  const { toast } = useToast();
  function submit(e: React.FormEvent) {
    e.preventDefault();
    start(async () => {
      const res = await saveSettings(settingKey, rows.map((r) => convert(fields, r)));
      if (res.ok) toast("Enregistré — visible immédiatement sur la boutique");
      else toast(res.error, "error");
    });
  }
  return (
    <form onSubmit={submit} className={`${card} p-6`} noValidate>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-semibold">{title}</h2>
          <p className="text-sm text-muted">{description}</p>
        </div>
        <button type="button" onClick={() => setRows((r) => [...r, { ...blank }])} className={aOutline}><Plus className="h-4 w-4" /> {addLabel}</button>
      </div>
      {rows.length === 0 && <p className="rounded-xl border border-dashed border-line p-8 text-center text-sm text-muted">Aucun élément. Cliquez sur « {addLabel} ».</p>}
      <div className="space-y-4">
        {rows.map((row, i) => (
          <fieldset key={i} className="rounded-xl border border-line bg-cream/30 p-4">
            <div className="mb-3 flex items-center justify-between">
              <legend className="text-sm font-semibold">{itemTitle(row, i)}</legend>
              <button type="button" aria-label="Supprimer" onClick={() => setRows((r) => r.filter((_, k) => k !== i))} className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {fields.map((f) => (
                <div key={f.name} className={f.wide || f.type === "textarea" || f.type === "image" ? "sm:col-span-2" : ""}>
                  <FieldInput f={f} id={`${settingKey}-${i}-${f.name}`} value={row[f.name] ?? ""} onChange={(x) => setRows((r) => r.map((o, k) => (k === i ? { ...o, [f.name]: x } : o)))} />
                </div>
              ))}
            </div>
          </fieldset>
        ))}
      </div>
      <SaveBar pending={pending} />
    </form>
  );
}

function DeliverySection({ initial, fees }: { initial: StoreSettings["delivery"]; fees: { governorate: string; fee: number; active: boolean }[] }) {
  const [d, setD] = useState({ defaultFee: String(initial.defaultFee), freeThreshold: String(initial.freeThreshold), estimate: initial.estimate });
  const [rows, setRows] = useState(fees.map((f) => ({ ...f, fee: String(f.fee) })));
  const [bulk, setBulk] = useState("");
  const [pending, start] = useTransition();
  const { toast } = useToast();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    start(async () => {
      const r1 = await saveSettings("delivery", {
        defaultFee: Number(d.defaultFee.replace(",", ".")) || 0,
        freeThreshold: Number(d.freeThreshold.replace(",", ".")) || 0,
        estimate: d.estimate,
      });
      const r2 = await saveDeliveryFees(rows.map((r) => ({ governorate: r.governorate, fee: Number(r.fee.replace(",", ".")) || 0, active: r.active })));
      if (r1.ok && r2.ok) toast("Livraison enregistrée — appliquée immédiatement au paiement");
      else toast((!r1.ok && r1.error) || (!r2.ok && r2.error) || "Erreur", "error");
    });
  }

  return (
    <form onSubmit={submit} className={`${card} p-6`} noValidate>
      <h2 className="font-display text-2xl font-semibold">Livraison</h2>
      <p className="mb-6 text-sm text-muted">Frais par gouvernorat, seuil de livraison offerte et délai affiché aux clients.</p>
      <div className="grid gap-5 sm:grid-cols-3">
        <div><label htmlFor="d-free" className={label}>Livraison offerte dès (TND)</label><input id="d-free" inputMode="decimal" value={d.freeThreshold} onChange={(e) => setD({ ...d, freeThreshold: e.target.value })} className={input} /><p className="mt-1 text-xs text-muted">0 = jamais offerte</p></div>
        <div><label htmlFor="d-def" className={label}>Frais par défaut (TND)</label><input id="d-def" inputMode="decimal" value={d.defaultFee} onChange={(e) => setD({ ...d, defaultFee: e.target.value })} className={input} /></div>
        <div><label htmlFor="d-est" className={label}>Délai de livraison</label><input id="d-est" value={d.estimate} onChange={(e) => setD({ ...d, estimate: e.target.value })} className={input} /></div>
      </div>

      <div className="mb-3 mt-8 flex flex-wrap items-end justify-between gap-3">
        <h3 className="font-display text-xl font-semibold">Frais par gouvernorat</h3>
        <div className="flex items-end gap-2">
          <div><label htmlFor="bulk" className="mb-1 block text-xs text-muted">Appliquer à tous</label><input id="bulk" inputMode="decimal" value={bulk} onChange={(e) => setBulk(e.target.value)} placeholder="TND" className={`${input} w-24`} /></div>
          <button type="button" onClick={() => bulk && setRows((r) => r.map((x) => ({ ...x, fee: bulk })))} className={aOutline}>Appliquer</button>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {rows.map((r, i) => (
          <div key={r.governorate} className={`flex items-center gap-3 rounded-xl border border-line p-3 ${r.active ? "bg-white" : "bg-sand/40"}`}>
            <label className="flex flex-1 cursor-pointer items-center gap-2 text-sm">
              <input type="checkbox" checked={r.active} onChange={(e) => setRows((x) => x.map((y, k) => (k === i ? { ...y, active: e.target.checked } : y)))} className="h-4 w-4 accent-clay" aria-label={`Livrer à ${r.governorate}`} />
              <span className={r.active ? "" : "text-muted line-through"}>{r.governorate}</span>
            </label>
            <div className="flex items-center gap-1.5">
              <input aria-label={`Frais ${r.governorate}`} inputMode="decimal" value={r.fee} onChange={(e) => setRows((x) => x.map((y, k) => (k === i ? { ...y, fee: e.target.value } : y)))} className={`${input} w-20 py-1.5 text-right`} />
              <span className="text-xs text-muted">TND</span>
            </div>
          </div>
        ))}
      </div>
      <SaveBar pending={pending} />
    </form>
  );
}

const TABS = [
  ["store", "Boutique & contact"],
  ["social", "Réseaux sociaux"],
  ["promo", "Accueil & promotions"],
  ["delivery", "Livraison"],
  ["locations", "Points de vente"],
  ["collections", "Collections"],
  ["testimonials", "Avis clients"],
] as const;

export function SettingsForm({ settings, fees }: { settings: StoreSettings; fees: { governorate: string; fee: number; active: boolean }[] }) {
  const [tab, setTab] = useState<(typeof TABS)[number][0]>("store");
  return (
    <div>
      <div className="-mx-1 mb-6 flex gap-1 overflow-x-auto px-1 pb-1" role="tablist">
        {TABS.map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`whitespace-nowrap rounded-lg px-4 py-2 text-sm transition ${tab === k ? "bg-ink text-ivory" : "bg-white text-ink hover:bg-cream"}`}>{l}</button>
        ))}
      </div>

      {tab === "store" && (
        <ObjectSection settingKey="store" title="Boutique & contact" description="Ces informations apparaissent dans le pied de page, la page contact et les confirmations." initial={settings.store} fields={[
          { name: "name", label: "Nom de la boutique" },
          { name: "tagline", label: "Slogan" },
          { name: "email", label: "E-mail de contact" },
          { name: "phone", label: "Téléphone", hint: "Format local, ex : 92 944 940" },
          { name: "whatsapp", label: "WhatsApp (international)", hint: "Ex : 21692944940 — laisser vide pour masquer" },
          { name: "hours", label: "Horaires d'ouverture" },
          { name: "address", label: "Adresse principale", wide: true },
        ]} />
      )}
      {tab === "social" && (
        <ObjectSection settingKey="social" title="Réseaux sociaux" description="Les liens vides ne sont pas affichés." initial={settings.social} fields={[
          { name: "instagram", label: "Instagram (URL)" },
          { name: "facebook", label: "Facebook (URL)" },
          { name: "tiktok", label: "TikTok (URL)" },
          { name: "pinterest", label: "Pinterest (URL)" },
        ]} />
      )}
      {tab === "promo" && (
        <ObjectSection settingKey="promo" title="Accueil & promotions" description="Bandeau d'annonce, section héro et histoire de la marque." initial={settings.promo} fields={[
          { name: "announcementEnabled", label: "Afficher le bandeau d'annonce", type: "checkbox" },
          { name: "announcement", label: "Texte du bandeau", wide: true },
          { name: "heroEyebrow", label: "Sur-titre du héro" },
          { name: "heroTitle", label: "Titre du héro" },
          { name: "heroSubtitle", label: "Sous-titre du héro", type: "textarea" },
          { name: "heroCta", label: "Texte du bouton" },
          { name: "heroCtaLink", label: "Lien du bouton", hint: "Ex : /boutique ou /boutique?categorie=bijoux" },
          { name: "heroImage", label: "Image du héro", type: "image" },
          { name: "storyTitle", label: "Titre « Notre histoire »", wide: true },
          { name: "storyText", label: "Texte « Notre histoire »", type: "textarea" },
          { name: "storyImage", label: "Image « Notre histoire »", type: "image" },
        ]} />
      )}
      {tab === "delivery" && <DeliverySection initial={settings.delivery} fees={fees} />}
      {tab === "locations" && (
        <ListSection settingKey="locations" title="Points de vente" description="Affichés sur la page « Nos boutiques » et dans le pied de page." addLabel="Ajouter une boutique" blank={{ name: "", address: "", hours: "", phone: "" }} itemTitle={(o, i) => String(o.name || `Boutique ${i + 1}`)} initial={settings.locations} fields={[
          { name: "name", label: "Nom" }, { name: "phone", label: "Téléphone" }, { name: "address", label: "Adresse", wide: true }, { name: "hours", label: "Horaires", wide: true },
        ]} />
      )}
      {tab === "collections" && (
        <ListSection settingKey="collections" title="Collections à la une" description="Cartes affichées sur la page d'accueil." addLabel="Ajouter une collection" blank={{ title: "", text: "", image: "", href: "/boutique" }} itemTitle={(o, i) => String(o.title || `Collection ${i + 1}`)} initial={settings.collections} fields={[
          { name: "title", label: "Titre" }, { name: "href", label: "Lien", hint: "Ex : /boutique?categorie=mode" }, { name: "text", label: "Description", wide: true }, { name: "image", label: "Image", type: "image" },
        ]} />
      )}
      {tab === "testimonials" && (
        <ListSection settingKey="testimonials" title="Avis clients" description="Témoignages affichés sur la page d'accueil. Remplacez les exemples par de vrais avis." addLabel="Ajouter un avis" blank={{ name: "", city: "", text: "", rating: 5 }} itemTitle={(o, i) => String(o.name || `Avis ${i + 1}`)} initial={settings.testimonials} fields={[
          { name: "name", label: "Nom" }, { name: "city", label: "Ville" }, { name: "rating", label: "Note (1 à 5)", type: "number" }, { name: "text", label: "Témoignage", type: "textarea" },
        ]} />
      )}
    </div>
  );
}
