"use client";

import Link from "next/link";
import { useOptimistic, useState, useTransition } from "react";
import { Pencil, Star, Trash2 } from "lucide-react";
import { deleteProduct, toggleProductFlag } from "@/app/actions/admin";
import { ConfirmDialog } from "@/components/ui/Modal";
import { useToast } from "@/components/ui/Toast";
import { formatTND } from "@/lib/format";
import { LOW_STOCK_THRESHOLD } from "@/lib/constants";

export type ProductRow = {
  id: number;
  name: string;
  sku: string;
  image: string | null;
  categoryName: string | null;
  price: number;
  stock: number;
  featured: boolean;
  available: boolean;
  hasVariants: boolean;
};

type Action =
  | { type: "toggle"; id: number; field: "featured" | "available"; value: boolean }
  | { type: "delete"; id: number };

export function ProductsTable({ rows }: { rows: ProductRow[] }) {
  const [optimistic, apply] = useOptimistic(rows, (state, a: Action) =>
    a.type === "delete" ? state.filter((r) => r.id !== a.id) : state.map((r) => (r.id === a.id ? { ...r, [a.field]: a.value } : r)),
  );
  const [, start] = useTransition();
  const [toDelete, setToDelete] = useState<ProductRow | null>(null);
  const { toast } = useToast();

  function toggle(r: ProductRow, field: "featured" | "available") {
    const value = !r[field];
    start(async () => {
      apply({ type: "toggle", id: r.id, field, value });
      const res = await toggleProductFlag(r.id, field, value);
      if (!res.ok) toast(res.error, "error");
    });
  }

  function confirmDelete() {
    const r = toDelete;
    if (!r) return;
    setToDelete(null);
    start(async () => {
      apply({ type: "delete", id: r.id });
      const res = await deleteProduct(r.id);
      if (res.ok) toast(`« ${r.name} » supprimé`);
      else toast(res.error, "error");
    });
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[820px] text-left text-sm">
          <thead className="border-b border-line bg-cream/50 text-xs uppercase tracking-wider text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Produit</th>
              <th className="px-4 py-3 font-medium">Catégorie</th>
              <th className="px-4 py-3 font-medium">Prix</th>
              <th className="px-4 py-3 font-medium">Stock</th>
              <th className="px-4 py-3 text-center font-medium">À la une</th>
              <th className="px-4 py-3 text-center font-medium">Disponible</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {optimistic.map((r) => (
              <tr key={r.id} className={`transition hover:bg-cream/40 ${r.available ? "" : "opacity-60"}`}>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-14 w-12 shrink-0 overflow-hidden rounded-lg bg-cream">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      {r.image && <img src={r.image} alt="" loading="lazy" className="h-full w-full object-cover" />}
                    </div>
                    <div className="min-w-0">
                      <Link href={`/admin/produits/${r.id}`} className="font-medium hover:text-clay">{r.name}</Link>
                      <p className="text-xs text-muted">{r.sku || "—"}{r.hasVariants && " · variantes"}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-muted">{r.categoryName ?? "—"}</td>
                <td className="whitespace-nowrap px-4 py-3 font-medium">{formatTND(r.price)}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${r.stock <= 0 ? "bg-rose-100 text-rose-700" : r.stock <= LOW_STOCK_THRESHOLD ? "bg-amber-100 text-amber-800" : "bg-emerald-100 text-emerald-800"}`}>
                    {r.stock <= 0 ? "Épuisé" : r.stock}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <button onClick={() => toggle(r, "featured")} aria-pressed={r.featured} aria-label={r.featured ? "Retirer de la une" : "Mettre à la une"} className="rounded-full p-1.5 hover:bg-cream">
                    <Star className={`h-5 w-5 transition ${r.featured ? "fill-clay text-clay" : "text-beige"}`} />
                  </button>
                </td>
                <td className="px-4 py-3 text-center">
                  <button
                    role="switch"
                    aria-checked={r.available}
                    aria-label={r.available ? "Rendre indisponible" : "Rendre disponible"}
                    onClick={() => toggle(r, "available")}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${r.available ? "bg-emerald-500" : "bg-sand"}`}
                  >
                    <span className={`inline-block h-5 w-5 rounded-full bg-white shadow transition ${r.available ? "translate-x-[22px]" : "translate-x-0.5"}`} />
                  </button>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <Link href={`/admin/produits/${r.id}`} aria-label={`Modifier ${r.name}`} className="rounded-lg p-2 hover:bg-cream"><Pencil className="h-4 w-4" /></Link>
                    <button onClick={() => setToDelete(r)} aria-label={`Supprimer ${r.name}`} className="rounded-lg p-2 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ConfirmDialog
        open={!!toDelete}
        onClose={() => setToDelete(null)}
        onConfirm={confirmDelete}
        title="Supprimer ce produit ?"
        message={`« ${toDelete?.name ?? ""} » sera définitivement supprimé de la boutique. Les commandes existantes conserveront son nom et son prix.`}
      />
    </>
  );
}
