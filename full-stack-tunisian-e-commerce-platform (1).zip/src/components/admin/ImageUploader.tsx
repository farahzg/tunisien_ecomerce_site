"use client";

import { useRef, useState } from "react";
import { ArrowLeft, ImagePlus, Link2, Loader2, Star, Trash2 } from "lucide-react";
import { useToast } from "@/components/ui/Toast";
import { input } from "@/components/ui/styles";

type Props = {
  value: string[];
  onChange: (urls: string[]) => void;
  multiple?: boolean;
  label?: string;
};

export function ImageUploader({ value, onChange, multiple = true, label = "Images" }: Props) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);
  const [url, setUrl] = useState("");
  const { toast } = useToast();

  async function upload(files: FileList | File[]) {
    const list = Array.from(files);
    if (!list.length) return;
    setBusy(true);
    try {
      const fd = new FormData();
      (multiple ? list : list.slice(0, 1)).forEach((f) => fd.append("files", f));
      const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Échec du téléversement");
      onChange(multiple ? [...value, ...data.urls] : data.urls);
      toast(`${data.urls.length} image${data.urls.length > 1 ? "s" : ""} téléversée${data.urls.length > 1 ? "s" : ""}`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Échec du téléversement", "error");
    } finally {
      setBusy(false);
      if (ref.current) ref.current.value = "";
    }
  }

  function addUrl() {
    const u = url.trim();
    if (!/^(\/|https?:\/\/)\S+$/.test(u)) return toast("URL d'image invalide", "error");
    onChange(multiple ? [...value, u] : [u]);
    setUrl("");
  }

  return (
    <div>
      <p className="mb-1.5 text-sm font-medium">{label}</p>
      {value.length > 0 && (
        <ul className="mb-3 grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5">
          {value.map((src, i) => (
            <li key={src + i} className="group relative aspect-square overflow-hidden rounded-xl border border-line bg-cream">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt={`Image ${i + 1}`} className="h-full w-full object-cover" />
              {multiple && i === 0 && (
                <span className="absolute left-1.5 top-1.5 rounded-full bg-clay px-2 py-0.5 text-[10px] font-medium text-white">Principale</span>
              )}
              <div className="absolute inset-x-0 bottom-0 flex justify-center gap-1 bg-gradient-to-t from-ink/70 to-transparent p-1.5 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100">
                {multiple && i > 0 && (
                  <button type="button" title="Définir comme principale" aria-label="Définir comme principale" onClick={() => onChange([src, ...value.filter((_, k) => k !== i)])} className="rounded-md bg-white/90 p-1.5 hover:bg-white"><Star className="h-3.5 w-3.5" /></button>
                )}
                {multiple && i > 0 && (
                  <button type="button" title="Déplacer à gauche" aria-label="Déplacer à gauche" onClick={() => { const n = [...value]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; onChange(n); }} className="rounded-md bg-white/90 p-1.5 hover:bg-white"><ArrowLeft className="h-3.5 w-3.5" /></button>
                )}
                <button type="button" title="Supprimer" aria-label="Supprimer l'image" onClick={() => onChange(value.filter((_, k) => k !== i))} className="rounded-md bg-white/90 p-1.5 text-rose-600 hover:bg-white"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); upload(e.dataTransfer.files); }}
        className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed px-4 py-6 text-center transition ${drag ? "border-clay bg-clay/5" : "border-line bg-cream/30"}`}
      >
        {busy ? (
          <p className="flex items-center gap-2 text-sm text-muted"><Loader2 className="h-4 w-4 animate-spin" /> Téléversement en cours…</p>
        ) : (
          <>
            <ImagePlus className="h-7 w-7 text-beige" />
            <p className="mt-2 text-sm">Glissez-déposez {multiple ? "vos images" : "une image"} ou{" "}
              <button type="button" onClick={() => ref.current?.click()} className="font-medium text-clay underline-offset-4 hover:underline">parcourir</button>
            </p>
            <p className="text-xs text-muted">JPG, PNG, WebP ou AVIF · 5 Mo max</p>
          </>
        )}
        <input ref={ref} type="file" accept="image/jpeg,image/png,image/webp,image/avif" multiple={multiple} hidden onChange={(e) => e.target.files && upload(e.target.files)} />
      </div>

      <div className="mt-3 flex gap-2">
        <div className="relative flex-1">
          <Link2 className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addUrl(); } }} placeholder="… ou coller l'URL d'une image" className={`${input} pl-9`} aria-label="URL de l'image" />
        </div>
        <button type="button" onClick={addUrl} className="rounded-lg border border-line bg-white px-4 text-sm hover:bg-cream">Ajouter</button>
      </div>
    </div>
  );
}
