"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { FolderTree, Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { deleteCategory, saveCategory } from "@/app/actions/admin";
import { ConfirmDialog, Modal } from "@/components/ui/Modal";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "./ImageUploader";
import { EmptyState } from "./ui";
import { aOutline, aPrimary, card, input, label } from "@/components/ui/styles";

export type CategoryRow = {
  id: number;
  name: string;
  slug: string;
  description: string;
  imageUrl: string;
  sortOrder: number;
  productCount: number;
};

type Draft = { id?: number; name: string; slug: string; description: string; imageUrl: string; sortOrder: string };
const blank: Draft = { name: "", slug: "", description: "", imageUrl: "", sortOrder: "0" };

export function CategoryManager({ rows }: { rows: CategoryRow[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [draft, setDraft] = useState<Draft | null>(null);
  const [toDelete, setToDelete] = useState<CategoryRow | null>(null);
  const [error, setError] = useState("");
  const [pending, start] = useTransition();

  function save(e: React.FormEvent) {
    e.preventDefault();
    if (!draft) return;
    setError("");
    start(async () => {
      const res = await saveCategory({ ...draft, sortOrder: Number(draft.sortOrder) || 0 });
      if (res.ok) {
        toast(draft.id ? "Catégorie mise à jour" : "Catégorie créée");
        setDraft(null);
        router.refresh();
      } else setError(res.error);
    });
  }

  function remove() {
    const c = toDelete;
    if (!c) return;
    start(async () => {
      const res = await deleteCategory(c.id);
      setToDelete(null);
      if (res.ok) { toast(`« ${c.name} » supprimée`); router.refresh(); } else toast(res.error, "error");
    });
  }

  return (
    <>
      <div className="mb-6 flex justify-end">
        <button onClick={() => { setError(""); setDraft({ ...blank, sortOrder: String(rows.length) }); }} className={aPrimary}><Plus className="h-4 w-4" /> Nouvelle catégorie</button>
      </div>

      {rows.length === 0 ? (
        <div className={card}><EmptyState icon={<FolderTree className="h-10 w-10" />} title="Aucune catégorie" text="Créez des catégories pour organiser votre boutique." /></div>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {rows.map((c) => (
            <li key={c.id} className={`${card} overflow-hidden`}>
              <div className="relative aspect-[16/9] bg-cream">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                {c.imageUrl ? <img src={c.imageUrl} alt="" loading="lazy" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-sm text-muted">Pas d&apos;image</div>}
                <span className="absolute right-3 top-3 rounded-full bg-white/95 px-2.5 py-1 text-xs font-medium">{c.productCount} produit{c.productCount > 1 ? "s" : ""}</span>
              </div>
              <div className="p-4">
                <h3 className="font-display text-2xl font-semibold">{c.name}</h3>
                <p className="mt-0.5 text-xs text-muted">/{c.slug} · ordre {c.sortOrder}</p>
                <p className="mt-2 line-clamp-2 text-sm text-muted">{c.description || "Aucune description"}</p>
                <div className="mt-4 flex gap-2">
                  <button onClick={() => { setError(""); setDraft({ id: c.id, name: c.name, slug: c.slug, description: c.description, imageUrl: c.imageUrl, sortOrder: String(c.sortOrder) }); }} className={aOutline}><Pencil className="h-4 w-4" /> Modifier</button>
                  <button onClick={() => setToDelete(c)} className={`${aOutline} text-rose-600`} aria-label={`Supprimer ${c.name}`}><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Modal open={!!draft} onClose={() => setDraft(null)} title={draft?.id ? "Modifier la catégorie" : "Nouvelle catégorie"} wide>
        {draft && (
          <form onSubmit={save} className="space-y-4" noValidate>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="cat-name" className={label}>Nom *</label>
                <input id="cat-name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} className={input} required autoFocus />
              </div>
              <div>
                <label htmlFor="cat-order" className={label}>Ordre d&apos;affichage</label>
                <input id="cat-order" inputMode="numeric" value={draft.sortOrder} onChange={(e) => setDraft({ ...draft, sortOrder: e.target.value })} className={input} />
              </div>
            </div>
            <div>
              <label htmlFor="cat-desc" className={label}>Description</label>
              <textarea id="cat-desc" rows={3} value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} className={input} maxLength={400} />
            </div>
            <div>
              <label htmlFor="cat-slug" className={label}>Lien (slug)</label>
              <input id="cat-slug" value={draft.slug} onChange={(e) => setDraft({ ...draft, slug: e.target.value })} className={input} placeholder="généré automatiquement" />
            </div>
            <ImageUploader multiple={false} label="Image de la catégorie" value={draft.imageUrl ? [draft.imageUrl] : []} onChange={(v) => setDraft({ ...draft, imageUrl: v[0] ?? "" })} />
            {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={() => setDraft(null)} className={aOutline}>Annuler</button>
              <button disabled={pending} className={aPrimary}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Enregistrer</button>
            </div>
          </form>
        )}
      </Modal>

      <ConfirmDialog
        open={!!toDelete}
        onClose={() => setToDelete(null)}
        onConfirm={remove}
        pending={pending}
        title="Supprimer cette catégorie ?"
        message={`« ${toDelete?.name ?? ""} » sera supprimée. Ses ${toDelete?.productCount ?? 0} produit(s) resteront en boutique, sans catégorie.`}
      />
    </>
  );
}
