"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { saveProduct } from "@/app/actions/admin";
import { ImageUploader } from "./ImageUploader";
import { useToast } from "@/components/ui/Toast";
import { aOutline, aPrimary, card, input, label } from "@/components/ui/styles";

type VariantRow = { id?: number; value: string; priceAdjust: string; stock: string };
export type ProductFormData = {
  id?: number;
  name: string;
  slug: string;
  shortDescription: string;
  description: string;
  price: string;
  comparePrice: string;
  categoryId: string;
  images: string[];
  stock: string;
  sku: string;
  featured: boolean;
  available: boolean;
  optionName: string;
  variants: VariantRow[];
};

export const emptyProduct: ProductFormData = {
  name: "", slug: "", shortDescription: "", description: "", price: "", comparePrice: "",
  categoryId: "", images: [], stock: "0", sku: "", featured: false, available: true,
  optionName: "Couleur", variants: [],
};

const num = (v: string) => (v.trim() === "" ? NaN : Number(v.replace(",", ".")));

export function ProductForm({
  initial,
  categories,
}: {
  initial: ProductFormData;
  categories: { id: number; name: string }[];
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [f, setF] = useState(initial);
  const [pending, start] = useTransition();
  const [error, setError] = useState("");
  const hasVariants = f.variants.length > 0;

  const set = <K extends keyof ProductFormData>(k: K, v: ProductFormData[K]) => setF((s) => ({ ...s, [k]: v }));
  const setVariant = (i: number, patch: Partial<VariantRow>) =>
    setF((s) => ({ ...s, variants: s.variants.map((v, k) => (k === i ? { ...v, ...patch } : v)) }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const price = num(f.price);
    if (!f.name.trim()) return setError("Le nom du produit est requis.");
    if (Number.isNaN(price) || price < 0) return setError("Veuillez saisir un prix valide.");
    const compare = f.comparePrice.trim() === "" ? null : num(f.comparePrice);
    if (compare !== null && Number.isNaN(compare)) return setError("Prix barré invalide.");
    const stock = Number.isNaN(num(f.stock)) ? 0 : Math.max(0, Math.floor(num(f.stock)));
    for (const v of f.variants) if (!v.value.trim()) return setError("Chaque variante doit avoir une valeur.");

    start(async () => {
      const res = await saveProduct({
        id: f.id,
        name: f.name,
        slug: f.slug,
        shortDescription: f.shortDescription,
        description: f.description,
        price,
        comparePrice: compare,
        categoryId: f.categoryId ? Number(f.categoryId) : null,
        images: f.images,
        stock,
        sku: f.sku,
        featured: f.featured,
        available: f.available,
        variants: f.variants.map((v) => ({
          id: v.id,
          optionName: f.optionName.trim() || "Option",
          value: v.value,
          priceAdjust: Number.isNaN(num(v.priceAdjust)) ? 0 : num(v.priceAdjust),
          stock: Number.isNaN(num(v.stock)) ? 0 : Math.max(0, Math.floor(num(v.stock))),
        })),
      });
      if (res.ok) {
        toast(f.id ? "Produit mis à jour" : "Produit créé");
        router.push("/admin/produits");
        router.refresh();
      } else {
        setError(res.error);
        toast(res.error, "error");
      }
    });
  }

  return (
    <form onSubmit={submit} className="grid gap-6 lg:grid-cols-3" noValidate>
      <div className="space-y-6 lg:col-span-2">
        <section className={`${card} space-y-5 p-6`}>
          <h2 className="font-display text-2xl font-semibold">Informations</h2>
          <div>
            <label htmlFor="p-name" className={label}>Nom du produit *</label>
            <input id="p-name" value={f.name} onChange={(e) => set("name", e.target.value)} className={input} required />
          </div>
          <div>
            <label htmlFor="p-short" className={label}>Résumé</label>
            <input id="p-short" value={f.shortDescription} onChange={(e) => set("shortDescription", e.target.value)} className={input} maxLength={240} placeholder="Une phrase d'accroche" />
          </div>
          <div>
            <label htmlFor="p-desc" className={label}>Description</label>
            <textarea id="p-desc" rows={7} value={f.description} onChange={(e) => set("description", e.target.value)} className={input} />
          </div>
        </section>

        <section className={`${card} p-6`}>
          <ImageUploader value={f.images} onChange={(v) => set("images", v)} label="Images du produit (la première est l'image principale)" />
        </section>

        <section className={`${card} space-y-4 p-6`}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl font-semibold">Variantes</h2>
              <p className="text-sm text-muted">Couleurs, tailles, finitions… Le stock est alors géré par variante.</p>
            </div>
            <button type="button" onClick={() => set("variants", [...f.variants, { value: "", priceAdjust: "0", stock: "0" }])} className={aOutline}>
              <Plus className="h-4 w-4" /> Ajouter une variante
            </button>
          </div>
          {hasVariants && (
            <>
              <div className="max-w-xs">
                <label htmlFor="p-opt" className={label}>Type d&apos;option</label>
                <input id="p-opt" value={f.optionName} onChange={(e) => set("optionName", e.target.value)} className={input} placeholder="Couleur, Taille, Format…" />
              </div>
              <ul className="space-y-3">
                <li className="hidden grid-cols-[1fr_120px_100px_40px] gap-3 text-xs font-medium uppercase tracking-wider text-muted sm:grid">
                  <span>Valeur</span><span>Ajust. prix (TND)</span><span>Stock</span><span />
                </li>
                {f.variants.map((v, i) => (
                  <li key={i} className="grid grid-cols-2 items-center gap-3 rounded-xl bg-cream/40 p-3 sm:grid-cols-[1fr_120px_100px_40px] sm:bg-transparent sm:p-0">
                    <input aria-label="Valeur" value={v.value} onChange={(e) => setVariant(i, { value: e.target.value })} className={`${input} col-span-2 sm:col-span-1`} placeholder="Ex : Bleu pétrole" />
                    <input aria-label="Ajustement de prix" inputMode="decimal" value={v.priceAdjust} onChange={(e) => setVariant(i, { priceAdjust: e.target.value })} className={input} />
                    <input aria-label="Stock" inputMode="numeric" value={v.stock} onChange={(e) => setVariant(i, { stock: e.target.value })} className={input} />
                    <button type="button" aria-label="Supprimer la variante" onClick={() => set("variants", f.variants.filter((_, k) => k !== i))} className="flex h-10 w-10 items-center justify-center rounded-lg text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </li>
                ))}
              </ul>
            </>
          )}
        </section>
      </div>

      <div className="space-y-6">
        <section className={`${card} space-y-5 p-6`}>
          <h2 className="font-display text-2xl font-semibold">Publication</h2>
          <label className="flex cursor-pointer items-center justify-between gap-3 text-sm">
            <span><span className="font-medium">Disponible à la vente</span><br /><span className="text-xs text-muted">Visible sur la boutique</span></span>
            <input type="checkbox" checked={f.available} onChange={(e) => set("available", e.target.checked)} className="h-5 w-5 accent-clay" />
          </label>
          <label className="flex cursor-pointer items-center justify-between gap-3 text-sm">
            <span><span className="font-medium">Produit à la une</span><br /><span className="text-xs text-muted">Mis en avant sur l&apos;accueil</span></span>
            <input type="checkbox" checked={f.featured} onChange={(e) => set("featured", e.target.checked)} className="h-5 w-5 accent-clay" />
          </label>
        </section>

        <section className={`${card} space-y-5 p-6`}>
          <h2 className="font-display text-2xl font-semibold">Prix & stock</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="p-price" className={label}>Prix (TND) *</label>
              <input id="p-price" inputMode="decimal" value={f.price} onChange={(e) => set("price", e.target.value)} className={input} required />
            </div>
            <div>
              <label htmlFor="p-compare" className={label}>Prix barré</label>
              <input id="p-compare" inputMode="decimal" value={f.comparePrice} onChange={(e) => set("comparePrice", e.target.value)} className={input} placeholder="Optionnel" />
            </div>
          </div>
          <div>
            <label htmlFor="p-stock" className={label}>Stock {hasVariants && <span className="font-normal text-muted">(géré par variante)</span>}</label>
            <input id="p-stock" inputMode="numeric" value={hasVariants ? String(f.variants.reduce((n, v) => n + (Number(v.stock) || 0), 0)) : f.stock} disabled={hasVariants} onChange={(e) => set("stock", e.target.value)} className={input} />
          </div>
          <div>
            <label htmlFor="p-sku" className={label}>Référence (SKU)</label>
            <input id="p-sku" value={f.sku} onChange={(e) => set("sku", e.target.value)} className={input} />
          </div>
        </section>

        <section className={`${card} space-y-5 p-6`}>
          <h2 className="font-display text-2xl font-semibold">Organisation</h2>
          <div>
            <label htmlFor="p-cat" className={label}>Catégorie</label>
            <select id="p-cat" value={f.categoryId} onChange={(e) => set("categoryId", e.target.value)} className={input}>
              <option value="">Sans catégorie</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="p-slug" className={label}>Lien (slug)</label>
            <input id="p-slug" value={f.slug} onChange={(e) => set("slug", e.target.value)} className={input} placeholder="généré automatiquement" />
          </div>
        </section>

        {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
        <div className="flex gap-3">
          <button disabled={pending} className={`${aPrimary} flex-1 py-3`}>
            {pending && <Loader2 className="h-4 w-4 animate-spin" />} {f.id ? "Enregistrer" : "Créer le produit"}
          </button>
          <button type="button" onClick={() => router.push("/admin/produits")} className={aOutline}>Annuler</button>
        </div>
      </div>
    </form>
  );
}
