"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import {
  ExternalLink, FolderTree, LayoutDashboard, LogOut, Mail, Menu, Package,
  Settings, ShoppingCart, Users, X,
} from "lucide-react";
import { logoutAction } from "@/app/actions/auth";
import { Logo } from "@/components/store/Header";

type Props = {
  adminName: string;
  adminEmail: string;
  pendingOrders: number;
  unreadMessages: number;
  children: React.ReactNode;
};

export function AdminShell({ adminName, adminEmail, pendingOrders, unreadMessages, children }: Props) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [pathname]);

  const nav = [
    { href: "/admin", label: "Tableau de bord", Icon: LayoutDashboard, exact: true },
    { href: "/admin/commandes", label: "Commandes", Icon: ShoppingCart, badge: pendingOrders },
    { href: "/admin/produits", label: "Produits", Icon: Package },
    { href: "/admin/categories", label: "Catégories", Icon: FolderTree },
    { href: "/admin/clients", label: "Clients", Icon: Users },
    { href: "/admin/messages", label: "Messages", Icon: Mail, badge: unreadMessages },
    { href: "/admin/parametres", label: "Paramètres", Icon: Settings },
  ];

  const sidebar = (
    <div className="flex h-full flex-col bg-ink text-ivory/80">
      <div className="flex items-center justify-between px-6 py-6">
        <Link href="/admin"><Logo light /></Link>
        <button onClick={() => setOpen(false)} aria-label="Fermer" className="rounded-full p-1.5 hover:bg-white/10 lg:hidden"><X className="h-5 w-5" /></button>
      </div>
      <nav className="flex-1 space-y-1 px-3" aria-label="Navigation administration">
        {nav.map(({ href, label, Icon, exact, badge }) => {
          const active = exact ? pathname === href : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? "page" : undefined}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
                active ? "bg-clay text-white" : "hover:bg-white/10 hover:text-ivory"
              }`}
            >
              <Icon className="h-[18px] w-[18px]" />
              <span className="flex-1">{label}</span>
              {!!badge && badge > 0 && (
                <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${active ? "bg-white/25" : "bg-clay text-white"}`}>{badge}</span>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="space-y-2 border-t border-white/10 p-4">
        <Link href="/" target="_blank" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-white/10">
          <ExternalLink className="h-4 w-4" /> Voir la boutique
        </Link>
        <div className="rounded-lg bg-white/5 px-3 py-2.5">
          <p className="truncate text-sm font-medium text-ivory">{adminName}</p>
          <p className="truncate text-xs text-ivory/50">{adminEmail}</p>
        </div>
        <form action={logoutAction}>
          <button className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-white/10">
            <LogOut className="h-4 w-4" /> Se déconnecter
          </button>
        </form>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f7f2e9] lg:grid lg:grid-cols-[260px_1fr]">
      <aside className="sticky top-0 hidden h-screen lg:block">{sidebar}</aside>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/60" onClick={() => setOpen(false)} />
          <div className="animate-toast absolute inset-y-0 left-0 w-72 shadow-2xl">{sidebar}</div>
        </div>
      )}
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-ivory/90 px-4 py-3 backdrop-blur lg:hidden">
          <button onClick={() => setOpen(true)} aria-label="Ouvrir le menu" className="rounded-lg p-2 hover:bg-cream"><Menu className="h-5 w-5" /></button>
          <span className="font-display text-xl font-semibold tracking-widest">ELYSSA <span className="text-xs text-clay">ADMIN</span></span>
        </header>
        <main className="p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
