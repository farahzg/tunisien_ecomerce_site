"use client";

import { useOptimistic, useTransition } from "react";
import { Loader2 } from "lucide-react";
import { updateOrderStatus } from "@/app/actions/admin";
import { ORDER_STATUSES, statusMeta } from "@/lib/constants";
import { useToast } from "@/components/ui/Toast";

export function OrderStatusSelect({ orderId, status, large }: { orderId: number; status: string; large?: boolean }) {
  const [optimistic, setOptimistic] = useOptimistic(status);
  const [pending, start] = useTransition();
  const { toast } = useToast();

  function onChange(next: string) {
    start(async () => {
      setOptimistic(next);
      const res = await updateOrderStatus(orderId, next);
      if (res.ok) toast(`Statut mis à jour : ${statusMeta(next).label}`);
      else toast(res.error, "error");
    });
  }

  return (
    <div className="relative inline-flex items-center">
      <select
        value={optimistic}
        onChange={(e) => onChange(e.target.value)}
        aria-label="Statut de la commande"
        className={`cursor-pointer appearance-none rounded-full pr-8 font-medium outline-none ring-1 transition focus:ring-2 ${statusMeta(optimistic).cls} ${
          large ? "py-2.5 pl-4 text-sm" : "py-1 pl-3 text-xs"
        }`}
      >
        {ORDER_STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
      </select>
      <span className="pointer-events-none absolute right-3 text-[10px]">
        {pending ? <Loader2 className="h-3 w-3 animate-spin" /> : "▾"}
      </span>
    </div>
  );
}
