"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Loader2, Trash2 } from "lucide-react";
import { deleteCustomer, saveCustomer } from "@/app/actions/admin";
import { ConfirmDialog } from "@/components/ui/Modal";
import { useToast } from "@/components/ui/Toast";
import { GOVERNORATES } from "@/lib/constants";
import { aOutline, aPrimary, input, label } from "@/components/ui/styles";

type C = { id: number; fullName: string; phone: string; email: string; governorate: string; city: string; address: string };

export function CustomerForm({ customer }: { customer: C }) {
  const router = useRouter();
  const { toast } = useToast();
  const [f, setF] = useState(customer);
  const [error, setError] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [pending, start] = useTransition();
  const set = (k: keyof C) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF((s) => ({ ...s, [k]: e.target.value }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    start(async () => {
      const res = await saveCustomer(f);
      if (res.ok) { toast("Informations client mises à jour"); router.refresh(); } else setError(res.error);
    });
  }

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <div>
        <label htmlFor="cu-name" className={label}>Nom complet</label>
        <input id="cu-name" value={f.fullName} onChange={set("fullName")} className={input} />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="cu-phone" className={label}>Téléphone</label>
          <input id="cu-phone" value={f.phone} onChange={set("phone")} className={input} />
        </div>
        <div>
          <label htmlFor="cu-email" className={label}>E-mail</label>
          <input id="cu-email" type="email" value={f.email} onChange={set("email")} className={input} />
        </div>
        <div>
          <label htmlFor="cu-gov" className={label}>Gouvernorat</label>
          <select id="cu-gov" value={f.governorate} onChange={set("governorate")} className={input}>
            <option value="">—</option>
            {GOVERNORATES.map((g) => <option key={g}>{g}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="cu-city" className={label}>Ville</label>
          <input id="cu-city" value={f.city} onChange={set("city")} className={input} />
        </div>
      </div>
      <div>
        <label htmlFor="cu-addr" className={label}>Adresse</label>
        <input id="cu-addr" value={f.address} onChange={set("address")} className={input} />
      </div>
      {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
      <div className="flex flex-wrap justify-between gap-3 pt-2">
        <button disabled={pending} className={aPrimary}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Enregistrer</button>
        <button type="button" onClick={() => setConfirm(true)} className={`${aOutline} text-rose-600`}><Trash2 className="h-4 w-4" /> Supprimer le client</button>
      </div>
      <ConfirmDialog
        open={confirm}
        onClose={() => setConfirm(false)}
        pending={pending}
        title="Supprimer ce client ?"
        message="La fiche client sera supprimée. Ses commandes restent conservées dans la liste des commandes."
        onConfirm={() => start(async () => {
          const r = await deleteCustomer(f.id);
          if (r.ok) { toast("Client supprimé"); router.push("/admin/clients"); router.refresh(); } else toast(r.error, "error");
        })}
      />
    </form>
  );
}
