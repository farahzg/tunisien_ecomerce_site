"use client";

import { useState, useTransition } from "react";
import { Loader2 } from "lucide-react";
import { updateOrderNotes } from "@/app/actions/admin";
import { useToast } from "@/components/ui/Toast";
import { aOutline, input } from "@/components/ui/styles";

export function OrderNotes({ orderId, initial }: { orderId: number; initial: string }) {
  const [value, setValue] = useState(initial);
  const [pending, start] = useTransition();
  const { toast } = useToast();
  return (
    <div>
      <label htmlFor="admin-notes" className="sr-only">Notes internes</label>
      <textarea id="admin-notes" rows={4} value={value} onChange={(e) => setValue(e.target.value)} className={input} placeholder="Notes visibles uniquement par l'équipe…" maxLength={1000} />
      <button
        disabled={pending || value === initial}
        onClick={() => start(async () => {
          const r = await updateOrderNotes(orderId, value);
          if (r.ok) toast("Notes enregistrées"); else toast(r.error, "error");
        })}
        className={`${aOutline} mt-3`}
      >
        {pending && <Loader2 className="h-4 w-4 animate-spin" />} Enregistrer les notes
      </button>
    </div>
  );
}
