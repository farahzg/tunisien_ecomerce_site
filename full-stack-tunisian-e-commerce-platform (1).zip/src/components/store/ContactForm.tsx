"use client";

import { useState, useTransition } from "react";
import { CheckCircle2, Loader2 } from "lucide-react";
import { sendContactMessage } from "@/app/actions/store";
import { btnClay, input, label } from "@/components/ui/styles";

export function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [done, setDone] = useState<string | null>(null);
  const [formError, setFormError] = useState("");
  const [pending, start] = useTransition();

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    setErrors((x) => ({ ...x, [k]: "" }));
  };

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError("");
    start(async () => {
      const res = await sendContactMessage(form);
      if (res.ok) {
        setDone(res.message ?? "Message envoyé.");
        setForm({ name: "", email: "", phone: "", message: "" });
        setErrors({});
      } else {
        setFormError(res.error);
        setErrors(res.fieldErrors ?? {});
      }
    });
  }

  if (done) {
    return (
      <div className="rounded-2xl border border-line bg-white p-10 text-center">
        <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
        <p className="mt-4 font-display text-2xl">{done}</p>
        <button onClick={() => setDone(null)} className="mt-6 text-sm text-clay underline-offset-4 hover:underline">Envoyer un autre message</button>
      </div>
    );
  }

  const err = (k: string) => errors[k] && <p role="alert" className="mt-1.5 text-xs text-rose-600">{errors[k]}</p>;

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5 rounded-2xl border border-line bg-white p-6 sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="c-name" className={label}>Nom *</label>
          <input id="c-name" value={form.name} onChange={set("name")} className={input} autoComplete="name" aria-invalid={!!errors.name} />
          {err("name")}
        </div>
        <div>
          <label htmlFor="c-phone" className={label}>Téléphone</label>
          <input id="c-phone" type="tel" value={form.phone} onChange={set("phone")} className={input} autoComplete="tel" />
        </div>
      </div>
      <div>
        <label htmlFor="c-email" className={label}>E-mail</label>
        <input id="c-email" type="email" value={form.email} onChange={set("email")} className={input} autoComplete="email" aria-invalid={!!errors.email} />
        {err("email")}
      </div>
      <div>
        <label htmlFor="c-message" className={label}>Message *</label>
        <textarea id="c-message" rows={6} value={form.message} onChange={set("message")} className={input} aria-invalid={!!errors.message} maxLength={2000} />
        {err("message")}
      </div>
      {formError && !Object.keys(errors).length && <p role="alert" className="text-sm text-rose-600">{formError}</p>}
      <button disabled={pending} className={btnClay}>
        {pending && <Loader2 className="h-4 w-4 animate-spin" />} Envoyer le message
      </button>
    </form>
  );
}
