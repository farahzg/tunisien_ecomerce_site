"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export function ProductGallery({ images, name }: { images: string[]; name: string }) {
  const [i, setI] = useState(0);
  if (images.length === 0) {
    return <div className="flex aspect-[4/5] items-center justify-center rounded-3xl bg-cream text-muted">Pas d&apos;image</div>;
  }
  const go = (d: number) => setI((x) => (x + d + images.length) % images.length);
  return (
    <div className="flex flex-col-reverse gap-4 lg:flex-row">
      {images.length > 1 && (
        <div className="flex gap-3 overflow-x-auto lg:max-h-[640px] lg:flex-col lg:overflow-y-auto" role="tablist" aria-label="Vignettes">
          {images.map((src, idx) => (
            <button
              key={src + idx}
              role="tab"
              aria-selected={idx === i}
              aria-label={`Image ${idx + 1}`}
              onClick={() => setI(idx)}
              className={`h-20 w-16 shrink-0 overflow-hidden rounded-xl border-2 transition ${idx === i ? "border-clay" : "border-transparent opacity-70 hover:opacity-100"}`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt="" loading="lazy" className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      )}
      <div className="group relative aspect-[4/5] flex-1 overflow-hidden rounded-3xl bg-cream">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img key={images[i]} src={images[i]} alt={`${name} — vue ${i + 1}`} fetchPriority="high" className="animate-fade-up h-full w-full object-cover" />
        {images.length > 1 && (
          <>
            <button onClick={() => go(-1)} aria-label="Image précédente" className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2.5 opacity-100 shadow transition hover:bg-white sm:opacity-0 sm:group-hover:opacity-100">
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button onClick={() => go(1)} aria-label="Image suivante" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2.5 opacity-100 shadow transition hover:bg-white sm:opacity-0 sm:group-hover:opacity-100">
              <ChevronRight className="h-5 w-5" />
            </button>
            <span className="absolute bottom-3 right-3 rounded-full bg-ink/70 px-3 py-1 text-xs text-ivory">{i + 1} / {images.length}</span>
          </>
        )}
      </div>
    </div>
  );
}
