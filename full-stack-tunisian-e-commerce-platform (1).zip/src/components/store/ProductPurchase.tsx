"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Check, Minus, Plus, ShoppingBag } from "lucide-react";
import { useCart } from "@/components/cart/CartProvider";
import { formatTND } from "@/lib/format";
import { LOW_STOCK_THRESHOLD } from "@/lib/constants";

type Variant = { id: number; optionName: string; value: string; priceAdjust: number; stock: number };
type Props = {
  product: { id: number; slug: string; name: string; price: number; comparePrice: number | null; image: string; stock: number };
  variants: Variant[];
};

export function ProductPurchase({ product, variants }: Props) {
  const router = useRouter();
  const { add } = useCart();
  const hasVariants = variants.length > 0;
  const [variantId, setVariantId] = useState<number | null>(
    variants.find((v) => v.stock > 0)?.id ?? null,
  );
  const [qty, setQty] = useState(1);
  const [error, setError] = useState("");

  const variant = variants.find((v) => v.id === variantId) ?? null;
  const price = product.price + (variant?.priceAdjust ?? 0);
  const stock = hasVariants ? (variant?.stock ?? 0) : product.stock;
  const soldOut = hasVariants ? variants.every((v) => v.stock <= 0) : product.stock <= 0;
  const optionName = variants[0]?.optionName ?? "Option";

  function addToCart(goToCart: boolean) {
    if (hasVariants && !variant) return setError(`Veuillez choisir : ${optionName.toLowerCase()}`);
    if (stock <= 0) return;
    setError("");
    add(
      {
        productId: product.id,
        variantId: variant?.id ?? null,
        slug: product.slug,
        name: product.name,
        variantLabel: variant ? variant.value : "",
        price,
        image: product.image,
        max: stock,
      },
      qty,
    );
    if (goToCart) router.push("/panier");
  }

  return (
    <div>
      <div className="flex items-baseline gap-3">
        <p className="font-display text-4xl font-semibold">{formatTND(price)}</p>
        {product.comparePrice && product.comparePrice > product.price && (
          <p className="text-lg text-muted line-through">{formatTND(product.comparePrice + (variant?.priceAdjust ?? 0))}</p>
        )}
      </div>

      <p className="mt-3 flex items-center gap-2 text-sm" aria-live="polite">
        {soldOut ? (
          <span className="inline-flex items-center gap-2 text-rose-600"><span className="h-2 w-2 rounded-full bg-rose-500" /> Épuisé</span>
        ) : stock <= 0 ? (
          <span className="inline-flex items-center gap-2 text-rose-600"><span className="h-2 w-2 rounded-full bg-rose-500" /> Cette option est épuisée</span>
        ) : stock <= LOW_STOCK_THRESHOLD ? (
          <span className="inline-flex items-center gap-2 text-amber-700"><span className="h-2 w-2 rounded-full bg-amber-500" /> Plus que {stock} en stock</span>
        ) : (
          <span className="inline-flex items-center gap-2 text-emerald-700"><span className="h-2 w-2 rounded-full bg-emerald-500" /> En stock</span>
        )}
      </p>

      {hasVariants && (
        <fieldset className="mt-6">
          <legend className="mb-3 text-sm font-medium">
            {optionName} : <span className="font-normal text-muted">{variant?.value ?? "—"}</span>
          </legend>
          <div className="flex flex-wrap gap-2.5">
            {variants.map((v) => {
              const active = v.id === variantId;
              const out = v.stock <= 0;
              return (
                <button
                  key={v.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => { setVariantId(v.id); setQty(1); setError(""); }}
                  className={`relative rounded-full border px-5 py-2.5 text-sm transition ${
                    active ? "border-ink bg-ink text-ivory" : "border-line bg-white hover:border-ink"
                  } ${out ? "opacity-50" : ""}`}
                >
                  <span className={out ? "line-through" : ""}>{v.value}</span>
                  {v.priceAdjust !== 0 && !active && (
                    <span className="ml-1.5 text-xs opacity-70">{v.priceAdjust > 0 ? "+" : ""}{formatTND(v.priceAdjust)}</span>
                  )}
                </button>
              );
            })}
          </div>
        </fieldset>
      )}

      <div className="mt-7 flex flex-wrap items-center gap-4">
        <div className="inline-flex items-center rounded-full border border-line bg-white" role="group" aria-label="Quantité">
          <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} disabled={qty <= 1} aria-label="Diminuer la quantité" className="p-3.5 hover:text-clay disabled:opacity-40">
            <Minus className="h-4 w-4" />
          </button>
          <span className="w-10 text-center text-sm font-medium tabular-nums" aria-live="polite">{qty}</span>
          <button type="button" onClick={() => setQty((q) => Math.min(Math.max(stock, 1), q + 1))} disabled={qty >= stock} aria-label="Augmenter la quantité" className="p-3.5 hover:text-clay disabled:opacity-40">
            <Plus className="h-4 w-4" />
          </button>
        </div>
        <button
          type="button"
          onClick={() => addToCart(false)}
          disabled={soldOut || (hasVariants && stock <= 0)}
          className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-ink px-8 py-3.5 text-sm font-medium tracking-wide text-ivory transition hover:bg-clay disabled:cursor-not-allowed disabled:bg-muted/40"
        >
          <ShoppingBag className="h-[18px] w-[18px]" /> {soldOut ? "Produit épuisé" : "Ajouter au panier"}
        </button>
      </div>
      {error && <p role="alert" className="mt-3 text-sm text-rose-600">{error}</p>}
      {!soldOut && (
        <button
          type="button"
          onClick={() => addToCart(true)}
          disabled={hasVariants && stock <= 0}
          className="mt-3 w-full rounded-full border border-ink/25 px-8 py-3.5 text-sm font-medium transition hover:border-clay hover:text-clay disabled:opacity-50"
        >
          Acheter maintenant
        </button>
      )}
      <ul className="mt-6 space-y-2 text-sm text-muted">
        {["Paiement à la livraison (COD)", "Livraison partout en Tunisie", "Emballage soigné, prêt à offrir"].map((t) => (
          <li key={t} className="flex items-center gap-2"><Check className="h-4 w-4 text-olive" /> {t}</li>
        ))}
      </ul>
    </div>
  );
}
