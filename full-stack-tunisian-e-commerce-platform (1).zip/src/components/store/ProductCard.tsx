import Link from "next/link";
import type { ProductCardData } from "@/lib/queries";
import { formatTND } from "@/lib/format";
import { LOW_STOCK_THRESHOLD } from "@/lib/constants";
import { QuickAdd } from "./QuickAdd";

const DAY = 24 * 3600 * 1000;

export function ProductCard({ product: p, priority }: { product: ProductCardData; priority?: boolean }) {
  const soldOut = p.stock <= 0;
  const discount =
    p.comparePrice && p.comparePrice > p.price
      ? Math.round((1 - p.price / p.comparePrice) * 100)
      : 0;
  const isNew = Date.now() - new Date(p.createdAt).getTime() < 10 * DAY;
  const [first, second] = p.images;

  return (
    <article className="group relative">
      <Link href={`/produits/${p.slug}`} className="block" aria-label={p.name}>
        <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-cream">
          {first ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={first}
              alt={p.name}
              loading={priority ? "eager" : "lazy"}
              decoding="async"
              className={`absolute inset-0 h-full w-full object-cover transition duration-700 ${
                second ? "group-hover:opacity-0" : "group-hover:scale-105"
              } ${soldOut ? "opacity-70 grayscale-[30%]" : ""}`}
            />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-muted">Pas d&apos;image</div>
          )}
          {second && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={second}
              alt=""
              loading="lazy"
              decoding="async"
              className="absolute inset-0 h-full w-full scale-105 object-cover opacity-0 transition duration-700 group-hover:scale-100 group-hover:opacity-100"
            />
          )}
          <div className="absolute left-3 top-3 flex flex-col items-start gap-1.5">
            {soldOut && (
              <span className="rounded-full bg-ink px-3 py-1 text-[11px] font-medium tracking-wide text-ivory">Épuisé</span>
            )}
            {!soldOut && discount > 0 && (
              <span className="rounded-full bg-clay px-3 py-1 text-[11px] font-medium text-white">−{discount}%</span>
            )}
            {!soldOut && isNew && (
              <span className="rounded-full bg-white/95 px-3 py-1 text-[11px] font-medium tracking-wide text-ink">Nouveau</span>
            )}
            {!soldOut && p.stock <= LOW_STOCK_THRESHOLD && (
              <span className="rounded-full bg-amber-100 px-3 py-1 text-[11px] font-medium text-amber-800">
                Plus que {p.stock}
              </span>
            )}
          </div>
        </div>
        <div className="mt-4 space-y-1">
          {p.categoryName && (
            <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted">{p.categoryName}</p>
          )}
          <h3 className="font-display text-xl font-semibold leading-snug transition group-hover:text-clay">{p.name}</h3>
          <p className="flex items-baseline gap-2 text-sm">
            <span className="font-semibold">
              {p.hasVariants ? "À partir de " : ""}
              {formatTND(p.price)}
            </span>
            {discount > 0 && (
              <span className="text-xs text-muted line-through">{formatTND(p.comparePrice)}</span>
            )}
          </p>
        </div>
      </Link>
      {!soldOut && !p.hasVariants && (
        <QuickAdd
          product={{ id: p.id, slug: p.slug, name: p.name, price: p.price, image: first ?? "", stock: p.stock }}
        />
      )}
    </article>
  );
}
