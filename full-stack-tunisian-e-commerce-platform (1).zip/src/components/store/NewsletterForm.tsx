"use client";

import { useState, useTransition } from "react";
import { subscribeNewsletter } from "@/app/actions/store";
import { Loader2 } from "lucide-react";

export function NewsletterForm({ dark }: { dark?: boolean }) {
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    start(async () => {
      const res = await subscribeNewsletter(email);
      if (res.ok) {
        setMsg({ ok: true, text: res.message ?? "Merci !" });
        setEmail("");
      } else {
        setMsg({ ok: false, text: res.error });
      }
    });
  }

  return (
    <form onSubmit={onSubmit} noValidate className="w-full">
      <div className="flex flex-col gap-2 sm:flex-row">
        <label htmlFor="newsletter-email" className="sr-only">Adresse e-mail</label>
        <input
          id="newsletter-email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Votre adresse e-mail"
          className={`flex-1 rounded-full border px-5 py-3 text-sm outline-none transition focus:ring-2 focus:ring-clay/30 ${
            dark ? "border-white/20 bg-white/10 text-ivory placeholder:text-ivory/50" : "border-line bg-white"
          }`}
        />
        <button
          disabled={pending}
          className="inline-flex items-center justify-center gap-2 rounded-full bg-clay px-7 py-3 text-sm font-medium text-white transition hover:bg-clay-dark disabled:opacity-60"
        >
          {pending && <Loader2 className="h-4 w-4 animate-spin" />} S&apos;inscrire
        </button>
      </div>
      {msg && (
        <p role="status" className={`mt-3 text-sm ${msg.ok ? (dark ? "text-emerald-300" : "text-emerald-700") : "text-rose-500"}`}>
          {msg.text}
        </p>
      )}
    </form>
  );
}
