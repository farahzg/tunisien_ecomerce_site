"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Search, ShoppingBag, User, X, ChevronDown } from "lucide-react";
import { useCart } from "@/components/cart/CartProvider";

type Props = {
  categories: { name: string; slug: string }[];
  announcement: string | null;
};

export function Logo({ light }: { light?: boolean }) {
  return (
    <span className={`inline-flex flex-col items-center leading-none ${light ? "text-ivory" : "text-ink"}`}>
      <span className="font-display text-[1.7rem] font-semibold tracking-[0.28em] sm:text-[2rem]">ELYSSA</span>
      <span className="mt-1 text-[0.58rem] font-medium tracking-[0.55em] text-clay">ARTISANAT</span>
    </span>
  );
}

export function Header({ categories, announcement }: Props) {
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const { count, ready } = useCart();
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    setOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    const v = q.trim();
    router.push(v ? `/boutique?q=${encodeURIComponent(v)}` : "/boutique");
  }

  const link = "text-sm tracking-wide text-ink/80 transition hover:text-clay";

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-ivory/90 backdrop-blur-md">
      {announcement && (
        <div className="bg-ink px-4 py-2 text-center text-xs tracking-wide text-ivory">
          {announcement}
        </div>
      )}
      <div className="container-x flex h-[72px] items-center justify-between gap-4">
        <div className="flex flex-1 items-center gap-1 lg:hidden">
          <button
            onClick={() => setOpen(true)}
            aria-label="Ouvrir le menu"
            className="rounded-full p-2 hover:bg-cream"
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>

        <nav className="hidden flex-1 items-center gap-7 lg:flex" aria-label="Navigation principale">
          <Link href="/boutique" className={link}>Boutique</Link>
          <div className="group relative">
            <button className={`${link} inline-flex items-center gap-1`} aria-haspopup="true">
              Catégories <ChevronDown className="h-3.5 w-3.5 transition group-hover:rotate-180" />
            </button>
            <div className="invisible absolute left-0 top-full z-10 pt-3 opacity-0 transition group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
              <div className="w-60 rounded-xl border border-line bg-white p-2 shadow-xl shadow-black/5">
                {categories.map((c) => (
                  <Link
                    key={c.slug}
                    href={`/boutique?categorie=${c.slug}`}
                    className="block rounded-lg px-3 py-2 text-sm hover:bg-cream hover:text-clay"
                  >
                    {c.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
          <Link href="/a-propos" className={link}>Notre histoire</Link>
        </nav>

        <Link href="/" aria-label="ELYSSA ARTISANAT — Accueil" className="shrink-0">
          <Logo />
        </Link>

        <div className="flex flex-1 items-center justify-end gap-1">
          <nav className="mr-4 hidden items-center gap-7 lg:flex">
            <Link href="/boutiques" className={link}>Nos boutiques</Link>
            <Link href="/contact" className={link}>Contact</Link>
          </nav>
          <button
            onClick={() => setSearchOpen((s) => !s)}
            aria-label="Rechercher"
            aria-expanded={searchOpen}
            className="rounded-full p-2 hover:bg-cream"
          >
            <Search className="h-5 w-5" />
          </button>
          <Link
            href="/suivi-commande"
            aria-label="Mon compte — suivre ma commande"
            className="hidden rounded-full p-2 hover:bg-cream sm:block"
          >
            <User className="h-5 w-5" />
          </Link>
          <Link href="/panier" aria-label={`Panier (${count} articles)`} className="relative rounded-full p-2 hover:bg-cream">
            <ShoppingBag className="h-5 w-5" />
            {ready && count > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-clay px-1 text-[10px] font-semibold text-white">
                {count}
              </span>
            )}
          </Link>
        </div>
      </div>

      {searchOpen && (
        <div className="border-t border-line bg-cream/60">
          <form onSubmit={submitSearch} className="container-x flex items-center gap-3 py-3" role="search">
            <Search className="h-5 w-5 text-muted" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Rechercher un produit : cafetière, collier, coussin…"
              aria-label="Rechercher un produit"
              className="flex-1 bg-transparent text-base outline-none placeholder:text-muted/70"
            />
            <button className="rounded-full bg-ink px-5 py-2 text-sm text-ivory hover:bg-clay">Rechercher</button>
          </form>
        </div>
      )}

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="absolute inset-0 bg-ink/50" onClick={() => setOpen(false)} />
          <div className="animate-toast absolute inset-y-0 left-0 flex w-[84%] max-w-sm flex-col bg-ivory p-6 shadow-2xl">
            <div className="mb-8 flex items-center justify-between">
              <Logo />
              <button onClick={() => setOpen(false)} aria-label="Fermer le menu" className="rounded-full p-2 hover:bg-cream">
                <X className="h-6 w-6" />
              </button>
            </div>
            <nav className="flex flex-col gap-1 text-lg" aria-label="Menu mobile">
              <Link href="/boutique" className="rounded-lg px-3 py-2.5 font-display text-2xl hover:bg-cream">Toute la boutique</Link>
              <div className="my-2 ml-3 flex flex-col border-l border-line pl-4">
                {categories.map((c) => (
                  <Link key={c.slug} href={`/boutique?categorie=${c.slug}`} className="py-2 text-base text-ink/80 hover:text-clay">
                    {c.name}
                  </Link>
                ))}
              </div>
              <Link href="/a-propos" className="rounded-lg px-3 py-2.5 font-display text-2xl hover:bg-cream">Notre histoire</Link>
              <Link href="/boutiques" className="rounded-lg px-3 py-2.5 font-display text-2xl hover:bg-cream">Nos boutiques</Link>
              <Link href="/contact" className="rounded-lg px-3 py-2.5 font-display text-2xl hover:bg-cream">Contact</Link>
              <Link href="/suivi-commande" className="rounded-lg px-3 py-2.5 font-display text-2xl hover:bg-cream">Suivre ma commande</Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
