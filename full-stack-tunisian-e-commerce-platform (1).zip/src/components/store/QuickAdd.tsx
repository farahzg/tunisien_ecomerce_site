"use client";

import { ShoppingBag } from "lucide-react";
import { useCart } from "@/components/cart/CartProvider";

export function QuickAdd({
  product,
}: {
  product: { id: number; slug: string; name: string; price: number; image: string; stock: number };
}) {
  const { add } = useCart();
  return (
    <button
      type="button"
      onClick={() =>
        add({
          productId: product.id,
          variantId: null,
          slug: product.slug,
          name: product.name,
          variantLabel: "",
          price: product.price,
          image: product.image,
          max: product.stock,
        })
      }
      aria-label={`Ajouter ${product.name} au panier`}
      className="absolute bottom-3 right-3 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/95 text-ink shadow-lg transition hover:bg-clay hover:text-white sm:translate-y-2 sm:opacity-0 sm:group-hover:translate-y-0 sm:group-hover:opacity-100 sm:focus:translate-y-0 sm:focus:opacity-100"
    >
      <ShoppingBag className="h-[18px] w-[18px]" />
    </button>
  );
}
