import Link from "next/link";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import type { StoreSettings } from "@/lib/settings-defaults";
import { FacebookIcon, InstagramIcon, TikTokIcon } from "@/components/icons";
import { Logo } from "./Header";
import { NewsletterForm } from "./NewsletterForm";

export function Footer({
  settings,
  categories,
}: {
  settings: StoreSettings;
  categories: { name: string; slug: string }[];
}) {
  const { store, social, locations } = settings;
  const socials = [
    { href: social.instagram, label: "Instagram", Icon: InstagramIcon },
    { href: social.facebook, label: "Facebook", Icon: FacebookIcon },
    { href: social.tiktok, label: "TikTok", Icon: TikTokIcon },
  ].filter((s) => s.href);

  return (
    <footer className="mt-24 bg-ink text-ivory/80">
      <div className="pattern-zellige border-b border-white/10">
        <div className="container-x grid gap-8 py-14 md:grid-cols-2 md:items-center">
          <div>
            <h2 className="font-display text-3xl text-ivory sm:text-4xl">Restez dans l&apos;atelier</h2>
            <p className="mt-2 max-w-md text-sm text-ivory/70">
              Nouveautés, collections et invitations à nos événements : une lettre par mois, jamais plus.
            </p>
          </div>
          <NewsletterForm dark />
        </div>
      </div>

      <div className="container-x grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo light />
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-ivory/70">{store.tagline}</p>
          <div className="mt-5 flex gap-3">
            {socials.map(({ href, label, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="rounded-full border border-white/20 p-2.5 transition hover:border-clay hover:bg-clay"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-4 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-ivory">Boutique</h3>
          <ul className="space-y-2.5 text-sm">
            <li><Link className="hover:text-clay" href="/boutique">Tous les produits</Link></li>
            {categories.map((c) => (
              <li key={c.slug}>
                <Link className="hover:text-clay" href={`/boutique?categorie=${c.slug}`}>{c.name}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="mb-4 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-ivory">Informations</h3>
          <ul className="space-y-2.5 text-sm">
            <li><Link className="hover:text-clay" href="/a-propos">Notre histoire</Link></li>
            <li><Link className="hover:text-clay" href="/boutiques">Nos boutiques</Link></li>
            <li><Link className="hover:text-clay" href="/contact">Contact</Link></li>
            <li><Link className="hover:text-clay" href="/suivi-commande">Suivre ma commande</Link></li>
            <li><Link className="hover:text-clay" href="/panier">Mon panier</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-4 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-ivory">Nous trouver</h3>
          <ul className="space-y-3 text-sm">
            {locations.map((l) => (
              <li key={l.name} className="flex gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
                <span>
                  <strong className="font-medium text-ivory">{l.name}</strong>
                  <br />
                  {l.address}
                </span>
              </li>
            ))}
            <li className="flex gap-2.5"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-clay" />{store.hours}</li>
            <li className="flex gap-2.5">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
              <a href={`tel:+216${store.phone.replace(/\s/g, "")}`} className="hover:text-clay">{store.phone}</a>
            </li>
            <li className="flex gap-2.5">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
              <a href={`mailto:${store.email}`} className="break-all hover:text-clay">{store.email}</a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-x flex flex-col items-center justify-between gap-2 py-5 text-xs text-ivory/50 sm:flex-row">
          <p>© {new Date().getFullYear()} {store.name}. Tous droits réservés.</p>
          <p>Paiement à la livraison · Livraison dans toute la Tunisie · Prix en TND</p>
        </div>
      </div>
    </footer>
  );
}
