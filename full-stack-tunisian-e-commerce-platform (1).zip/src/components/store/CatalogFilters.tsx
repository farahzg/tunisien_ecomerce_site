"use client";

import { useRouter, usePathname } from "next/navigation";
import { useState, useTransition } from "react";
import { Loader2, Search, SlidersHorizontal, X } from "lucide-react";
import { input } from "@/components/ui/styles";

type Props = {
  categories: { name: string; slug: string; count: number }[];
  sorts: readonly { value: string; label: string }[];
  current: { q: string; categorie: string; tri: string; min: string; max: string; dispo: boolean };
};

export function CatalogFilters({ categories, sorts, current }: Props) {
  const router = useRouter();
  const pathname = usePathname();
  const [pending, start] = useTransition();
  const [q, setQ] = useState(current.q);
  const [min, setMin] = useState(current.min);
  const [max, setMax] = useState(current.max);
  const [showMore, setShowMore] = useState(false);

  function push(patch: Partial<Record<string, string | boolean>>) {
    const next = { ...current, q, min, max, ...patch } as Record<string, string | boolean>;
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(next)) {
      if (v === "" || v === false || v == null) continue;
      if (k === "tri" && v === "nouveautes") continue;
      params.set(k, v === true ? "1" : String(v));
    }
    const qs = params.toString();
    start(() => router.push(qs ? `${pathname}?${qs}` : pathname, { scroll: false }));
  }

  const hasFilters = !!(current.q || current.categorie || current.min || current.max || current.dispo);

  const pill = (active: boolean) =>
    `whitespace-nowrap rounded-full border px-4 py-2 text-sm transition ${
      active ? "border-ink bg-ink text-ivory" : "border-line bg-white hover:border-clay hover:text-clay"
    }`;

  return (
    <div className="space-y-5">
      <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 sm:mx-0 sm:flex-wrap sm:px-0" role="tablist" aria-label="Catégories">
        <button className={pill(!current.categorie)} onClick={() => push({ categorie: "" })}>Tout voir</button>
        {categories.map((c) => (
          <button key={c.slug} className={pill(current.categorie === c.slug)} onClick={() => push({ categorie: c.slug })}>
            {c.name} <span className="opacity-60">({c.count})</span>
          </button>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <form
          onSubmit={(e) => { e.preventDefault(); push({ q }); }}
          className="relative min-w-[220px] flex-1 sm:max-w-sm"
          role="search"
        >
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Rechercher par nom…"
            aria-label="Rechercher un produit par nom"
            className={`${input} pl-10 pr-9`}
          />
          {q && (
            <button type="button" aria-label="Effacer" onClick={() => { setQ(""); push({ q: "" }); }} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-ink">
              <X className="h-4 w-4" />
            </button>
          )}
        </form>

        <select
          aria-label="Trier par"
          value={current.tri}
          onChange={(e) => push({ tri: e.target.value })}
          className={`${input} w-auto min-w-[10rem]`}
        >
          {sorts.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>

        <button
          type="button"
          onClick={() => setShowMore((s) => !s)}
          aria-expanded={showMore}
          className="inline-flex items-center gap-2 rounded-lg border border-line bg-white px-4 py-2.5 text-sm hover:border-clay"
        >
          <SlidersHorizontal className="h-4 w-4" /> Filtres
        </button>

        {pending && <Loader2 className="h-5 w-5 animate-spin text-clay" aria-label="Chargement" />}
        {hasFilters && !pending && (
          <button onClick={() => { setQ(""); setMin(""); setMax(""); start(() => router.push(pathname, { scroll: false })); }} className="text-sm text-clay underline-offset-4 hover:underline">
            Réinitialiser
          </button>
        )}
      </div>

      {showMore && (
        <form
          onSubmit={(e) => { e.preventDefault(); push({}); }}
          className="flex flex-wrap items-end gap-4 rounded-2xl border border-line bg-white p-4"
        >
          <div>
            <label htmlFor="pmin" className="mb-1 block text-xs font-medium text-muted">Prix min (TND)</label>
            <input id="pmin" inputMode="numeric" value={min} onChange={(e) => setMin(e.target.value.replace(/[^\d.]/g, ""))} placeholder="0" className={`${input} w-28`} />
          </div>
          <div>
            <label htmlFor="pmax" className="mb-1 block text-xs font-medium text-muted">Prix max (TND)</label>
            <input id="pmax" inputMode="numeric" value={max} onChange={(e) => setMax(e.target.value.replace(/[^\d.]/g, ""))} placeholder="500" className={`${input} w-28`} />
          </div>
          <label className="flex cursor-pointer items-center gap-2 pb-2.5 text-sm">
            <input
              type="checkbox"
              checked={current.dispo}
              onChange={(e) => push({ dispo: e.target.checked })}
              className="h-4 w-4 accent-clay"
            />
            En stock uniquement
          </label>
          <button className="rounded-lg bg-ink px-5 py-2.5 text-sm text-ivory hover:bg-clay">Appliquer</button>
        </form>
      )}
    </div>
  );
}
