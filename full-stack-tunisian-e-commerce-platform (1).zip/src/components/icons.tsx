type P = { className?: string };

export function InstagramIcon({ className }: P) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className={className} aria-hidden>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function FacebookIcon({ className }: P) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M13.5 21v-7.5h2.6l.5-3h-3.1V8.6c0-.9.3-1.5 1.6-1.5h1.6V4.4c-.3 0-1.2-.1-2.3-.1-2.3 0-3.9 1.4-3.9 4v2.2H7.8v3h2.7V21h3z" />
    </svg>
  );
}

export function TikTokIcon({ className }: P) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M16.6 3c.3 2.2 1.6 3.6 3.9 3.8v2.8c-1.4.1-2.6-.3-3.8-1.1v6.2c0 3.9-3.2 6.1-6.3 5.4-2.5-.6-4.1-3-3.7-5.6.4-2.7 2.9-4.5 5.6-4v2.9c-1.6-.4-3 .6-3 2.1 0 1.5 1.5 2.4 2.8 1.9.9-.3 1.4-1.1 1.4-2.1V3h3.1z" />
    </svg>
  );
}

export function StarPattern({ className }: P) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M12 1l2.2 6.3L20.5 5l-2.3 6.3L24 12l-5.8.7L20.5 19l-6.3-2.3L12 23l-2.2-6.3L3.5 19l2.3-6.3L0 12l5.8-.7L3.5 5l6.3 2.3z" />
    </svg>
  );
}
