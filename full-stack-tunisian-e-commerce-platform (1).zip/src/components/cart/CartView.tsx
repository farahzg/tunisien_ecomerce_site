"use client";

import Link from "next/link";
import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useCart } from "./CartProvider";
import { formatTND } from "@/lib/format";
import { btnClay, btnOutline } from "@/components/ui/styles";

export function CartView({ freeThreshold }: { freeThreshold: number }) {
  const { items, ready, subtotal, setQty, remove, clear } = useCart();

  if (!ready) {
    return (
      <div className="space-y-4" aria-busy="true">
        {[0, 1].map((i) => <div key={i} className="skeleton h-32 w-full rounded-2xl" />)}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="rounded-3xl border border-dashed border-line bg-white/60 px-6 py-24 text-center">
        <ShoppingBag className="mx-auto h-14 w-14 text-beige" />
        <h2 className="mt-5 font-display text-3xl">Votre panier est vide</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted">
          Découvrez nos créations artisanales et ajoutez vos coups de cœur.
        </p>
        <Link href="/boutique" className={`${btnClay} mt-7`}>Découvrir la boutique</Link>
      </div>
    );
  }

  const remaining = Math.max(0, freeThreshold - subtotal);
  const progress = freeThreshold > 0 ? Math.min(100, (subtotal / freeThreshold) * 100) : 100;

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
      <div>
        <ul className="divide-y divide-line rounded-2xl border border-line bg-white">
          {items.map((i) => (
            <li key={i.key} className="flex gap-4 p-4 sm:gap-6 sm:p-5">
              <Link href={`/produits/${i.slug}`} className="h-28 w-24 shrink-0 overflow-hidden rounded-xl bg-cream sm:h-32 sm:w-28">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={i.image} alt={i.name} className="h-full w-full object-cover" />
              </Link>
              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex justify-between gap-3">
                  <div className="min-w-0">
                    <Link href={`/produits/${i.slug}`} className="font-display text-xl font-semibold leading-tight hover:text-clay">{i.name}</Link>
                    {i.variantLabel && <p className="mt-0.5 text-sm text-muted">{i.variantLabel}</p>}
                    <p className="mt-1 text-sm text-muted">{formatTND(i.price)}</p>
                  </div>
                  <p className="whitespace-nowrap font-semibold">{formatTND(i.price * i.qty)}</p>
                </div>
                <div className="mt-auto flex items-center justify-between pt-3">
                  <div className="inline-flex items-center rounded-full border border-line" role="group" aria-label={`Quantité de ${i.name}`}>
                    <button onClick={() => setQty(i.key, i.qty - 1)} disabled={i.qty <= 1} aria-label="Diminuer" className="p-2.5 hover:text-clay disabled:opacity-40">
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-8 text-center text-sm tabular-nums">{i.qty}</span>
                    <button onClick={() => setQty(i.key, i.qty + 1)} disabled={i.qty >= i.max} aria-label="Augmenter" className="p-2.5 hover:text-clay disabled:opacity-40">
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <button onClick={() => remove(i.key)} className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-rose-600">
                    <Trash2 className="h-4 w-4" /> <span className="hidden sm:inline">Retirer</span>
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
        <button onClick={clear} className="mt-4 text-sm text-muted underline-offset-4 hover:text-rose-600 hover:underline">
          Vider le panier
        </button>
      </div>

      <aside className="h-fit rounded-2xl border border-line bg-white p-6 lg:sticky lg:top-32">
        <h2 className="font-display text-2xl font-semibold">Récapitulatif</h2>
        {freeThreshold > 0 && (
          <div className="mt-4 rounded-xl bg-cream/70 p-3.5 text-sm">
            {remaining > 0 ? (
              <p>Plus que <strong>{formatTND(remaining)}</strong> pour la livraison offerte.</p>
            ) : (
              <p className="font-medium text-olive">🎉 La livraison est offerte !</p>
            )}
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-sand">
              <div className="h-full rounded-full bg-clay transition-all" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}
        <dl className="mt-5 space-y-3 text-sm">
          <div className="flex justify-between"><dt className="text-muted">Sous-total</dt><dd className="font-medium">{formatTND(subtotal)}</dd></div>
          <div className="flex justify-between"><dt className="text-muted">Livraison</dt><dd className="text-muted">Calculée à l&apos;étape suivante</dd></div>
          <div className="flex justify-between border-t border-line pt-4 text-base"><dt className="font-semibold">Total estimé</dt><dd className="font-display text-2xl font-semibold">{formatTND(subtotal)}</dd></div>
        </dl>
        <Link href="/commande" className={`${btnClay} mt-6 w-full`}>Passer la commande</Link>
        <Link href="/boutique" className={`${btnOutline} mt-3 w-full`}>Continuer mes achats</Link>
        <p className="mt-4 text-center text-xs text-muted">Paiement à la livraison (espèces)</p>
      </aside>
    </div>
  );
}
