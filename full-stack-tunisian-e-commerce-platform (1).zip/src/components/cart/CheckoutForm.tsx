"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { Banknote, Loader2, ShieldCheck, ShoppingBag } from "lucide-react";
import { useCart } from "./CartProvider";
import { createOrder } from "@/app/actions/store";
import { GOVERNORATES } from "@/lib/constants";
import { formatTND } from "@/lib/format";
import { btnClay, input, label } from "@/components/ui/styles";

type Props = {
  fees: { governorate: string; fee: number; active: boolean }[];
  freeThreshold: number;
  defaultFee: number;
  estimate: string;
};

export function CheckoutForm({ fees, freeThreshold, defaultFee, estimate }: Props) {
  const router = useRouter();
  const { items, ready, subtotal } = useCart();
  const [pending, start] = useTransition();
  const [form, setForm] = useState({
    fullName: "", phone: "", email: "", governorate: "", city: "", address: "", notes: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    if (errors[k]) setErrors((x) => ({ ...x, [k]: "" }));
  };

  const delivery = useMemo(() => {
    if (!form.governorate) return null;
    if (freeThreshold > 0 && subtotal >= freeThreshold) return 0;
    return fees.find((f) => f.governorate === form.governorate)?.fee ?? defaultFee;
  }, [form.governorate, subtotal, fees, freeThreshold, defaultFee]);
  const total = subtotal + (delivery ?? 0);

  function validate() {
    const e: Record<string, string> = {};
    if (form.fullName.trim().length < 3) e.fullName = "Veuillez saisir votre nom complet";
    const phone = form.phone.replace(/[\s.-]/g, "").replace(/^(\+216|00216|216)/, "");
    if (!/^[2-9]\d{7}$/.test(phone)) e.phone = "Numéro tunisien invalide (8 chiffres)";
    if (form.email.trim() && !/^\S+@\S+\.\S+$/.test(form.email.trim())) e.email = "Adresse e-mail invalide";
    if (!form.governorate) e.governorate = "Veuillez choisir un gouvernorat";
    if (form.city.trim().length < 2) e.city = "Veuillez saisir votre ville";
    if (form.address.trim().length < 8) e.address = "Veuillez saisir votre adresse complète";
    return e;
  }

  function onSubmit(ev: React.FormEvent) {
    ev.preventDefault();
    setFormError("");
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) {
      document.getElementById(`f-${Object.keys(e)[0]}`)?.focus();
      return;
    }
    start(async () => {
      const res = await createOrder({
        ...form,
        items: items.map((i) => ({ productId: i.productId, variantId: i.variantId, quantity: i.qty })),
      });
      if (res.ok) {
        router.push(`/commande/confirmation/${res.orderNumber}`);
      } else {
        setFormError(res.error);
        if (res.fieldErrors) setErrors(res.fieldErrors);
      }
    });
  }

  if (!ready) return <div className="skeleton h-96 w-full rounded-2xl" aria-busy="true" />;

  if (items.length === 0) {
    return (
      <div className="rounded-3xl border border-dashed border-line bg-white/60 px-6 py-20 text-center">
        <ShoppingBag className="mx-auto h-12 w-12 text-beige" />
        <h2 className="mt-4 font-display text-3xl">Votre panier est vide</h2>
        <p className="mt-2 text-sm text-muted">Ajoutez des articles avant de passer commande.</p>
        <Link href="/boutique" className={`${btnClay} mt-6`}>Découvrir la boutique</Link>
      </div>
    );
  }

  const err = (k: string) => errors[k] && <p id={`e-${k}`} role="alert" className="mt-1.5 text-xs text-rose-600">{errors[k]}</p>;
  const a11y = (k: string) => ({ "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `e-${k}` : undefined });

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-10 lg:grid-cols-[1fr_400px]">
      <div className="space-y-8">
        <section className="rounded-2xl border border-line bg-white p-6">
          <h2 className="mb-5 font-display text-2xl font-semibold">1. Vos coordonnées</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="f-fullName" className={label}>Nom complet *</label>
              <input id="f-fullName" autoComplete="name" value={form.fullName} onChange={set("fullName")} className={input} placeholder="Prénom et nom" {...a11y("fullName")} />
              {err("fullName")}
            </div>
            <div>
              <label htmlFor="f-phone" className={label}>Téléphone *</label>
              <input id="f-phone" type="tel" inputMode="tel" autoComplete="tel" value={form.phone} onChange={set("phone")} className={input} placeholder="Ex : 92 944 940" {...a11y("phone")} />
              {err("phone")}
            </div>
            <div>
              <label htmlFor="f-email" className={label}>E-mail <span className="font-normal text-muted">(facultatif)</span></label>
              <input id="f-email" type="email" autoComplete="email" value={form.email} onChange={set("email")} className={input} placeholder="vous@exemple.com" {...a11y("email")} />
              {err("email")}
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-line bg-white p-6">
          <h2 className="mb-5 font-display text-2xl font-semibold">2. Adresse de livraison</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="f-governorate" className={label}>Gouvernorat *</label>
              <select id="f-governorate" value={form.governorate} onChange={set("governorate")} className={input} {...a11y("governorate")}>
                <option value="">Choisir…</option>
                {GOVERNORATES.map((g) => {
                  const row = fees.find((f) => f.governorate === g);
                  return <option key={g} value={g} disabled={row ? !row.active : false}>{g}</option>;
                })}
              </select>
              {err("governorate")}
            </div>
            <div>
              <label htmlFor="f-city" className={label}>Ville / délégation *</label>
              <input id="f-city" autoComplete="address-level2" value={form.city} onChange={set("city")} className={input} {...a11y("city")} />
              {err("city")}
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="f-address" className={label}>Adresse complète *</label>
              <input id="f-address" autoComplete="street-address" value={form.address} onChange={set("address")} className={input} placeholder="Rue, numéro, résidence, étage…" {...a11y("address")} />
              {err("address")}
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="f-notes" className={label}>Notes de livraison <span className="font-normal text-muted">(facultatif)</span></label>
              <textarea id="f-notes" rows={3} value={form.notes} onChange={set("notes")} className={input} placeholder="Point de repère, horaire préféré, message pour un cadeau…" maxLength={500} />
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-line bg-white p-6">
          <h2 className="mb-5 font-display text-2xl font-semibold">3. Paiement</h2>
          <label className="flex items-start gap-4 rounded-xl border-2 border-clay bg-clay/5 p-4">
            <input type="radio" checked readOnly className="mt-1 h-4 w-4 accent-clay" />
            <span>
              <span className="flex items-center gap-2 font-medium"><Banknote className="h-5 w-5 text-clay" /> Paiement à la livraison (COD)</span>
              <span className="mt-1 block text-sm text-muted">Vous réglez en espèces au livreur à la réception de votre commande. Livraison sous {estimate}.</span>
            </span>
          </label>
        </section>
      </div>

      <aside className="h-fit rounded-2xl border border-line bg-white p-6 lg:sticky lg:top-32">
        <h2 className="font-display text-2xl font-semibold">Votre commande</h2>
        <ul className="mt-5 max-h-72 space-y-4 overflow-y-auto pr-1">
          {items.map((i) => (
            <li key={i.key} className="flex gap-3">
              <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-cream">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={i.image} alt="" className="h-full w-full object-cover" />
                <span className="absolute -right-0 -top-0 flex h-5 min-w-5 items-center justify-center rounded-bl-lg bg-ink px-1 text-[10px] text-ivory">{i.qty}</span>
              </div>
              <div className="min-w-0 flex-1 text-sm">
                <p className="truncate font-medium">{i.name}</p>
                {i.variantLabel && <p className="text-xs text-muted">{i.variantLabel}</p>}
              </div>
              <p className="whitespace-nowrap text-sm font-medium">{formatTND(i.price * i.qty)}</p>
            </li>
          ))}
        </ul>
        <dl className="mt-5 space-y-3 border-t border-line pt-5 text-sm">
          <div className="flex justify-between"><dt className="text-muted">Sous-total</dt><dd>{formatTND(subtotal)}</dd></div>
          <div className="flex justify-between">
            <dt className="text-muted">Livraison</dt>
            <dd>{delivery === null ? <span className="text-muted">Choisir un gouvernorat</span> : delivery === 0 ? <span className="font-medium text-olive">Offerte</span> : formatTND(delivery)}</dd>
          </div>
          <div className="flex justify-between border-t border-line pt-4"><dt className="font-semibold">Total à payer</dt><dd className="font-display text-3xl font-semibold">{formatTND(total)}</dd></div>
        </dl>
        {formError && <p role="alert" className="mt-4 rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{formError}</p>}
        <button disabled={pending} className={`${btnClay} mt-6 w-full py-4`}>
          {pending ? <><Loader2 className="h-4 w-4 animate-spin" /> Envoi en cours…</> : "Confirmer ma commande"}
        </button>
        <p className="mt-4 flex items-center justify-center gap-2 text-xs text-muted"><ShieldCheck className="h-4 w-4" /> Vos informations sont protégées et utilisées uniquement pour la livraison.</p>
      </aside>
    </form>
  );
}
